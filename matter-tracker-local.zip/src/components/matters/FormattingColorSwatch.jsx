import { FORMATTING_COLORS } from "@/lib/formattingRules";
import { cn } from "@/lib/utils";

/**
 * One pair of contrasting colors: the left half is the light-mode tint,
 * the right half is the dark-mode tint of the same choice.
 */
export default function FormattingColorSwatch({ colorKey, className }) {
  const palette = FORMATTING_COLORS[colorKey] || FORMATTING_COLORS.red;

  return (
    <span className={cn("relative block overflow-hidden rounded-full", className)} aria-hidden="true">
      <span className={cn("absolute inset-y-0 left-0 w-1/2", palette.light)} />
      <span className={cn("absolute inset-y-0 right-0 w-1/2", palette.dark)} />
    </span>
  );
}