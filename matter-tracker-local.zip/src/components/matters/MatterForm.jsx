import { useState, useEffect, useMemo } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Loader2, Settings } from "lucide-react";
import { motion } from "framer-motion";
import { isMobileViewport } from "@/lib/isMobileViewport";

import ListManagementModal from "./ListManagementModal";
import DateField from "./DateField";

const INSTRUMENT_TYPES = [
  "Amendment", "Assignment", "Consent to Sublease", "Easement", "Estoppel Certificate", 
  "Lease", "Letter of Intent", "License Agreement", "Other", 
  "Purchase Agreement", "Sale Agreement", "SNDA", "Sublease"
];

const ASSET_TYPES = [
  "Office", "Life Science / Lab", "Industrial", "Retail (Food)", 
  "Retail (Shopping)", "Mixed Use", "Ground Lease"
];

const PENDING_WITH_OPTIONS = ["Rob", "Client", "Landlord", "Tenant", "Pending Internal Review"];
const STATUS_OPTIONS = ["Closed", "Deal Died", "On Hold", "Open", "Pending Execution"];
const AMENDMENT_TYPES = ["Extension", "Expansion", "Partial Termination", "Termination", "Relocation", "Other"];
const SUBLEASE_RELATED_TYPES = ["Assignment", "Consent to Sublease", "Sublease"];
const LEASE_ONLY_FIELDS = [
  "asset_type", "amendment_types", "sublessee_assignee_name", "sublet_sqft", "sublease_term_type",
  "rentable_sqft", "lease_term_months", "has_extension_option", "has_right_of_first_offer",
  "has_right_of_first_refusal", "has_expansion_option", "has_termination_option", "has_parking",
  "lease_provisions"
];

const DEFAULT_PROVISION_OPTIONS = [
  { name: "Expansion Option", field_key: "has_expansion_option", position: 1 },
  { name: "Extension Option", field_key: "has_extension_option", position: 2 },
  { name: "Parking", field_key: "has_parking", position: 3 },
  { name: "Right of First Offer", field_key: "has_right_of_first_offer", position: 4 },
  { name: "Right of First Refusal", field_key: "has_right_of_first_refusal", position: 5 },
  { name: "Termination Option", field_key: "has_termination_option", position: 6 }
];

function SelectField({ value, onChange, options, placeholder, required }) {
  return (
    <Select value={value || "placeholder_empty"} onValueChange={(val) => val !== "placeholder_empty" && onChange(val)} required={required}>
      <SelectTrigger className="border-slate-200 dark:border-slate-800 dark:bg-slate-900 dark:text-slate-200 focus:border-blue-500 focus:ring-blue-500">
        <SelectValue placeholder={placeholder} />
      </SelectTrigger>
      <SelectContent className="dark:bg-slate-900 dark:border-slate-800">
        <SelectItem value="placeholder_empty" disabled className="hidden">{placeholder}</SelectItem>
        {options.map((option) => (
          <SelectItem key={option} value={option}>{option}</SelectItem>
        ))}
      </SelectContent>
    </Select>
  );
}

export default function MatterForm({ 
  open, 
  onOpenChange, 
  matter, 
  onSave, 
  isSaving, 
  clients = [],
  properties = [],
  opposingParties = [],
  partners = [],
  matterCategories = [],
  instrumentTypes = [],
  assetTypes = [],
  matters = [],
  onCreateClient,
  onCreateProperty,
  onCreateOpposingParty,
  onCreatePartner,
  onUpdateClient,
  onDeleteClient,
  onUpdateProperty,
  onDeleteProperty,
  onUpdateOpposingParty,
  onDeleteOpposingParty,
  onUpdatePartner,
  onDeletePartner,
  onCreateCategory,
  onUpdateCategory,
  onDeleteCategory,
  onCreateInstrumentType,
  onUpdateInstrumentType,
  onDeleteInstrumentType,
  onCreateAssetType,
  onUpdateAssetType,
  onDeleteAssetType,
  leaseProvisionOptions = [],
  onCreateLeaseProvision,
  onUpdateLeaseProvision,
  onDeleteLeaseProvision,
  onUpdateMattersField
}) {
  const instrumentOptions = instrumentTypes.length ? instrumentTypes.map((t) => t.name) : INSTRUMENT_TYPES;
  const assetOptions = assetTypes.length ? assetTypes.map((t) => t.name) : ASSET_TYPES;
  const [formData, setFormData] = useState({
    client_name: "",
    assigned_partner: "",
    property_address: "",
    opposing_party: "",
    matter_category: "Leasing",
    instrument_type: "",
    instrument_type_other: "",
    asset_type: "",
    amendment_types: [],
    sublessee_assignee_name: "",
    sublet_sqft: "",
    sublease_term_type: "",
    date_received: "",
    date_closed: "",
    pending_with: "",
    status: "Open",
    comments: "",
    rentable_sqft: "",
    lease_term_months: "",
    opposing_counsel: "",
    has_extension_option: false,
    has_right_of_first_offer: false,
    has_right_of_first_refusal: false,
    has_expansion_option: false,
    has_termination_option: false,
    has_parking: false,
    lease_provisions: []
  });

  
  const [listModal, setListModal] = useState({ open: false, defaultTab: "clients" });

  const clientNames = useMemo(() => clients.map(c => c.name).sort(), [clients]);
  const partnerNames = useMemo(() => partners.map(p => p.name).sort(), [partners]);
  const categoryNames = useMemo(
    () => [...matterCategories].sort((a, b) => (a.position ?? 99) - (b.position ?? 99)).map(c => c.name),
    [matterCategories]
  );
  const usesLeaseFields = useMemo(() => {
    const category = matterCategories.find(c => c.name === formData.matter_category);
    if (category) return !!category.lease_fields;
    return formData.matter_category === "Leasing" || !formData.matter_category;
  }, [matterCategories, formData.matter_category]);
  const propertyData = useMemo(() => {
    const allAddresses = properties.map(p => p.address);
    const mostRecent = [...properties].sort(
      (a, b) => new Date(b.created_date) - new Date(a.created_date)
    )[0]?.address;

    const top = [];
    if (formData.client_name) {
      const propertyUsage = {};
      matters.forEach(m => {
        if (m.client_name === formData.client_name && m.property_address) {
          propertyUsage[m.property_address] = (propertyUsage[m.property_address] || 0) + 1;
        }
      });
      Object.entries(propertyUsage)
        .sort((a, b) => b[1] - a[1])
        .forEach(([address]) => {
          if (!top.includes(address)) top.push(address);
        });
    }
    if (mostRecent && !top.includes(mostRecent)) top.push(mostRecent);

    return {
      clientProperties: top,
      otherProperties: allAddresses.filter(addr => !top.includes(addr)).sort()
    };
  }, [properties, matters, formData.client_name]);

  // Partners most often assigned to the selected client float to the top.
  const partnerData = useMemo(() => {
    if (!formData.client_name) return { affiliated: [], other: partnerNames };

    const partnerUsage = {};
    matters.forEach(m => {
      if (m.client_name === formData.client_name && m.assigned_partner) {
        partnerUsage[m.assigned_partner] = (partnerUsage[m.assigned_partner] || 0) + 1;
      }
    });

    const affiliated = Object.entries(partnerUsage)
      .sort((a, b) => b[1] - a[1])
      .map(([name]) => name)
      .filter(name => partnerNames.includes(name));

    return {
      affiliated,
      other: partnerNames.filter(name => !affiliated.includes(name))
    };
  }, [partners, matters, formData.client_name, partnerNames]);
  const provisions = useMemo(() => {
    const list = leaseProvisionOptions.length ? leaseProvisionOptions : DEFAULT_PROVISION_OPTIONS;
    return [...list].sort(
      (a, b) => (a.position ?? 99) - (b.position ?? 99) || a.name.localeCompare(b.name)
    );
  }, [leaseProvisionOptions]);

  const isProvisionOn = (option) =>
    option.field_key
      ? !!formData[option.field_key]
      : (formData.lease_provisions || []).includes(option.name);

  const handleProvisionToggle = (option, checked) => {
    setFormData((prev) => {
      const selected = new Set(prev.lease_provisions || []);
      if (checked) selected.add(option.name);
      else selected.delete(option.name);
      const next = { ...prev, lease_provisions: Array.from(selected) };
      if (option.field_key) next[option.field_key] = !!checked;
      return next;
    });
  };

  const opposingPartyData = useMemo(() => {
    const sorted = [...opposingParties].sort((a, b) => new Date(b.created_date) - new Date(a.created_date));
    const recent = sorted.slice(0, 3).map(o => o.name);
    const remaining = sorted.slice(3).map(o => o.name).sort((a, b) => a.localeCompare(b));
    return { recent, remaining };
  }, [opposingParties]);

  useEffect(() => {
    if (matter) {
      setFormData({
        client_name: matter.client_name || "",
        assigned_partner: matter.assigned_partner || "",
        property_address: matter.property_address || "",
        opposing_party: matter.opposing_party || "",
        matter_category: matter.matter_category || "Leasing",
        instrument_type: matter.instrument_type || "",
        instrument_type_other: matter.instrument_type_other || "",
        asset_type: matter.asset_type || "",
        amendment_types: matter.amendment_types || [],
        sublessee_assignee_name: matter.sublessee_assignee_name || "",
        sublet_sqft: matter.sublet_sqft || "",
        sublease_term_type: matter.sublease_term_type || "",
        date_received: matter.date_received || "",
        date_closed: matter.date_closed || "",
        pending_with: matter.pending_with || "",
        status: matter.status || "Open",
        comments: matter.comments || "",
        rentable_sqft: matter.rentable_sqft || "",
        lease_term_months: matter.lease_term_months || "",
        opposing_counsel: matter.opposing_counsel || "",
        has_extension_option: matter.has_extension_option || false,
        has_right_of_first_offer: matter.has_right_of_first_offer || false,
        has_right_of_first_refusal: matter.has_right_of_first_refusal || false,
        has_expansion_option: matter.has_expansion_option || false,
        has_termination_option: matter.has_termination_option || false,
        has_parking: matter.has_parking || false,
        lease_provisions: matter.lease_provisions || []
      });
    } else {
      setFormData({
        client_name: "",
        assigned_partner: "",
        property_address: "",
        opposing_party: "",
        matter_category: "Leasing",
        instrument_type: "",
        instrument_type_other: "",
        asset_type: "",
        amendment_types: [],
        sublessee_assignee_name: "",
        sublet_sqft: "",
        sublease_term_type: "",
        date_received: new Date().toISOString().split('T')[0],
        date_closed: "",
        pending_with: "Rob",
        status: "Open",
        comments: "",
        rentable_sqft: "",
        lease_term_months: "",
        opposing_counsel: "",
        has_extension_option: false,
        has_right_of_first_offer: false,
        has_right_of_first_refusal: false,
        has_expansion_option: false,
        has_termination_option: false,
        has_parking: false,
        lease_provisions: []
      });
    }
  }, [matter, open]);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!formData.instrument_type) {
      return;
    }
    const payload = { ...formData };
    payload.lease_provisions = provisions
      .filter((option) =>
        option.field_key
          ? !!payload[option.field_key]
          : (payload.lease_provisions || []).includes(option.name)
      )
      .map((option) => option.name);
    if (!usesLeaseFields) {
      LEASE_ONLY_FIELDS.forEach((field) => {
        payload[field] = Array.isArray(formData[field]) ? [] : typeof formData[field] === "boolean" ? false : "";
      });
    }
    onSave(payload);
  };

  const handleChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  

  return (
    <>
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto dark:bg-slate-950 dark:border-slate-800">
          <motion.div
            className="grid gap-4"
            initial={isMobileViewport() ? { x: 56, opacity: 0 } : false}
            animate={{ x: 0, opacity: 1 }}
            transition={{ duration: 0.22, ease: "easeOut" }}
          >
          <DialogHeader>
            <DialogTitle className="text-xl font-semibold text-slate-900 dark:text-slate-100">
              {matter ? "Edit Matter" : "New Matter"}
            </DialogTitle>
          </DialogHeader>

          <form onSubmit={handleSubmit} className="space-y-6 mt-4">
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label htmlFor="matter_category" className="text-slate-700 dark:text-slate-300">
                  Matter Category
                </Label>
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  className="h-6 w-6 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
                  onClick={() => setListModal({ open: true, defaultTab: "categories" })}
                >
                  <Settings className="h-3.5 w-3.5" />
                </Button>
              </div>
              <SelectField
                value={formData.matter_category}
                onChange={(val) => handleChange("matter_category", val)}
                options={categoryNames}
                placeholder="Select matter category"
              />
              <p className="text-xs text-slate-500 dark:text-slate-400">
                {usesLeaseFields
                  ? "This category uses the leasing fields below."
                  : "Leasing fields are hidden for this category."}
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label htmlFor="client_name" className="text-slate-700 dark:text-slate-300">
                    Client Name <span className="text-red-500">*</span>
                  </Label>
                  <Button
                    type="button"
                    variant="ghost"
                    size="icon"
                    className="h-6 w-6 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
                    onClick={() => setListModal({ open: true, defaultTab: "clients" })}
                  >
                    <Settings className="h-3.5 w-3.5" />
                  </Button>
                </div>
                <SelectField
                  value={formData.client_name}
                  onChange={(val) => handleChange("client_name", val)}
                  options={clientNames}
                  placeholder="Select client name"
                  required
                />
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label htmlFor="opposing_party" className="text-slate-700 dark:text-slate-300">
                    Opposing Party
                  </Label>
                  <Button
                    type="button"
                    variant="ghost"
                    size="icon"
                    className="h-6 w-6 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
                    onClick={() => setListModal({ open: true, defaultTab: "opposing" })}
                  >
                    <Settings className="h-3.5 w-3.5" />
                  </Button>
                </div>
                <Select value={formData.opposing_party || "placeholder_empty"} onValueChange={(val) => val !== "placeholder_empty" && handleChange("opposing_party", val)}>
                  <SelectTrigger className="border-slate-200 dark:border-slate-800 dark:bg-slate-900 dark:text-slate-200 focus:border-blue-500 focus:ring-blue-500">
                    <SelectValue placeholder="Select opposing party" />
                  </SelectTrigger>
                  <SelectContent className="dark:bg-slate-900 dark:border-slate-800">
                    <SelectItem value="placeholder_empty" disabled className="hidden">Select opposing party</SelectItem>
                    {opposingPartyData.recent.map((name) => (
                      <SelectItem key={name} value={name}>{name}</SelectItem>
                    ))}
                    {opposingPartyData.recent.length > 0 && opposingPartyData.remaining.length > 0 && (
                      <div className="h-[2px] bg-slate-900 dark:bg-slate-700 my-1 mx-2" />
                    )}
                    {opposingPartyData.remaining.map((name) => (
                      <SelectItem key={name} value={name}>{name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label htmlFor="assigned_partner" className="text-slate-700 dark:text-slate-300">
                  Assigned Partner
                </Label>
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  className="h-6 w-6 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
                  onClick={() => setListModal({ open: true, defaultTab: "partners" })}
                >
                  <Settings className="h-3.5 w-3.5" />
                </Button>
              </div>
              <Select value={formData.assigned_partner || "placeholder_empty"} onValueChange={(val) => val !== "placeholder_empty" && handleChange("assigned_partner", val)}>
                <SelectTrigger className="border-slate-200 dark:border-slate-800 dark:bg-slate-900 dark:text-slate-200 focus:border-blue-500 focus:ring-blue-500">
                  <SelectValue placeholder="Select assigned partner" />
                </SelectTrigger>
                <SelectContent className="dark:bg-slate-900 dark:border-slate-800">
                  <SelectItem value="placeholder_empty" disabled className="hidden">Select assigned partner</SelectItem>
                  {partnerData.affiliated.map((name) => (
                    <SelectItem key={name} value={name}>{name}</SelectItem>
                  ))}
                  {partnerData.affiliated.length > 0 && partnerData.other.length > 0 && (
                    <div className="h-[2px] bg-slate-900 dark:bg-slate-700 my-1 mx-2" />
                  )}
                  {partnerData.other.map((name) => (
                    <SelectItem key={name} value={name}>{name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label htmlFor="property_address" className="text-slate-700 dark:text-slate-300">
                  Property Address <span className="text-red-500">*</span>
                </Label>
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  className="h-6 w-6 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
                  onClick={() => setListModal({ open: true, defaultTab: "properties" })}
                >
                  <Settings className="h-3.5 w-3.5" />
                </Button>
              </div>
              <Select value={formData.property_address || "placeholder_empty"} onValueChange={(val) => val !== "placeholder_empty" && handleChange("property_address", val)} required>
                <SelectTrigger className="border-slate-200 dark:border-slate-800 dark:bg-slate-900 dark:text-slate-200 focus:border-blue-500 focus:ring-blue-500">
                  <SelectValue placeholder="Select property address" />
                </SelectTrigger>
                <SelectContent className="dark:bg-slate-900 dark:border-slate-800">
                  <SelectItem value="placeholder_empty" disabled className="hidden">Select property address</SelectItem>
                  {propertyData.clientProperties.map((address) => (
                    <SelectItem key={address} value={address}>{address}</SelectItem>
                  ))}
                  {propertyData.clientProperties.length > 0 && propertyData.otherProperties.length > 0 && (
                    <div className="h-[2px] bg-slate-900 dark:bg-slate-700 my-1 mx-2" />
                  )}
                  {propertyData.otherProperties.map((address) => (
                    <SelectItem key={address} value={address}>{address}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className={`grid gap-6 ${usesLeaseFields ? "grid-cols-1 md:grid-cols-2" : "grid-cols-1"}`}>
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label className="text-slate-700 dark:text-slate-300">
                    Instrument Type <span className="text-red-500">*</span>
                  </Label>
                  <Button
                    type="button"
                    variant="ghost"
                    size="icon"
                    className="h-6 w-6 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
                    title="Manage instrument types"
                    onClick={() => setListModal({ open: true, defaultTab: "instruments" })}
                  >
                    <Settings className="h-3.5 w-3.5" />
                  </Button>
                </div>
                <Select
                  value={formData.instrument_type}
                  onValueChange={(value) => {
                    handleChange("instrument_type", value);
                    if (value !== "Other") {
                      handleChange("instrument_type_other", "");
                    }
                    if (!SUBLEASE_RELATED_TYPES.includes(value)) {
                      handleChange("sublessee_assignee_name", "");
                      handleChange("sublet_sqft", "");
                      handleChange("sublease_term_type", "");
                    }
                    if (value !== "Amendment") {
                      handleChange("amendment_types", []);
                    }
                  }}
                  required
                >
                  <SelectTrigger className="border-slate-200 dark:border-slate-800 dark:bg-slate-900 dark:text-slate-200 focus:border-blue-500 focus:ring-blue-500">
                    <SelectValue placeholder="Select instrument type" />
                  </SelectTrigger>
                  <SelectContent className="dark:bg-slate-900 dark:border-slate-800">
                    {instrumentOptions.map((type) => (
                      <SelectItem key={type} value={type}>{type}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {usesLeaseFields && (
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label className="text-slate-700 dark:text-slate-300">
                    Asset Type
                  </Label>
                  <Button
                    type="button"
                    variant="ghost"
                    size="icon"
                    className="h-6 w-6 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
                    title="Manage asset types"
                    onClick={() => setListModal({ open: true, defaultTab: "assets" })}
                  >
                    <Settings className="h-3.5 w-3.5" />
                  </Button>
                </div>
                <Select
                  value={formData.asset_type || "placeholder_empty"}
                  onValueChange={(val) => val !== "placeholder_empty" && handleChange("asset_type", val)}
                >
                  <SelectTrigger className="border-slate-200 dark:border-slate-800 dark:bg-slate-900 dark:text-slate-200 focus:border-blue-500 focus:ring-blue-500">
                    <SelectValue placeholder="Select asset type" />
                  </SelectTrigger>
                  <SelectContent className="dark:bg-slate-900 dark:border-slate-800">
                    <SelectItem value="placeholder_empty" disabled className="hidden">Select asset type</SelectItem>
                    {assetOptions.map((type) => (
                      <SelectItem key={type} value={type}>{type}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              )}
            </div>

            {formData.instrument_type === "Other" && (
              <div className="space-y-2">
                <Label htmlFor="instrument_type_other" className="text-slate-700 dark:text-slate-300">
                  Specify Instrument <span className="text-red-500">*</span>
                </Label>
                <Input
                  id="instrument_type_other"
                  value={formData.instrument_type_other}
                  onChange={(e) => handleChange("instrument_type_other", e.target.value)}
                  placeholder="Enter instrument type"
                  required
                  className="border-slate-200 dark:border-slate-800 dark:bg-slate-900 dark:text-slate-200 focus:border-blue-500 focus:ring-blue-500"
                />
              </div>
            )}

            {usesLeaseFields && SUBLEASE_RELATED_TYPES.includes(formData.instrument_type) && (
              <div className="space-y-2">
                <Label htmlFor="sublessee_assignee_name" className="text-slate-700 dark:text-slate-300">
                  Name of Sublessee or Assignee <span className="text-red-500">*</span>
                </Label>
                <Input
                  id="sublessee_assignee_name"
                  value={formData.sublessee_assignee_name}
                  onChange={(e) => handleChange("sublessee_assignee_name", e.target.value)}
                  placeholder="Enter sublessee or assignee name"
                  required
                  className="border-slate-200 dark:border-slate-800 dark:bg-slate-900 dark:text-slate-200 focus:border-blue-500 focus:ring-blue-500"
                />
              </div>
            )}

            {usesLeaseFields && formData.instrument_type === "Amendment" && (
              <div className="space-y-2">
                <Label className="text-slate-700 dark:text-slate-300">Amendment Type(s)</Label>
                <div className="flex flex-wrap gap-3 mt-2">
                  {AMENDMENT_TYPES.map((type) => (
                    <div key={type} className="flex items-center space-x-2 bg-slate-50 dark:bg-slate-900 px-3 py-2 rounded-lg">
                      <Checkbox
                        id={`amendment_${type}`}
                        checked={formData.amendment_types?.includes(type)}
                        onCheckedChange={(checked) => {
                          if (checked) {
                            handleChange("amendment_types", [...(formData.amendment_types || []), type]);
                          } else {
                            handleChange("amendment_types", (formData.amendment_types || []).filter(t => t !== type));
                          }
                        }}
                      />
                      <Label htmlFor={`amendment_${type}`} className="text-sm font-normal text-slate-700 dark:text-slate-300 cursor-pointer">
                        {type}
                      </Label>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {usesLeaseFields && SUBLEASE_RELATED_TYPES.includes(formData.instrument_type) && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="sublet_sqft" className="text-slate-700 dark:text-slate-300">
                    Rentable Area of {formData.instrument_type === "Assignment" ? "Assigned" : "Sublet"} Premises (SF)
                  </Label>
                  <Input
                    id="sublet_sqft"
                    type="number"
                    min="0"
                    value={formData.sublet_sqft}
                    onChange={(e) => handleChange("sublet_sqft", e.target.value ? Number(e.target.value) : "")}
                    placeholder="e.g., 2500"
                    className="border-slate-200 dark:border-slate-800 dark:bg-slate-900 dark:text-slate-200 focus:border-blue-500 focus:ring-blue-500"
                  />
                </div>

                <div className="space-y-2">
                  <Label className="text-slate-700 dark:text-slate-300">
                    Term of {formData.instrument_type === "Assignment" ? "Assignment" : "Sublease"}
                  </Label>
                  <Select
                    value={formData.sublease_term_type}
                    onValueChange={(value) => handleChange("sublease_term_type", value)}
                  >
                    <SelectTrigger className="border-slate-200 dark:border-slate-800 dark:bg-slate-900 dark:text-slate-200 focus:border-blue-500 focus:ring-blue-500">
                      <SelectValue placeholder="Select term type" />
                    </SelectTrigger>
                    <SelectContent className="dark:bg-slate-900 dark:border-slate-800">
                      <SelectItem value="All of Remainder of Master Term">All of Remainder of Master Term</SelectItem>
                      <SelectItem value="Part of Remainder of Master Term">Part of Remainder of Master Term</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            )}

            <div className="space-y-2">
              <Label htmlFor="date_received" className="text-slate-700 dark:text-slate-300">
                Date Received <span className="text-red-500">*</span>
              </Label>
              <DateField
                id="date_received"
                value={formData.date_received}
                onChange={(val) => handleChange("date_received", val)}
                required
                className="border-slate-200 dark:border-slate-800 dark:bg-slate-900 dark:text-slate-200 focus:border-blue-500 focus:ring-blue-500"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="opposing_counsel" className="text-slate-700 dark:text-slate-300">
                Name of Opposing Counsel
              </Label>
              <Input
                id="opposing_counsel"
                value={formData.opposing_counsel}
                onChange={(e) => handleChange("opposing_counsel", e.target.value)}
                placeholder="Enter opposing counsel name"
                className="border-slate-200 dark:border-slate-800 dark:bg-slate-900 dark:text-slate-200 focus:border-blue-500 focus:ring-blue-500"
              />
            </div>

            {usesLeaseFields && (
            <div className="border-t border-slate-200 dark:border-slate-800 pt-6 mt-6">
              <h3 className="text-sm font-semibold text-slate-700 dark:text-slate-300 mb-4">
                Lease Metrics (Optional)
              </h3>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                <div className="space-y-2">
                  <Label htmlFor="rentable_sqft" className="text-slate-700 dark:text-slate-300">
                    Rentable Square Feet
                  </Label>
                  <Input
                    id="rentable_sqft"
                    type="number"
                    min="0"
                    value={formData.rentable_sqft}
                    onChange={(e) => handleChange("rentable_sqft", e.target.value ? Number(e.target.value) : "")}
                    placeholder="e.g., 5000"
                    className="border-slate-200 dark:border-slate-800 dark:bg-slate-900 dark:text-slate-200 focus:border-blue-500 focus:ring-blue-500"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="lease_term_months" className="text-slate-700 dark:text-slate-300">
                    Lease Term (Months)
                  </Label>
                  <Input
                    id="lease_term_months"
                    type="number"
                    min="0"
                    value={formData.lease_term_months}
                    onChange={(e) => handleChange("lease_term_months", e.target.value ? Number(e.target.value) : "")}
                    placeholder="e.g., 60"
                    className="border-slate-200 dark:border-slate-800 dark:bg-slate-900 dark:text-slate-200 focus:border-blue-500 focus:ring-blue-500"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label className="text-slate-700 dark:text-slate-300">Lease Provisions</Label>
                  <Button
                    type="button"
                    variant="ghost"
                    size="icon"
                    className="h-6 w-6 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
                    title="Manage lease provisions"
                    onClick={() => setListModal({ open: true, defaultTab: "provisions" })}
                  >
                    <Settings className="h-3.5 w-3.5" />
                  </Button>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 mt-2">
                  {provisions.map((option) => {
                    const fieldId = `provision_${option.field_key || option.name.replace(/\s+/g, "_")}`;
                    return (
                      <div key={fieldId} className="flex items-center space-x-3 bg-slate-50 dark:bg-slate-900 p-3 rounded-lg">
                        <Checkbox
                          id={fieldId}
                          checked={isProvisionOn(option)}
                          onCheckedChange={(checked) => handleProvisionToggle(option, checked)}
                        />
                        <Label htmlFor={fieldId} className="text-sm font-normal text-slate-700 dark:text-slate-300 cursor-pointer">
                          {option.name}
                        </Label>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
            )}

            <div className="flex justify-end gap-3 pt-4 border-t border-slate-100 dark:border-slate-800">
              <Button
                type="button"
                variant="outline"
                onClick={() => onOpenChange(false)}
                className="border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-900"
              >
                Cancel
              </Button>
              <Button
                type="submit"
                disabled={isSaving}
                className="bg-slate-900 hover:bg-slate-800 dark:bg-slate-200 dark:hover:bg-white dark:text-black text-white"
              >
                {isSaving ? (
                  <>
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                    Saving...
                  </>
                ) : (
                  matter ? "Update Matter" : "Create Matter"
                )}
              </Button>
            </div>
          </form>
          </motion.div>
        </DialogContent>
      </Dialog>

      <ListManagementModal
        open={listModal.open}
        onOpenChange={(open) => setListModal(prev => ({ ...prev, open }))}
        defaultTab={listModal.defaultTab}
        clients={clients}
        properties={properties}
        opposingParties={opposingParties}
        onCreateClient={onCreateClient}
        onUpdateClient={onUpdateClient}
        onDeleteClient={onDeleteClient}
        onCreateProperty={onCreateProperty}
        onUpdateProperty={onUpdateProperty}
        onDeleteProperty={onDeleteProperty}
        partners={partners}
        matterCategories={matterCategories}
        instrumentTypes={instrumentTypes}
        assetTypes={assetTypes}
        onCreateInstrumentType={onCreateInstrumentType}
        onUpdateInstrumentType={onUpdateInstrumentType}
        onDeleteInstrumentType={onDeleteInstrumentType}
        onCreateAssetType={onCreateAssetType}
        onUpdateAssetType={onUpdateAssetType}
        onDeleteAssetType={onDeleteAssetType}
        leaseProvisionOptions={leaseProvisionOptions}
        onCreateLeaseProvision={onCreateLeaseProvision}
        onUpdateLeaseProvision={onUpdateLeaseProvision}
        onDeleteLeaseProvision={onDeleteLeaseProvision}
        onCreateOpposingParty={onCreateOpposingParty}
        onUpdateOpposingParty={onUpdateOpposingParty}
        onDeleteOpposingParty={onDeleteOpposingParty}
        onCreatePartner={onCreatePartner}
        onUpdatePartner={onUpdatePartner}
        onDeletePartner={onDeletePartner}
        onCreateCategory={onCreateCategory}
        onUpdateCategory={onUpdateCategory}
        onDeleteCategory={onDeleteCategory}
        onUpdateMattersField={onUpdateMattersField}
      />
    </>
  );
}