import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Cloud, X } from "lucide-react";
import { toast } from "sonner";
import { formatDistanceToNow } from "date-fns";
import { getLastBackupAt, saveBackup, usePreparedBackup } from "@/lib/backup";

const DAY_MS = 24 * 60 * 60 * 1000;

// Shown at the top of the app when there is data and no backup in the last day.
export default function BackupBanner({ hasData, dataVersion }) {
  const [dismissed, setDismissed] = useState(() => sessionStorage.getItem("backupBannerDismissed") === "1");
  const [done, setDone] = useState(false);
  const [busy, setBusy] = useState(false);

  const last = getLastBackupAt();
  const due = hasData && Date.now() - last > DAY_MS;
  const visible = due && !dismissed && !done;
  const prepared = usePreparedBackup(dataVersion, visible);

  if (!visible) return null;

  const onSave = async () => {
    setBusy(true);
    try {
      const result = await saveBackup(prepared);
      if (result === "shared") {
        toast.success("Backup saved");
        setDone(true);
      } else if (result === "downloaded") {
        toast.success("Backup downloaded. Move it to iCloud Drive in Files.");
        setDone(true);
      }
    } catch (e) {
      toast.error("Backup failed: " + e.message);
    } finally {
      setBusy(false);
    }
  };

  const dismiss = () => {
    sessionStorage.setItem("backupBannerDismissed", "1");
    setDismissed(true);
  };

  return (
    <div className="mb-6 flex flex-col sm:flex-row sm:items-center gap-3 rounded-xl border border-amber-200 bg-amber-50 dark:border-amber-900 dark:bg-amber-950/40 p-4">
      <Cloud className="h-6 w-6 shrink-0 text-amber-600 dark:text-amber-400" />
      <div className="flex-1 text-sm text-amber-900 dark:text-amber-200">
        <p className="font-medium">Back up your data</p>
        <p className="text-amber-800 dark:text-amber-300">
          Your data is stored only on this device.{" "}
          {last ? `Last backup ${formatDistanceToNow(last, { addSuffix: true })}.` : "You haven't made a backup yet."}{" "}
          Tap Save, then choose <strong>Save to Files → iCloud Drive</strong>.
        </p>
      </div>
      <div className="flex items-center gap-2">
        <Button onClick={onSave} disabled={!prepared || busy}>
          {busy ? "Saving..." : "Save to iCloud"}
        </Button>
        <Button variant="ghost" size="icon" onClick={dismiss} aria-label="Remind me later">
          <X className="h-4 w-4" />
        </Button>
      </div>
    </div>
  );
}
