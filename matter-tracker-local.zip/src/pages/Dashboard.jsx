import { useState, useMemo, useEffect, useCallback, lazy, Suspense } from "react";
import { useTheme } from "next-themes";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { Plus, Briefcase, Clock, CheckCircle2, PauseCircle, Loader2, Printer, Pencil, Check, X, Archive, List, Settings2, Sun, Moon, Filter, Undo2 } from "lucide-react";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";

import StatsCard from "@/components/matters/StatsCard";
import MatterTable from "@/components/matters/MatterTable";
import MatterForm from "@/components/matters/MatterForm";
import MatterDetail from "@/components/matters/MatterDetail";
import FilterBar from "@/components/matters/FilterBar";
const PrintReportModal = lazy(() => import("@/components/matters/PrintReportModal"));
import ArchiveModal from "@/components/matters/ArchiveModal";
const ListManagementModal = lazy(() => import("@/components/matters/ListManagementModal"));
const DataManagementModal = lazy(() => import("@/components/matters/DataManagementModal"));
const ColumnManagerModal = lazy(() => import("@/components/matters/ColumnManagerModal"));
import { cn } from "@/lib/utils";
import { PENDING_WITH_OPTIONS as DEFAULT_PENDING_WITH_OPTIONS, STATUS_OPTIONS as DEFAULT_STATUS_OPTIONS } from "@/lib/matterColumns";
import { loadFilterCards } from "@/lib/filterCards";
import { BUILT_IN_FORMATTING_RULES, DEFAULT_FORMATTING_RULES } from "@/lib/formattingRules";
import { readMattersCache, writeMattersCache } from "@/lib/mattersCache";
import useUndoStack from "@/hooks/useUndoStack";
import PullToRefresh from "@/components/PullToRefresh";
import MobileTabBar from "@/components/matters/MobileTabBar";
import ModalSpinner from "@/components/ModalSpinner";
import useSheetHistory from "@/hooks/useSheetHistory";
import PasscodeGate from "@/components/PasscodeGate";
import BackupBanner from "@/components/BackupBanner";

const { Matter, Client, Property, OpposingParty, Partner, MatterColumn, MatterCategory, InstrumentType, AssetType, PendingWithOption, StatusOption, LeaseProvisionOption, FormattingRule } = base44.entities;

const stripMeta = (record) => {
  const { id, created_date, updated_date, created_by, created_by_id, ...rest } = record;
  return rest;
};

const todayString = () => new Date().toISOString().split("T")[0];

export default function Dashboard() {
  const [formOpen, setFormOpen] = useState(false);
  const [editingMatter, setEditingMatter] = useState(null);
  const [viewingMatter, setViewingMatter] = useState(null);
  const [deletingMatter, setDeletingMatter] = useState(null);
  const [filters, setFilters] = useState({
    search: "",
    status: "All Statuses",
    statusMulti: [],
    instrumentType: "All Types",
    pendingWith: "All",
    client: "All Clients",
    property: "All Properties"
  });
  const [printModalOpen, setPrintModalOpen] = useState(false);
      const [archiveModalOpen, setArchiveModalOpen] = useState(false);
      const [listModalOpen, setListModalOpen] = useState(false);
      const [dataManagementOpen, setDataManagementOpen] = useState(false);
  const [columnsModalOpen, setColumnsModalOpen] = useState(false);
  const [showFilters, setShowFilters] = useState(false);
  const [sortConfig, setSortConfig] = useState({ key: null, direction: 'asc' });
  const [appTitle, setAppTitle] = useState(() => localStorage.getItem('matterTrackerTitle') || "Leasing Tracker");
  const [isEditingTitle, setIsEditingTitle] = useState(false);
  const [tempTitle, setTempTitle] = useState(appTitle);
  const { resolvedTheme, setTheme } = useTheme();
  const [showUpdateNotice, setShowUpdateNotice] = useState(false);

  // Check for app updates
  useEffect(() => {
    const APP_VERSION = "1.0.2"; // Increment this when publishing updates
    const lastVersion = localStorage.getItem('matterTrackerVersion');
    const noticeShownThisSession = sessionStorage.getItem('updateNoticeShown');
    
    // Show notice if version changed and we haven't shown it this session
    if (lastVersion !== APP_VERSION && !noticeShownThisSession) {
      setShowUpdateNotice(true);
      sessionStorage.setItem('updateNoticeShown', 'true');
    }
    
    localStorage.setItem('matterTrackerVersion', APP_VERSION);
  }, []);

  const toggleTheme = () => {
    setTheme(resolvedTheme === 'dark' ? 'light' : 'dark');
  };

  const handleSaveTitle = () => {
    setAppTitle(tempTitle);
    localStorage.setItem('matterTrackerTitle', tempTitle);
    setIsEditingTitle(false);
  };

  const handleCancelTitle = () => {
    setTempTitle(appTitle);
    setIsEditingTitle(false);
  };

  const queryClient = useQueryClient();
  const undoStack = useUndoStack();
  const handlePullRefresh = useCallback(
    () => queryClient.invalidateQueries({ queryKey: ["matters"] }),
    [queryClient]
  );

  const { data: user } = useQuery({
    queryKey: ["currentUser"],
    queryFn: () => base44.auth.me()
  });

  const { data: allMatters = [], isLoading } = useQuery({
    queryKey: ["matters", user?.email],
    queryFn: () => Matter.filter({ created_by: user.email }, "created_date"),
    enabled: !!user?.email,
    // Paint from the on-device copy immediately; the server refresh follows.
    placeholderData: () => readMattersCache(user?.email)
  });

  // Keep the on-device copy current after every change.
  useEffect(() => {
    if (!isLoading && user?.email) {
      writeMattersCache(user.email, allMatters);
    }
  }, [allMatters, isLoading, user?.email]);

  // Separate active matters from archived
        const matters = allMatters.filter(m => !m.archived);
        const archivedMatters = allMatters.filter(m => m.archived);



      // Fetch lists
      const { data: clients = [] } = useQuery({
        queryKey: ["clients", user?.email],
        queryFn: () => Client.filter({ created_by: user.email }, "name"),
        enabled: !!user?.email
      });

      const { data: properties = [] } = useQuery({
        queryKey: ["properties", user?.email],
        queryFn: () => Property.filter({ created_by: user.email }, "address"),
        enabled: !!user?.email
      });

      const { data: opposingParties = [] } = useQuery({
        queryKey: ["opposingParties", user?.email],
        queryFn: () => OpposingParty.filter({ created_by: user.email }, "name"),
        enabled: !!user?.email
      });

      const { data: partners = [] } = useQuery({
        queryKey: ["partners", user?.email],
        queryFn: () => Partner.filter({ created_by: user.email }, "name"),
        enabled: !!user?.email
      });

      const { data: instrumentTypes = [] } = useQuery({
        queryKey: ["instrumentTypes", user?.email],
        queryFn: () => InstrumentType.filter({}, "name"),
        enabled: !!user?.email
      });

      const { data: assetTypes = [] } = useQuery({
        queryKey: ["assetTypes", user?.email],
        queryFn: () => AssetType.filter({}, "name"),
        enabled: !!user?.email
      });

      const { data: leaseProvisionOptions = [] } = useQuery({
        queryKey: ["leaseProvisionOptions", user?.email],
        queryFn: () => LeaseProvisionOption.filter({}, "position"),
        enabled: !!user?.email
      });

      const { data: pendingWithRecords = [] } = useQuery({
        queryKey: ["pendingWithOptions", user?.email],
        queryFn: () => PendingWithOption.filter({}, "name"),
        enabled: !!user?.email
      });

      const pendingWithOptions = pendingWithRecords.length
        ? pendingWithRecords.map((option) => option.name)
        : DEFAULT_PENDING_WITH_OPTIONS;

      const { data: statusRecords = [] } = useQuery({
        queryKey: ["statusOptions", user?.email],
        queryFn: () => StatusOption.filter({}, "name"),
        enabled: !!user?.email
      });

      const statusOptions = statusRecords.length
        ? statusRecords.map((option) => option.name)
        : DEFAULT_STATUS_OPTIONS;

      const { data: matterColumns = [] } = useQuery({
        queryKey: ["matterColumns", user?.email],
        queryFn: () => MatterColumn.filter({ created_by: user.email }, "position"),
        enabled: !!user?.email
      });

      const { data: matterCategories = [] } = useQuery({
        queryKey: ["matterCategories", user?.email],
        queryFn: () => MatterCategory.filter({ created_by: user.email }, "position"),
        enabled: !!user?.email
      });

      const { data: formattingRules = [], isSuccess: formattingRulesLoaded } = useQuery({
        queryKey: ["formattingRules", user?.email],
        queryFn: () => FormattingRule.filter({ created_by: user.email }, "position"),
        enabled: !!user?.email
      });

      // Store the app's standard highlights (stale activity, pending with Rob / internal review,
      // pending execution) as real rules once per account, so they show up in the Formatting tab.
      useEffect(() => {
        if (!formattingRulesLoaded || !user?.email) return;
        const seedKey = `formattingRulesBuiltInsSeeded_${user.email}`;
        if (localStorage.getItem(seedKey)) return;
        localStorage.setItem(seedKey, "1");
        const existingNames = new Set(formattingRules.map((rule) => rule.name));
        const missing = formattingRules.length === 0
          ? DEFAULT_FORMATTING_RULES
          : BUILT_IN_FORMATTING_RULES.filter((rule) => !existingNames.has(rule.name));
        if (missing.length) {
          FormattingRule.bulkCreate(missing)
            .then(() => queryClient.invalidateQueries({ queryKey: ["formattingRules"] }))
            .catch(() => localStorage.removeItem(seedKey));
        }
      }, [formattingRulesLoaded, formattingRules, user?.email]);

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.Matter.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["matters"] });
      setFormOpen(false);
      toast.success("Matter created successfully");
    }
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Matter.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["matters"] });
      setFormOpen(false);
      setEditingMatter(null);
      toast.success("Matter updated successfully");
    }
  });

  const quickUpdateMutation = useMutation({
    mutationFn: ({ id, field, value }) => base44.entities.Matter.update(id, { [field]: value }),
    onMutate: async ({ id, field, value }) => {
      await queryClient.cancelQueries({ queryKey: ["matters"] });
      const previous = queryClient.getQueriesData({ queryKey: ["matters"] });
      queryClient.setQueriesData({ queryKey: ["matters"] }, (old) =>
        Array.isArray(old)
          ? old.map((matter) => (matter.id === id ? { ...matter, [field]: value } : matter))
          : old
      );
      return { previous };
    },
    onError: (_error, _variables, context) => {
      context?.previous?.forEach(([key, data]) => queryClient.setQueryData(key, data));
      toast.error("Could not save that change");
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["matters"] });
      toast.success("Updated successfully");
    }
  });

  const handleQuickUpdate = (id, field, value) => {
    const previous = allMatters.find((matter) => matter.id === id);
    undoStack.push({
      kind: "update",
      id,
      data: { [field]: previous ? previous[field] ?? null : null },
      label: "cell edit"
    });
    quickUpdateMutation.mutate({ id, field, value });
  };

  const archiveMutation = useMutation({
    mutationFn: (id) => base44.entities.Matter.update(id, { 
      archived: true, 
      archived_date: new Date().toISOString().split('T')[0] 
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["matters"] });
      setDeletingMatter(null);
      toast.success("Matter archived successfully");
    }
  });

  const restoreMutation = useMutation({
    mutationFn: (id) => base44.entities.Matter.update(id, { 
      archived: false, 
      archived_date: null 
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["matters"] });
      toast.success("Matter restored successfully");
    }
  });

  const deleteMutation = useMutation({
        mutationFn: (id) => base44.entities.Matter.delete(id),
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: ["matters"] });
          toast.success("Matter permanently deleted");
          }
          });

  const handleRestore = async (mattersToRestore) => {
    try {
      // Delete all current matters
      for (const matter of allMatters) {
        await Matter.delete(matter.id);
      }

      // Restore matters from backup
      for (const matter of mattersToRestore) {
        const { id, created_date, updated_date, created_by, ...matterData } = matter;
        await Matter.create(matterData);
      }

      queryClient.invalidateQueries({ queryKey: ["matters"] });
    } catch (error) {
      throw error;
    }
  };

  const handleDeleteAll = async () => {
    for (const matter of allMatters) {
      await Matter.delete(matter.id);
    }
    queryClient.invalidateQueries({ queryKey: ["matters"] });
  };

      // Client mutations
      const createClientMutation = useMutation({
        mutationFn: (data) => Client.create(data),
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: ["clients"] });
          toast.success("Client added");
        }
      });

      const updateClientMutation = useMutation({
        mutationFn: ({ id, data }) => Client.update(id, data),
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: ["clients"] });
          toast.success("Client updated");
        }
      });

      const deleteClientMutation = useMutation({
        mutationFn: (id) => Client.delete(id),
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: ["clients"] });
          toast.success("Client removed from list");
        }
      });

      // Property mutations
      const createPropertyMutation = useMutation({
        mutationFn: (data) => Property.create(data),
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: ["properties"] });
          toast.success("Property added");
        }
      });

      const updatePropertyMutation = useMutation({
        mutationFn: ({ id, data }) => Property.update(id, data),
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: ["properties"] });
          toast.success("Property updated");
        }
      });

      const deletePropertyMutation = useMutation({
        mutationFn: (id) => Property.delete(id),
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: ["properties"] });
          toast.success("Property removed from list");
        }
      });

      // Opposing Party mutations
      const createOpposingPartyMutation = useMutation({
        mutationFn: (data) => OpposingParty.create(data),
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: ["opposingParties"] });
          toast.success("Opposing party added");
        }
      });

      const updateOpposingPartyMutation = useMutation({
        mutationFn: ({ id, data }) => OpposingParty.update(id, data),
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: ["opposingParties"] });
          toast.success("Opposing party updated");
        }
      });

      const deleteOpposingPartyMutation = useMutation({
        mutationFn: (id) => OpposingParty.delete(id),
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: ["opposingParties"] });
          toast.success("Opposing party removed from list");
        }
      });

      // Partner mutations
      const createPartnerMutation = useMutation({
        mutationFn: (data) => Partner.create(data),
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: ["partners"] });
          toast.success("Partner added");
        }
      });

      const updatePartnerMutation = useMutation({
        mutationFn: ({ id, data }) => Partner.update(id, data),
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: ["partners"] });
          toast.success("Partner updated");
        }
      });

      const deletePartnerMutation = useMutation({
        mutationFn: (id) => Partner.delete(id),
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: ["partners"] });
          toast.success("Partner removed from list");
        }
      });

      // Instrument type mutations
      const createInstrumentTypeMutation = useMutation({
        mutationFn: (data) => InstrumentType.create(data),
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: ["instrumentTypes"] });
          toast.success("Instrument type added");
        }
      });

      const updateInstrumentTypeMutation = useMutation({
        mutationFn: ({ id, data }) => InstrumentType.update(id, data),
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: ["instrumentTypes"] });
          toast.success("Instrument type updated");
        }
      });

      const deleteInstrumentTypeMutation = useMutation({
        mutationFn: (id) => InstrumentType.delete(id),
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: ["instrumentTypes"] });
          toast.success("Instrument type removed from list");
        }
      });

      // Asset type mutations
      const createAssetTypeMutation = useMutation({
        mutationFn: (data) => AssetType.create(data),
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: ["assetTypes"] });
          toast.success("Asset type added");
        }
      });

      const updateAssetTypeMutation = useMutation({
        mutationFn: ({ id, data }) => AssetType.update(id, data),
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: ["assetTypes"] });
          toast.success("Asset type updated");
        }
      });

      const deleteAssetTypeMutation = useMutation({
        mutationFn: (id) => AssetType.delete(id),
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: ["assetTypes"] });
          toast.success("Asset type removed from list");
        }
      });

      // Lease provision mutations
      const createLeaseProvisionMutation = useMutation({
        mutationFn: (data) => LeaseProvisionOption.create(data),
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: ["leaseProvisionOptions"] });
          toast.success("Lease provision added");
        }
      });

      const updateLeaseProvisionMutation = useMutation({
        mutationFn: ({ id, data }) => LeaseProvisionOption.update(id, data),
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: ["leaseProvisionOptions"] });
          toast.success("Lease provision updated");
        }
      });

      const deleteLeaseProvisionMutation = useMutation({
        mutationFn: (id) => LeaseProvisionOption.delete(id),
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: ["leaseProvisionOptions"] });
          toast.success("Lease provision removed");
        }
      });

      // Pending With option mutations
      const createPendingWithMutation = useMutation({
        mutationFn: (data) => PendingWithOption.create(data),
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: ["pendingWithOptions"] });
          toast.success("Pending With option added");
        }
      });

      const updatePendingWithMutation = useMutation({
        mutationFn: ({ id, data }) => PendingWithOption.update(id, data),
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: ["pendingWithOptions"] });
          toast.success("Pending With option updated");
        }
      });

      const deletePendingWithMutation = useMutation({
        mutationFn: (id) => PendingWithOption.delete(id),
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: ["pendingWithOptions"] });
          toast.success("Pending With option removed");
        }
      });

      // Status option mutations
      const createStatusMutation = useMutation({
        mutationFn: (data) => StatusOption.create(data),
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: ["statusOptions"] });
          toast.success("Status added");
        }
      });

      const updateStatusMutation = useMutation({
        mutationFn: ({ id, data }) => StatusOption.update(id, data),
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: ["statusOptions"] });
          toast.success("Status updated");
        }
      });

      const deleteStatusMutation = useMutation({
        mutationFn: (id) => StatusOption.delete(id),
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: ["statusOptions"] });
          toast.success("Status removed");
        }
      });

      // Custom column mutations
      const createColumnMutation = useMutation({
        mutationFn: (data) => MatterColumn.create(data),
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: ["matterColumns"] });
          toast.success("Column added");
        }
      });

      const updateColumnMutation = useMutation({
        mutationFn: ({ id, data }) => MatterColumn.update(id, data),
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: ["matterColumns"] });
        }
      });

      const deleteColumnMutation = useMutation({
        mutationFn: (id) => MatterColumn.delete(id),
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: ["matterColumns"] });
          toast.success("Column removed");
        }
      });

      // Formatting rule mutations
      const createFormattingRuleMutation = useMutation({
        mutationFn: (data) => FormattingRule.create(data),
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: ["formattingRules"] });
          toast.success("Formatting rule added");
        }
      });

      const updateFormattingRuleMutation = useMutation({
        mutationFn: ({ id, data }) => FormattingRule.update(id, data),
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: ["formattingRules"] });
        }
      });

      const deleteFormattingRuleMutation = useMutation({
        mutationFn: (id) => FormattingRule.delete(id),
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: ["formattingRules"] });
          toast.success("Formatting rule removed");
        }
      });

      // Matter category mutations
      const createCategoryMutation = useMutation({
        mutationFn: (data) => MatterCategory.create(data),
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: ["matterCategories"] });
          toast.success("Category added");
        }
      });

      const updateCategoryMutation = useMutation({
        mutationFn: ({ id, data }) => MatterCategory.update(id, data),
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: ["matterCategories"] });
        }
      });

      const deleteCategoryMutation = useMutation({
        mutationFn: (id) => MatterCategory.delete(id),
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: ["matterCategories"] });
          toast.success("Category removed");
        }
      });

  // Update all matters when a list item name changes
  const handleUpdateMattersField = async (fieldName, oldValue, newValue) => {
    const mattersToUpdate = allMatters.filter(m => m[fieldName] === oldValue);
    for (const matter of mattersToUpdate) {
      await Matter.update(matter.id, { [fieldName]: newValue });
    }
    queryClient.invalidateQueries({ queryKey: ["matters"] });
  };

  const handleSave = (data) => {
    // Clean up empty string values for optional fields
    const cleanedData = { ...data };
    if (cleanedData.date_closed === "") delete cleanedData.date_closed;
    if (cleanedData.sublet_sqft === "") delete cleanedData.sublet_sqft;
    if (cleanedData.rentable_sqft === "") delete cleanedData.rentable_sqft;
    if (cleanedData.lease_term_months === "") delete cleanedData.lease_term_months;
    
    if (editingMatter) {
      undoStack.push({
        kind: "update",
        id: editingMatter.id,
        data: stripMeta(editingMatter),
        label: "matter edit"
      });
      updateMutation.mutate({ id: editingMatter.id, data: cleanedData });
    } else {
      createMutation.mutate(cleanedData);
    }
  };

  const handleEdit = (matter) => {
    setEditingMatter(matter);
    setViewingMatter(null);
    setFormOpen(true);
  };

  const handleView = (matter) => {
    setViewingMatter(matter);
  };

  // Mobile back gesture closes the open sheet/dialog instead of leaving the page.
  useSheetHistory(viewingMatter ? `matter/${viewingMatter.id}` : null, () => setViewingMatter(null));
  useSheetHistory(formOpen ? "matter/new" : null, () => setFormOpen(false));

  const scrollToMatters = () => {
    document.getElementById("matters-table")?.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  const handleFilterChange = (key, value) => {
    setFilters(prev => ({ ...prev, [key]: value }));
  };

  const handleMultiStatusToggle = (statusGroup) => {
    setFilters(prev => {
      const current = prev.statusMulti || [];
      let newMulti;
      
      if (statusGroup === "Open/Pending") {
        const hasOpen = current.includes("Open");
        const hasPending = current.includes("Pending Execution");
        if (hasOpen || hasPending) {
          newMulti = current.filter(s => s !== "Open" && s !== "Pending Execution");
        } else {
          newMulti = [...current, "Open", "Pending Execution"];
        }
      } else if (statusGroup === "Closed/Dead") {
        const hasClosed = current.includes("Closed");
        const hasDead = current.includes("Deal Died");
        if (hasClosed || hasDead) {
          newMulti = current.filter(s => s !== "Closed" && s !== "Deal Died");
        } else {
          newMulti = [...current, "Closed", "Deal Died"];
        }
      } else if (statusGroup === "On Hold") {
        const hasOnHold = current.includes("On Hold");
        if (hasOnHold) {
          newMulti = current.filter(s => s !== "On Hold");
        } else {
          newMulti = [...current, "On Hold"];
        }
      }
      
      return { 
        ...prev, 
        statusMulti: newMulti,
        status: newMulti.length === 0 ? "All Statuses" : "Custom"
      };
    });
  };

  const handleClearFilters = () => {
    setFilters({
      search: "",
      status: "All Statuses",
      statusMulti: [],
      instrumentType: "All Types",
      pendingWith: "All",
      client: "All Clients",
      property: "All Properties"
    });
  };

  const handleSort = (key) => {
    setSortConfig(prev => ({
      key,
      direction: prev.key === key && prev.direction === 'asc' ? 'desc' : 'asc'
    }));
  };

  // Fuzzy search helper
  const fuzzyMatch = (text, search) => {
    if (!text) return false;
    text = text.toLowerCase();
    search = search.toLowerCase();
    
    // Exact substring match
    if (text.includes(search)) return true;
    
    // Fuzzy match: check if characters appear in order
    let searchIdx = 0;
    for (let i = 0; i < text.length && searchIdx < search.length; i++) {
      if (text[i] === search[searchIdx]) searchIdx++;
    }
    if (searchIdx === search.length) return true;
    
    // Word-based fuzzy matching for typos
    const words = text.split(/\s+/);
    return words.some(word => {
      if (word.length < 3 || search.length < 3) return false;
      let matches = 0;
      const minLength = Math.min(word.length, search.length);
      for (let i = 0; i < minLength; i++) {
        if (word[i] === search[i]) matches++;
      }
      return matches >= minLength * 0.7; // 70% character match threshold
    });
  };

  const filteredMatters = useMemo(() => {
    let result = matters.filter(matter => {
      const search = filters.search;
      const matchesSearch = !search || 
        fuzzyMatch(matter.client_name, search) ||
        fuzzyMatch(matter.property_address, search) ||
        fuzzyMatch(matter.opposing_party, search) ||
        fuzzyMatch(matter.opposing_counsel, search) ||
        fuzzyMatch(matter.instrument_type, search) ||
        fuzzyMatch(matter.sublessee_assignee_name, search) ||
        fuzzyMatch(matter.comments, search) ||
        fuzzyMatch(matter.pending_with, search) ||
        fuzzyMatch(matter.status, search);

      let matchesStatus;
      if (filters.statusMulti && filters.statusMulti.length > 0) {
        matchesStatus = filters.statusMulti.includes(matter.status);
      } else {
        matchesStatus = filters.status === "All Statuses" || 
          matter.status === filters.status ||
          (filters.status === "Closed/Dead" && (matter.status === "Closed" || matter.status === "Deal Died")) ||
          (filters.status === "Open/Pending" && (matter.status === "Open" || matter.status === "Pending Execution")) ||
          (filters.status === "On Hold" && matter.status === "On Hold");
      }
      const matchesType = filters.instrumentType === "All Types" || matter.instrument_type === filters.instrumentType;
      const matchesPending = filters.pendingWith === "All" || matter.pending_with === filters.pendingWith;
      const matchesClient = filters.client === "All Clients" || matter.client_name === filters.client;
      const matchesProperty = filters.property === "All Properties" || matter.property_address === filters.property;

      return matchesSearch && matchesStatus && matchesType && matchesPending && matchesClient && matchesProperty;
    });

    if (sortConfig.key) {
      result = [...result].sort((a, b) => {
        const aVal = a[sortConfig.key] || '';
        const bVal = b[sortConfig.key] || '';
        if (aVal < bVal) return sortConfig.direction === 'asc' ? -1 : 1;
        if (aVal > bVal) return sortConfig.direction === 'asc' ? 1 : -1;
        return 0;
      });
    }

    return result;
  }, [matters, filters, sortConfig]);

  const [filterCards, setFilterCards] = useState(loadFilterCards);

  // Apply first enabled filter card on initial load
  useEffect(() => {
    const firstEnabledCard = filterCards.find(card => card.enabled);
    if (firstEnabledCard) {
      handleFilterCardClick(firstEnabledCard.filters);
    }
  }, []);

  // Listen for localStorage changes to update filter cards
  useEffect(() => {
    const handleStorageChange = () => {
      const saved = localStorage.getItem('matterFilterCards');
      if (saved) {
        setFilterCards(JSON.parse(saved));
      }
    };

    window.addEventListener('storage', handleStorageChange);
    
    // Also check on data management modal close
    const interval = setInterval(() => {
      if (!dataManagementOpen) {
        const saved = localStorage.getItem('matterFilterCards');
        if (saved) {
          const parsed = JSON.parse(saved);
          if (JSON.stringify(parsed) !== JSON.stringify(filterCards)) {
            setFilterCards(parsed);
          }
        }
      }
    }, 500);

    return () => {
      window.removeEventListener('storage', handleStorageChange);
      clearInterval(interval);
    };
  }, [dataManagementOpen, filterCards]);

  const getFilteredCount = (filterConfig) => {
    if (!filterConfig.statuses && !filterConfig.instrumentTypes && !filterConfig.pendingWith) {
      return matters.length;
    }
    return matters.filter(m => {
      const statusMatch = !filterConfig.statuses || filterConfig.statuses.length === 0 || filterConfig.statuses.includes(m.status);
      const typeMatch = !filterConfig.instrumentTypes || filterConfig.instrumentTypes.length === 0 || filterConfig.instrumentTypes.includes(m.instrument_type);
      const pendingMatch = !filterConfig.pendingWith || filterConfig.pendingWith.length === 0 || filterConfig.pendingWith.includes(m.pending_with);
      return statusMatch && typeMatch && pendingMatch;
    }).length;
  };

  const handleFilterCardClick = (filterConfig) => {
    setSortConfig({ key: null, direction: 'asc' });
    if (!filterConfig.statuses && !filterConfig.instrumentTypes && !filterConfig.pendingWith) {
      setFilters(prev => ({ ...prev, status: "All Statuses", statusMulti: [], instrumentType: "All Types", pendingWith: "All" }));
    } else {
      setFilters(prev => ({
        ...prev,
        status: "Custom",
        statusMulti: filterConfig.statuses || [],
        instrumentType: filterConfig.instrumentTypes?.length === 1 ? filterConfig.instrumentTypes[0] : "All Types",
        pendingWith: filterConfig.pendingWith?.length === 1 ? filterConfig.pendingWith[0] : "All"
      }));
    }
  };

  const isCardActive = (filterConfig) => {
    if (!filterConfig.statuses && !filterConfig.instrumentTypes && !filterConfig.pendingWith) {
      return filters.status === "All Statuses" && filters.statusMulti.length === 0;
    }
    const statusMatch = JSON.stringify(filters.statusMulti.sort()) === JSON.stringify((filterConfig.statuses || []).sort());
    return statusMatch;
  };

  const handleArchive = (matter) => {
    undoStack.push({
      kind: "update",
      id: matter.id,
      data: { archived: false, archived_date: null },
      label: "archive"
    });
    archiveMutation.mutate(matter.id);
  };

  const handleUnarchive = (matter) => {
    undoStack.push({
      kind: "update",
      id: matter.id,
      data: { archived: true, archived_date: todayString() },
      label: "restore from archive"
    });
    restoreMutation.mutate(matter.id);
  };

  const handlePermanentDelete = (matter) => {
    undoStack.push({ kind: "create", record: matter, label: "permanent delete" });
    deleteMutation.mutate(matter.id);
  };

  const handleUndo = async () => {
    const entry = undoStack.pop();
    if (!entry) return;
    try {
      if (entry.kind === "update") {
        await Matter.update(entry.id, entry.data);
      } else if (entry.kind === "create") {
        await Matter.create(stripMeta(entry.record));
      } else if (entry.kind === "delete") {
        await Matter.delete(entry.id);
      }
      queryClient.invalidateQueries({ queryKey: ["matters"] });
      toast.success("Last change undone");
    } catch (error) {
      toast.error("Could not undo: " + error.message);
    }
  };

  if (isLoading || !user) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-slate-400" />
      </div>
    );
  }

  return (
    <PasscodeGate user={user}>
      <div className="page-shell bg-slate-50 dark:bg-black transition-colors">
        <PullToRefresh onRefresh={handlePullRefresh} />
        <MobileTabBar
          onMatters={scrollToMatters}
          onReports={() => setPrintModalOpen(true)}
          onData={() => setDataManagementOpen(true)}
        />
        <div className="w-full px-3 sm:px-6 lg:px-8">
        <BackupBanner
          hasData={allMatters.length + clients.length + properties.length + opposingParties.length + partners.length > 0}
          dataVersion={JSON.stringify([allMatters.map(m => m.updated_date), clients.length, properties.length, opposingParties.length, partners.length, instrumentTypes.length, assetTypes.length, leaseProvisionOptions.length, pendingWithRecords.length, statusRecords.length, matterColumns.length, matterCategories.length, formattingRules.map(r => r.updated_date)])}
        />
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 mb-5 sm:mb-8">
          <div>
            {isEditingTitle ? (
              <div className="flex items-center gap-2">
                <Input
                  value={tempTitle}
                  onChange={(e) => setTempTitle(e.target.value)}
                  className="text-xl font-bold h-9 w-80"
                  autoFocus
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') handleSaveTitle();
                    if (e.key === 'Escape') handleCancelTitle();
                  }}
                />
                <Button size="icon" variant="ghost" onClick={handleSaveTitle} className="h-8 w-8 text-green-600">
                  <Check className="h-4 w-4" />
                </Button>
                <Button size="icon" variant="ghost" onClick={handleCancelTitle} className="h-8 w-8 text-slate-400">
                  <X className="h-4 w-4" />
                </Button>
              </div>
            ) : (
              <div className="flex items-center gap-2 group">
                <h1 className="text-2xl sm:text-3xl font-bold text-slate-900 dark:text-slate-100 tracking-tight">
                  {appTitle}
                </h1>
                <Button
                  size="icon"
                  variant="ghost"
                  onClick={() => setIsEditingTitle(true)}
                  className="h-7 w-7 opacity-60 sm:opacity-0 sm:group-hover:opacity-100 transition-opacity text-slate-400 hover:text-slate-600"
                >
                  <Pencil className="h-3.5 w-3.5" />
                </Button>
              </div>
            )}
            <p className="mt-1 text-slate-500 dark:text-slate-400">
              Manage and track your commercial real estate matters
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <Button
              variant="outline"
              onClick={handleUndo}
              disabled={undoStack.stack.length === 0}
              title={undoStack.latest ? `Undo ${undoStack.latest.label}` : "Nothing to undo"}
              className="border-slate-200 dark:border-slate-800 text-slate-900 dark:text-slate-200"
            >
              <Undo2 className="h-4 w-4 mr-2" />
              Undo
            </Button>
            <Button
              variant="outline"
              size="icon"
              onClick={toggleTheme}
              className="border-slate-200 dark:border-slate-700"
            >
              {resolvedTheme === 'dark' ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
            </Button>
            <Button
              variant="outline"
              onClick={() => setArchiveModalOpen(true)}
              className="border-slate-200 dark:border-slate-800 text-slate-900 dark:text-slate-200"
            >
              <Archive className="h-4 w-4 mr-2" />
              Archive ({archivedMatters.length})
            </Button>
            <Button
              variant="outline"
              onClick={() => setDataManagementOpen(true)}
              className="border-slate-200 dark:border-slate-800 text-slate-900 dark:text-slate-200"
            >
              <Settings2 className="h-4 w-4 mr-2" />
              Data Management
            </Button>
            <Button
              variant="outline"
              onClick={() => setPrintModalOpen(true)}
              className="border-slate-200 dark:border-slate-800 text-slate-900 dark:text-slate-200"
            >
              <Printer className="h-4 w-4 mr-2" />
              Print Report
            </Button>
            <Button
              onClick={() => { setEditingMatter(null); setFormOpen(true); }}
              className="bg-slate-900 hover:bg-slate-800 dark:bg-slate-200 dark:hover:bg-white dark:text-black text-white shadow-sm"
            >
              <Plus className="h-4 w-4 mr-2" />
              New Matter
            </Button>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 lg:grid-cols-5 gap-3 sm:gap-4 mb-5 sm:mb-8">
          {filterCards.filter(card => card.enabled).map((card, idx) => (
            <StatsCard
              key={card.id}
              title={card.label}
              value={getFilteredCount(card.filters)}
              icon={[Briefcase, Clock, CheckCircle2, PauseCircle, Briefcase][idx % 5]}
              color={["slate", "blue", "green", "amber", "purple"][idx % 5]}
              onClick={() => handleFilterCardClick(card.filters)}
              isActive={isCardActive(card.filters)}
              multiSelect
            />
          ))}
        </div>

        {/* Filters */}
        <div className="mb-3 lg:hidden">
          <Button
            variant="outline"
            onClick={() => setShowFilters(v => !v)}
            className="w-full h-10 justify-between border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200"
          >
            <span className="flex items-center gap-2">
              <Filter className="h-4 w-4" />
              {showFilters ? "Hide filters" : "Filters"}
            </span>
            <span className="text-xs text-slate-400">{matters.length} total</span>
          </Button>
        </div>
        <div className={cn("mb-6", !showFilters && "hidden lg:block")}>
          <FilterBar
            filters={filters}
            onFilterChange={handleFilterChange}
            onClearFilters={handleClearFilters}
            clients={clients}
            properties={properties}
            matters={matters}
            instrumentTypes={instrumentTypes}
            pendingWithOptions={["All", ...pendingWithOptions]}
            statusOptions={["All Statuses", ...statusOptions]}
          />
        </div>

        {/* Table */}
                      <div id="matters-table" className="scroll-mt-4">
                      <MatterTable
                        matters={filteredMatters}
                        allMatters={matters}
                        onEdit={handleEdit}
                        onDelete={setDeletingMatter}
                        onView={handleView}
                        onQuickUpdate={handleQuickUpdate}
                        sortConfig={sortConfig}
                        onSort={handleSort}
                        activeStatusFilter={filters.status}
                        searchTerm={filters.search}
                        clients={clients}
                        properties={properties}
                        opposingParties={opposingParties}
                        partners={partners}
                        instrumentTypes={instrumentTypes}
                        pendingWithOptions={pendingWithOptions}
                        statusOptions={statusOptions}
                        customColumns={matterColumns.filter(c => c.kind === "custom")}
                        formattingRules={formattingRules}
                        onManageColumns={() => setColumnsModalOpen(true)}
                      />
                      </div>

        {/* Edit columns modal */}
                    {columnsModalOpen && (
                    <Suspense fallback={<ModalSpinner />}>
                    <ColumnManagerModal
                      open={columnsModalOpen}
                      onOpenChange={setColumnsModalOpen}
                      columns={matterColumns}
                      onCreateColumn={(data) => createColumnMutation.mutateAsync(data)}
                      onUpdateColumn={(id, data) => updateColumnMutation.mutateAsync({ id, data })}
                      onDeleteColumn={(id) => deleteColumnMutation.mutateAsync(id)}
                    />
                    </Suspense>
                    )}

        {/* Archive Modal */}
                    <ArchiveModal
                      open={archiveModalOpen}
                      onOpenChange={setArchiveModalOpen}
                      archivedMatters={archivedMatters}
                      onRestore={handleUnarchive}
                      onPermanentDelete={handlePermanentDelete}
                    />

                    {/* Print Report Modal */}
                    {printModalOpen && (
                    <Suspense fallback={<ModalSpinner />}>
                    <PrintReportModal
                                                open={printModalOpen}
                                                onOpenChange={setPrintModalOpen}
                                                matters={matters}
                                                archivedMatters={archivedMatters}
                                                properties={properties}
                                                instrumentTypes={instrumentTypes}
                                                pendingWithOptions={["All", ...pendingWithOptions]}
                                                statusOptions={statusOptions}
                                                customColumns={matterColumns.filter(c => c.kind === "custom")}
                                              />
                    </Suspense>
                    )}

        {/* Form Modal */}
        <MatterForm
                                  open={formOpen}
                                  onOpenChange={setFormOpen}
                                  matter={editingMatter}
                                  onSave={handleSave}
                                  isSaving={createMutation.isPending || updateMutation.isPending}
                                  clients={clients}
                                  properties={properties}
                                  opposingParties={opposingParties}
                                  partners={partners}
                                  instrumentTypes={instrumentTypes}
                                  assetTypes={assetTypes}
                                  matters={matters}
                      onCreateClient={(data) => createClientMutation.mutateAsync(data)}
                      onCreateProperty={(data) => createPropertyMutation.mutateAsync(data)}
                      onCreateOpposingParty={(data) => createOpposingPartyMutation.mutateAsync(data)}
                      onCreatePartner={(data) => createPartnerMutation.mutateAsync(data)}
                      onUpdateClient={(id, data) => updateClientMutation.mutateAsync({ id, data })}
                      onDeleteClient={(id) => deleteClientMutation.mutateAsync(id)}
                      onUpdateProperty={(id, data) => updatePropertyMutation.mutateAsync({ id, data })}
                      onDeleteProperty={(id) => deletePropertyMutation.mutateAsync(id)}
                      onUpdateOpposingParty={(id, data) => updateOpposingPartyMutation.mutateAsync({ id, data })}
                      onDeleteOpposingParty={(id) => deleteOpposingPartyMutation.mutateAsync(id)}
                      onUpdatePartner={(id, data) => updatePartnerMutation.mutateAsync({ id, data })}
                      onDeletePartner={(id) => deletePartnerMutation.mutateAsync(id)}
                      matterCategories={matterCategories}
                      onCreateCategory={(data) => createCategoryMutation.mutateAsync(data)}
                      onUpdateCategory={(id, data) => updateCategoryMutation.mutateAsync({ id, data })}
                      onDeleteCategory={(id) => deleteCategoryMutation.mutateAsync(id)}
                      onCreateInstrumentType={(data) => createInstrumentTypeMutation.mutateAsync(data)}
                      onUpdateInstrumentType={(id, data) => updateInstrumentTypeMutation.mutateAsync({ id, data })}
                      onDeleteInstrumentType={(id) => deleteInstrumentTypeMutation.mutateAsync(id)}
                      onCreateAssetType={(data) => createAssetTypeMutation.mutateAsync(data)}
                      onUpdateAssetType={(id, data) => updateAssetTypeMutation.mutateAsync({ id, data })}
                      onDeleteAssetType={(id) => deleteAssetTypeMutation.mutateAsync(id)}
                      leaseProvisionOptions={leaseProvisionOptions}
                      onCreateLeaseProvision={(data) => createLeaseProvisionMutation.mutateAsync(data)}
                      onUpdateLeaseProvision={(id, data) => updateLeaseProvisionMutation.mutateAsync({ id, data })}
                      onDeleteLeaseProvision={(id) => deleteLeaseProvisionMutation.mutateAsync(id)}
                      onUpdateMattersField={handleUpdateMattersField}
                    />

                    {/* List Management Modal */}
                    {listModalOpen && (
                    <Suspense fallback={<ModalSpinner />}>
                    <ListManagementModal
                      open={listModalOpen}
                      onOpenChange={setListModalOpen}
                      pendingWithRecords={pendingWithRecords}
                      onCreatePendingWith={(data) => createPendingWithMutation.mutateAsync(data)}
                      onUpdatePendingWith={(id, data) => updatePendingWithMutation.mutateAsync({ id, data })}
                      onDeletePendingWith={(id) => deletePendingWithMutation.mutateAsync(id)}
                      statusRecords={statusRecords}
                      onCreateStatus={(data) => createStatusMutation.mutateAsync(data)}
                      onUpdateStatus={(id, data) => updateStatusMutation.mutateAsync({ id, data })}
                      onDeleteStatus={(id) => deleteStatusMutation.mutateAsync(id)}
                      clients={clients}
                      properties={properties}
                      opposingParties={opposingParties}
                      partners={partners}
                      instrumentTypes={instrumentTypes}
                      assetTypes={assetTypes}
                      onCreateClient={(data) => createClientMutation.mutateAsync(data)}
                      onUpdateClient={(id, data) => updateClientMutation.mutateAsync({ id, data })}
                      onDeleteClient={(id) => deleteClientMutation.mutateAsync(id)}
                      onCreateProperty={(data) => createPropertyMutation.mutateAsync(data)}
                      onUpdateProperty={(id, data) => updatePropertyMutation.mutateAsync({ id, data })}
                      onDeleteProperty={(id) => deletePropertyMutation.mutateAsync(id)}
                      onCreateOpposingParty={(data) => createOpposingPartyMutation.mutateAsync(data)}
                      onUpdateOpposingParty={(id, data) => updateOpposingPartyMutation.mutateAsync({ id, data })}
                      onDeleteOpposingParty={(id) => deleteOpposingPartyMutation.mutateAsync(id)}
                      onCreatePartner={(data) => createPartnerMutation.mutateAsync(data)}
                      onUpdatePartner={(id, data) => updatePartnerMutation.mutateAsync({ id, data })}
                      onDeletePartner={(id) => deletePartnerMutation.mutateAsync(id)}
                      matterCategories={matterCategories}
                      onCreateCategory={(data) => createCategoryMutation.mutateAsync(data)}
                      onUpdateCategory={(id, data) => updateCategoryMutation.mutateAsync({ id, data })}
                      onDeleteCategory={(id) => deleteCategoryMutation.mutateAsync(id)}
                      onCreateInstrumentType={(data) => createInstrumentTypeMutation.mutateAsync(data)}
                      onUpdateInstrumentType={(id, data) => updateInstrumentTypeMutation.mutateAsync({ id, data })}
                      onDeleteInstrumentType={(id) => deleteInstrumentTypeMutation.mutateAsync(id)}
                      onCreateAssetType={(data) => createAssetTypeMutation.mutateAsync(data)}
                      onUpdateAssetType={(id, data) => updateAssetTypeMutation.mutateAsync({ id, data })}
                      onDeleteAssetType={(id) => deleteAssetTypeMutation.mutateAsync(id)}
                      leaseProvisionOptions={leaseProvisionOptions}
                      onCreateLeaseProvision={(data) => createLeaseProvisionMutation.mutateAsync(data)}
                      onUpdateLeaseProvision={(id, data) => updateLeaseProvisionMutation.mutateAsync({ id, data })}
                      onDeleteLeaseProvision={(id) => deleteLeaseProvisionMutation.mutateAsync(id)}
                      onUpdateMattersField={handleUpdateMattersField}
                    />
                    </Suspense>
                    )}

                    {/* Data Management Modal */}
                    {dataManagementOpen && (
                    <Suspense fallback={<ModalSpinner />}>
                    <DataManagementModal
                      open={dataManagementOpen}
                      onOpenChange={setDataManagementOpen}
                      pendingWithOptions={pendingWithOptions}
                      pendingWithRecords={pendingWithRecords}
                      onCreatePendingWith={(data) => createPendingWithMutation.mutateAsync(data)}
                      onUpdatePendingWith={(id, data) => updatePendingWithMutation.mutateAsync({ id, data })}
                      onDeletePendingWith={(id) => deletePendingWithMutation.mutateAsync(id)}
                      statusOptions={statusOptions}
                      statusRecords={statusRecords}
                      onCreateStatus={(data) => createStatusMutation.mutateAsync(data)}
                      onUpdateStatus={(id, data) => updateStatusMutation.mutateAsync({ id, data })}
                      onDeleteStatus={(id) => deleteStatusMutation.mutateAsync(id)}
                      allMatters={allMatters}
                      matters={matters}
                      archivedMatters={archivedMatters}
                      user={user}
                      formattingRules={formattingRules}
                      customColumns={matterColumns.filter(c => c.kind === "custom")}
                      onCreateFormattingRule={(data) => createFormattingRuleMutation.mutateAsync(data)}
                      onUpdateFormattingRule={(id, data) => updateFormattingRuleMutation.mutateAsync({ id, data })}
                      onDeleteFormattingRule={(id) => deleteFormattingRuleMutation.mutateAsync(id)}
                      onRestore={handleRestore}
                      onDeleteAll={handleDeleteAll}
                      clients={clients}
                      properties={properties}
                      opposingParties={opposingParties}
                      partners={partners}
                      instrumentTypes={instrumentTypes}
                      assetTypes={assetTypes}
                      onCreateClient={(data) => createClientMutation.mutateAsync(data)}
                      onUpdateClient={(id, data) => updateClientMutation.mutateAsync({ id, data })}
                      onDeleteClient={(id) => deleteClientMutation.mutateAsync(id)}
                      onCreateProperty={(data) => createPropertyMutation.mutateAsync(data)}
                      onUpdateProperty={(id, data) => updatePropertyMutation.mutateAsync({ id, data })}
                      onDeleteProperty={(id) => deletePropertyMutation.mutateAsync(id)}
                      onCreateOpposingParty={(data) => createOpposingPartyMutation.mutateAsync(data)}
                      onUpdateOpposingParty={(id, data) => updateOpposingPartyMutation.mutateAsync({ id, data })}
                      onDeleteOpposingParty={(id) => deleteOpposingPartyMutation.mutateAsync(id)}
                      onCreatePartner={(data) => createPartnerMutation.mutateAsync(data)}
                      onUpdatePartner={(id, data) => updatePartnerMutation.mutateAsync({ id, data })}
                      onDeletePartner={(id) => deletePartnerMutation.mutateAsync(id)}
                      matterCategories={matterCategories}
                      onCreateCategory={(data) => createCategoryMutation.mutateAsync(data)}
                      onUpdateCategory={(id, data) => updateCategoryMutation.mutateAsync({ id, data })}
                      onDeleteCategory={(id) => deleteCategoryMutation.mutateAsync(id)}
                      onCreateInstrumentType={(data) => createInstrumentTypeMutation.mutateAsync(data)}
                      onUpdateInstrumentType={(id, data) => updateInstrumentTypeMutation.mutateAsync({ id, data })}
                      onDeleteInstrumentType={(id) => deleteInstrumentTypeMutation.mutateAsync(id)}
                      onCreateAssetType={(data) => createAssetTypeMutation.mutateAsync(data)}
                      onUpdateAssetType={(id, data) => updateAssetTypeMutation.mutateAsync({ id, data })}
                      onDeleteAssetType={(id) => deleteAssetTypeMutation.mutateAsync(id)}
                      leaseProvisionOptions={leaseProvisionOptions}
                      onCreateLeaseProvision={(data) => createLeaseProvisionMutation.mutateAsync(data)}
                      onUpdateLeaseProvision={(id, data) => updateLeaseProvisionMutation.mutateAsync({ id, data })}
                      onDeleteLeaseProvision={(id) => deleteLeaseProvisionMutation.mutateAsync(id)}
                      onUpdateMattersField={handleUpdateMattersField}
                    />
                    </Suspense>
                    )}

        {/* Detail Sheet */}
        <MatterDetail
          matter={viewingMatter}
          open={!!viewingMatter}
          onOpenChange={(open) => !open && setViewingMatter(null)}
          onEdit={handleEdit}
        />

        {/* Update Notice */}
        <AlertDialog open={showUpdateNotice} onOpenChange={setShowUpdateNotice}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>App Updated</AlertDialogTitle>
              <AlertDialogDescription className="space-y-3">
                <p>The Matter Tracker has been updated. Please take a moment to:</p>
                <ul className="list-disc list-inside space-y-1 text-sm">
                  <li>Perform a backup of your data</li>
                  <li>Review your filter cards in Data Management</li>
                  <li>Check your matter table for proper organization</li>
                </ul>
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogAction onClick={() => setShowUpdateNotice(false)}>
                Got it
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>

        {/* Archive Confirmation */}
                    <AlertDialog open={!!deletingMatter} onOpenChange={(open) => !open && setDeletingMatter(null)}>
                      <AlertDialogContent>
                        <AlertDialogHeader>
                          <AlertDialogTitle>Archive Matter</AlertDialogTitle>
                          <AlertDialogDescription>
                            Are you sure you want to archive this matter for "{deletingMatter?.client_name}"? 
                            You can restore it later from the Archive.
                          </AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                          <AlertDialogCancel>Cancel</AlertDialogCancel>
                          <AlertDialogAction
                            onClick={() => handleArchive(deletingMatter)}
                            className="bg-amber-600 hover:bg-amber-700"
                          >
                            {archiveMutation.isPending ? "Archiving..." : "Archive"}
                          </AlertDialogAction>
                        </AlertDialogFooter>
                      </AlertDialogContent>
                    </AlertDialog>
        </div>
        <div className="h-16 sm:hidden" />
      </div>
    </PasscodeGate>
  );
}