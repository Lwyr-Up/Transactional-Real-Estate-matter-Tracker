import React from 'react'
import ReactDOM from 'react-dom/client'
import App from '@/App.jsx'
import '@/index.css'
import { requestPersistentStorage } from '@/api/localDb'

ReactDOM.createRoot(document.getElementById('root')).render(<App />)

// Ask the browser to keep this app's data and not evict it when space is low.
requestPersistentStorage()

// Offline support: cache the app so it launches with no connection.
if ('serviceWorker' in navigator && import.meta.env.PROD) {
  window.addEventListener('load', () => {
    navigator.serviceWorker
      .register(`${import.meta.env.BASE_URL}sw.js`)
      .catch((err) => console.warn('Service worker registration failed:', err));
  });
}
