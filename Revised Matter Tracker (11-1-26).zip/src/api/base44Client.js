// Local-only replacement for the Base44 client.
// The rest of the app still imports `base44` from here, but everything now
// runs against this device's IndexedDB. Nothing is sent over the network.
import { entities, LOCAL_USER } from "./localDb";

export const base44 = {
  entities,
  auth: {
    me: async () => LOCAL_USER,
    logout: () => {},
    redirectToLogin: () => {},
    isAuthenticated: async () => true,
  },
};
