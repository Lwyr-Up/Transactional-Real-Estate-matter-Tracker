import { useEffect, useRef, useState } from "react";
import { ArrowDown, Loader2 } from "lucide-react";
import { cn } from "@/lib/utils";

const THRESHOLD = 70;
const MAX_PULL = 110;

export default function PullToRefresh({ onRefresh }) {
  const [pull, setPull] = useState(0);
  const [refreshing, setRefreshing] = useState(false);
  const gesture = useRef({ active: false, startX: 0, startY: 0, pull: 0 });
  const busy = useRef(false);

  useEffect(() => {
    const reset = () => {
      gesture.current.active = false;
      gesture.current.pull = 0;
      setPull(0);
    };

    const handleStart = (event) => {
      // Portaled report controls scroll independently of the dashboard. A pull
      // inside them must never start the page-level refresh gesture.
      const inDialog = event.target instanceof Element && event.target.closest(
        '[role="dialog"], [role="alertdialog"], [data-radix-popper-content-wrapper]'
      );
      if (busy.current || window.scrollY > 0 || event.touches.length !== 1 || inDialog) {
        reset();
        return;
      }
      const touch = event.touches[0];
      gesture.current = { active: true, startX: touch.clientX, startY: touch.clientY, pull: 0 };
    };

    const handleMove = (event) => {
      const state = gesture.current;
      if (!state.active || busy.current) return;
      const touch = event.touches[0];
      const dy = touch.clientY - state.startY;
      const dx = touch.clientX - state.startX;
      // Leave upward scrolling and horizontal card swipes alone.
      if (dy <= 0 || Math.abs(dx) > Math.abs(dy) || window.scrollY > 0) {
        reset();
        return;
      }
      const distance = Math.min(dy * 0.5, MAX_PULL);
      state.pull = distance;
      setPull(distance);
      if (event.cancelable) event.preventDefault();
    };

    const handleEnd = async () => {
      const state = gesture.current;
      if (!state.active) return;
      const distance = state.pull;
      state.active = false;
      if (distance < THRESHOLD) {
        setPull(0);
        return;
      }
      busy.current = true;
      setRefreshing(true);
      setPull(THRESHOLD);
      try {
        await onRefresh?.();
      } finally {
        busy.current = false;
        setRefreshing(false);
        setPull(0);
      }
    };

    window.addEventListener("touchstart", handleStart, { passive: true });
    window.addEventListener("touchmove", handleMove, { passive: false });
    window.addEventListener("touchend", handleEnd);
    window.addEventListener("touchcancel", reset);
    return () => {
      window.removeEventListener("touchstart", handleStart);
      window.removeEventListener("touchmove", handleMove);
      window.removeEventListener("touchend", handleEnd);
      window.removeEventListener("touchcancel", reset);
    };
  }, [onRefresh]);

  const visible = refreshing || pull > 6;
  const progress = Math.min(pull / THRESHOLD, 1);

  return (
    <div
      aria-hidden={!visible}
      className="pointer-events-none fixed inset-x-0 top-0 z-50 flex justify-center"
      style={{ paddingTop: "calc(env(safe-area-inset-top, 0px) + 6px)" }}
    >
      <div
        className={cn(
          "flex h-9 w-9 items-center justify-center rounded-full border border-slate-200 bg-white text-slate-500 shadow-sm transition-opacity dark:border-slate-700 dark:bg-slate-900 dark:text-slate-300",
          visible ? "opacity-100" : "opacity-0"
        )}
        style={{ transform: `translateY(${Math.min(pull, 40)}px)` }}
      >
        {refreshing ? (
          <Loader2 className="h-4 w-4 animate-spin" />
        ) : (
          <ArrowDown className="h-4 w-4" style={{ transform: `rotate(${progress * 180}deg)` }} />
        )}
      </div>
    </div>
  );
}