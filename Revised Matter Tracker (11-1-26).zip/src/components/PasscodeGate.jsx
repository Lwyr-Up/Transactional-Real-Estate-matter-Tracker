import { useState } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Lock } from "lucide-react";
import { toast } from "sonner";
import { hasPin, verifyPin } from "@/lib/pin";

// Optional on-device PIN lock. If no PIN has been set (Data Management >
// Security), the app opens straight away. Once a PIN is set, it is asked for
// each time the app is launched.
export default function PasscodeGate({ children }) {
  const [unlocked, setUnlocked] = useState(() => !hasPin());
  const [value, setValue] = useState("");
  const [busy, setBusy] = useState(false);

  const submit = async () => {
    setBusy(true);
    const ok = await verifyPin(value);
    setBusy(false);
    if (ok) {
      setUnlocked(true);
      setValue("");
    } else {
      toast.error("Incorrect PIN");
      setValue("");
    }
  };

  if (unlocked) return children;

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-black flex items-center justify-center p-6">
      <div className="max-w-sm w-full bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 p-8 text-center shadow-lg space-y-5">
        <div className="w-16 h-16 bg-slate-100 dark:bg-slate-800 rounded-full flex items-center justify-center mx-auto">
          <Lock className="h-8 w-8 text-slate-500" />
        </div>
        <h2 className="text-xl font-semibold text-slate-900 dark:text-slate-100">Enter PIN</h2>
        <Input
          type="password"
          inputMode="numeric"
          autoFocus
          value={value}
          onChange={(e) => setValue(e.target.value.replace(/\D/g, ""))}
          onKeyDown={(e) => e.key === "Enter" && value.length >= 4 && submit()}
          placeholder="PIN"
          className="text-center text-2xl tracking-widest"
        />
        <Button onClick={submit} disabled={busy || value.length < 4} className="w-full">
          Unlock
        </Button>
      </div>
    </div>
  );
}


