import { useState } from "react";
import { Button } from "@/components/ui/button";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Trash2, Loader2 } from "lucide-react";
import { eraseAllData } from "@/api/localDb";

// Local-only replacement for "Delete Account": there is no account, so this
// erases everything stored on this device (matters, lists, rules, columns).
export default function DeleteAccountDialog() {
  const [open, setOpen] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const [confirmed, setConfirmed] = useState(false);
  const [error, setError] = useState("");

  const handleErase = async () => {
    setError("");
    setDeleting(true);
    try {
      await eraseAllData();
      window.location.reload();
    } catch (err) {
      setError(err?.message || "The data could not be erased. Please try again.");
      setDeleting(false);
    }
  };

  return (
    <AlertDialog
      open={open}
      onOpenChange={(next) => {
        if (deleting) return;
        setOpen(next);
        setConfirmed(false);
        setError("");
      }}
    >
      <AlertDialogTrigger asChild>
        <Button
          variant="outline"
          className="border-red-200 text-red-600 hover:bg-red-50 hover:text-red-700 dark:border-red-900 dark:text-red-400 dark:hover:bg-red-950 dark:hover:text-red-300"
        >
          <Trash2 className="h-4 w-4 mr-2" />
          Erase All Data
        </Button>
      </AlertDialogTrigger>
      <AlertDialogContent>
        <AlertDialogHeader>
          <AlertDialogTitle>Erase all data on this device?</AlertDialogTitle>
          <AlertDialogDescription>
            This permanently erases every matter, list, category, column and formatting rule stored in this app on
            this device. It cannot be undone. Save a full backup to iCloud first if you want to keep a copy.
          </AlertDialogDescription>
        </AlertDialogHeader>
        <label className="flex items-start gap-2 text-sm text-slate-700 dark:text-slate-300">
          <input
            type="checkbox"
            checked={confirmed}
            onChange={(e) => setConfirmed(e.target.checked)}
            className="mt-1"
          />
          I have saved a backup and want to erase everything.
        </label>
        {error && <p className="text-sm text-red-600 dark:text-red-400">{error}</p>}
        <AlertDialogFooter>
          <AlertDialogCancel disabled={deleting}>Cancel</AlertDialogCancel>
          <AlertDialogAction
            onClick={(event) => {
              event.preventDefault();
              handleErase();
            }}
            disabled={deleting || !confirmed}
            className="bg-red-600 text-white hover:bg-red-700"
          >
            {deleting ? (
              <>
                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                Erasing
              </>
            ) : (
              "Erase Everything"
            )}
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
}
