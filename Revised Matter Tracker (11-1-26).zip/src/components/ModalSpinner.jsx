import { Loader2 } from "lucide-react";

export default function ModalSpinner() {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/10">
      <Loader2 className="h-6 w-6 animate-spin text-slate-500 dark:text-slate-300" />
    </div>
  );
}