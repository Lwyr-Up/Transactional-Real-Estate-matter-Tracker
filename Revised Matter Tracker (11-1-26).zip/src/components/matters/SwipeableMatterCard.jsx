import { useRef, useState } from "react";
import { Archive, Eye, Pencil } from "lucide-react";
import { cn } from "@/lib/utils";

const MAX_OFFSET = 128;
const TRIGGER = 96;

// Actions a swipe can reveal. A direction set to "none" cannot be dragged.
const ACTION_META = {
  archive: { label: "Archive", Icon: Archive, tone: "bg-slate-600" },
  edit: { label: "Edit", Icon: Pencil, tone: "bg-blue-600" },
  details: { label: "Details", Icon: Eye, tone: "bg-emerald-600" },
};

/**
 * Wraps a mobile matter card and lets it be swiped left or right.
 * Swiping right (card slides right) fires rightAction, swiping left fires leftAction.
 * Vertical scrolling keeps working; taps and inline editors are left untouched.
 */
export default function SwipeableMatterCard({
  children,
  leftAction = "archive",
  rightAction = "edit",
  onAction,
}) {
  const [offset, setOffset] = useState(0);
  const [dragging, setDragging] = useState(false);
  const startRef = useRef(null);
  const offsetRef = useRef(0);

  const setDragOffset = (value) => {
    offsetRef.current = value;
    setOffset(value);
  };

  const isInteractive = (el) =>
    el?.closest?.(
      'input, select, textarea, button, a, [contenteditable="true"], [role="combobox"], [role="button"], [data-no-swipe]'
    );

  const handlePointerDown = (e) => {
    if (e.pointerType === "mouse") return;
    if (isInteractive(e.target)) return;
    startRef.current = { x: e.clientX, y: e.clientY, horizontal: null };
  };

  const handlePointerMove = (e) => {
    const start = startRef.current;
    if (!start) return;
    const dx = e.clientX - start.x;
    const dy = e.clientY - start.y;

    if (start.horizontal === null) {
      if (Math.abs(dx) < 6 && Math.abs(dy) < 6) return;
      start.horizontal = Math.abs(dx) > Math.abs(dy) * 1.2;
      if (!start.horizontal) {
        startRef.current = null;
        return;
      }
      setDragging(true);
    }

    let next = Math.max(-MAX_OFFSET, Math.min(MAX_OFFSET, dx));
    if (next > 0 && !ACTION_META[rightAction]) next = 0;
    if (next < 0 && !ACTION_META[leftAction]) next = 0;
    setDragOffset(next);
  };

  const endSwipe = () => {
    const start = startRef.current;
    startRef.current = null;
    const value = offsetRef.current;
    const wasHorizontal = !!start?.horizontal;
    const action = value > 0 ? rightAction : leftAction;

    setDragging(false);
    setDragOffset(0);

    if (wasHorizontal && Math.abs(value) >= TRIGGER && ACTION_META[action]) onAction?.(action);
  };

  const side = offset > 0 ? "right" : "left";
  const meta = ACTION_META[offset > 0 ? rightAction : leftAction];
  const progress = meta ? Math.min(1, Math.abs(offset) / TRIGGER) : 0;
  const RevealIcon = meta?.Icon;

  return (
    <div
      className="relative overflow-hidden touch-pan-y"
      onPointerDown={handlePointerDown}
      onPointerMove={handlePointerMove}
      onPointerUp={endSwipe}
      onPointerCancel={endSwipe}
    >
      {meta && (
        <div
          aria-hidden={progress === 0}
          className={cn(
            "pointer-events-none absolute inset-0 flex items-center px-5 text-white",
            meta.tone,
            side === "right" ? "justify-start" : "justify-end"
          )}
          style={{ opacity: progress }}
        >
          <span className="flex items-center gap-2 text-sm font-semibold">
            {side === "right" && <RevealIcon className="h-4 w-4" />}
            {meta.label}
            {side === "left" && <RevealIcon className="h-4 w-4" />}
          </span>
        </div>
      )}

      <div
        className={cn("relative bg-white dark:bg-slate-950", dragging && "shadow-lg")}
        style={{
          transform: `translateX(${offset}px)`,
          transition: dragging ? "none" : "transform 180ms ease-out",
        }}
      >
        {children}
      </div>
    </div>
  );
}