import { Card } from "@/components/ui/card";
import { cn } from "@/lib/utils";

export default function StatsCard({ title, value, subtitle, icon: Icon, color = "blue", onClick, isActive, multiSelect, onIconClick }) {
  const colorClasses = {
    blue: "bg-blue-50 text-blue-600 dark:bg-blue-950 dark:text-blue-400",
    green: "bg-emerald-50 text-emerald-600 dark:bg-emerald-950 dark:text-emerald-400",
    amber: "bg-amber-50 text-amber-600 dark:bg-amber-950 dark:text-amber-400",
    slate: "bg-slate-100 text-slate-600 dark:bg-slate-900 dark:text-slate-400",
    purple: "bg-purple-50 text-purple-600 dark:bg-purple-950 dark:text-purple-400"
  };

  return (
    <Card 
      className={cn(
        "p-3 sm:p-5 border-0 shadow-sm bg-white dark:bg-black hover:shadow-md transition-all duration-300",
        onClick && 'cursor-pointer',
        isActive && (multiSelect ? 'ring-2 ring-blue-500 ring-offset-2' : 'ring-2 ring-slate-900 dark:ring-slate-200 ring-offset-2')
      )}
      onClick={onClick}
    >
      <div className="flex items-start justify-between">
        <div>
          <p className="text-[11px] font-medium text-slate-500 dark:text-slate-400 tracking-wide uppercase sm:text-sm">
            {title}
          </p>
          <p className="mt-1 text-2xl font-semibold text-slate-900 dark:text-slate-100 sm:mt-2 sm:text-3xl">
            {value}
          </p>
          {subtitle && (
            <p className="mt-1 text-xs text-slate-500 dark:text-slate-400 sm:text-sm">{subtitle}</p>
          )}
        </div>
        {Icon && (
          onIconClick ? (
            <button
              type="button"
              title="Edit this card's setup"
              onClick={(e) => { e.stopPropagation(); onIconClick(); }}
              className={cn(
                "rounded-xl p-2 transition-transform hover:scale-105 active:scale-95 sm:p-3",
                colorClasses[color]
              )}
            >
              <Icon className="h-4 w-4 sm:h-5 sm:w-5" />
            </button>
          ) : (
            <div className={cn("rounded-xl p-2 sm:p-3", colorClasses[color])}>
              <Icon className="h-4 w-4 sm:h-5 sm:w-5" />
            </div>
          )
        )}
      </div>
    </Card>
  );
}