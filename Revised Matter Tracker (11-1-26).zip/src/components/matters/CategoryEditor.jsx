import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Pencil, Trash2, Plus, Check, X, Loader2 } from "lucide-react";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";

export default function CategoryEditor({ items = [], onCreate, onUpdate, onDelete, onUpdateMattersField }) {
  const [editingId, setEditingId] = useState(null);
  const [editValue, setEditValue] = useState("");
  const [newValue, setNewValue] = useState("");
  const [isAdding, setIsAdding] = useState(false);
  const [deleteItem, setDeleteItem] = useState(null);
  const [duplicateAlert, setDuplicateAlert] = useState(null);

  const sorted = [...items].sort((a, b) => (a.position ?? 99) - (b.position ?? 99));

  const checkDuplicate = (value, excludeId = null) =>
    items.find(item => item.name.trim().toLowerCase() === value.trim().toLowerCase() && item.id !== excludeId);

  const handleAdd = async () => {
    if (!newValue.trim()) return;
    const duplicate = checkDuplicate(newValue);
    if (duplicate) {
      setDuplicateAlert({ existingValue: duplicate.name });
      setNewValue("");
      return;
    }
    setIsAdding(true);
    await onCreate({ name: newValue.trim(), lease_fields: false, position: items.length + 1 });
    setNewValue("");
    setIsAdding(false);
  };

  const handleSaveEdit = async (item) => {
    if (editValue.trim()) {
      const duplicate = checkDuplicate(editValue, item.id);
      if (duplicate) {
        setDuplicateAlert({ existingValue: duplicate.name });
        setEditingId(null);
        setEditValue("");
        return;
      }
      const oldValue = item.name;
      const newName = editValue.trim();
      await onUpdate(item.id, { name: newName });
      if (onUpdateMattersField && oldValue !== newName) {
        await onUpdateMattersField("matter_category", oldValue, newName);
      }
    }
    setEditingId(null);
    setEditValue("");
  };

  const handleDelete = async () => {
    if (deleteItem) {
      await onDelete(deleteItem.id);
      setDeleteItem(null);
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex gap-2">
        <Input
          value={newValue}
          onChange={(e) => setNewValue(e.target.value)}
          placeholder="Add new category..."
          onKeyDown={(e) => e.key === 'Enter' && handleAdd()}
          className="flex-1 bg-white text-slate-900 placeholder:text-slate-500 dark:bg-slate-950 dark:text-slate-200 dark:placeholder:text-slate-500 dark:border-slate-800"
        />
        <Button onClick={handleAdd} disabled={!newValue.trim() || isAdding} size="sm">
          {isAdding ? <Loader2 className="h-4 w-4 animate-spin" /> : <Plus className="h-4 w-4" />}
        </Button>
      </div>

      <p className="text-xs text-slate-500 dark:text-slate-400">
        Turn on "Leasing fields" for categories that should show asset type, sublease details and lease metrics.
      </p>

      <div className="border rounded-lg divide-y max-h-[300px] overflow-y-auto dark:border-slate-800">
        {sorted.length === 0 ? (
          <div className="p-4 text-center text-slate-600 dark:text-slate-400 text-sm">No categories added yet</div>
        ) : (
          sorted.map((item) => (
            <div key={item.id} className="p-3 space-y-2 hover:bg-slate-50 dark:hover:bg-slate-900">
              {editingId === item.id ? (
                <div className="flex items-center gap-2">
                  <Input
                    value={editValue}
                    onChange={(e) => setEditValue(e.target.value)}
                    className="flex-1 h-8 bg-white text-slate-900 placeholder:text-slate-500 dark:bg-slate-950 dark:text-slate-200 dark:placeholder:text-slate-500 dark:border-slate-800"
                    autoFocus
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') handleSaveEdit(item);
                      if (e.key === 'Escape') { setEditingId(null); setEditValue(""); }
                    }}
                  />
                  <Button size="icon" variant="ghost" className="h-8 w-8 text-green-600" onClick={() => handleSaveEdit(item)}>
                    <Check className="h-4 w-4" />
                  </Button>
                  <Button size="icon" variant="ghost" className="h-8 w-8 text-slate-400" onClick={() => { setEditingId(null); setEditValue(""); }}>
                    <X className="h-4 w-4" />
                  </Button>
                </div>
              ) : (
                <div className="flex items-center justify-between gap-2">
                  <span className="text-sm text-slate-900 dark:text-slate-200">{item.name}</span>
                  <div className="flex items-center gap-1">
                    <Button
                      size="icon"
                      variant="ghost"
                      className="h-8 w-8 text-slate-400 hover:text-slate-600"
                      onClick={() => { setEditingId(item.id); setEditValue(item.name); }}
                    >
                      <Pencil className="h-3.5 w-3.5" />
                    </Button>
                    <Button
                      size="icon"
                      variant="ghost"
                      className="h-8 w-8 text-slate-400 hover:text-red-600"
                      onClick={() => setDeleteItem(item)}
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </Button>
                  </div>
                </div>
              )}
              <div className="flex items-center gap-2">
                <Switch
                  id={`lease_fields_${item.id}`}
                  checked={!!item.lease_fields}
                  onCheckedChange={(checked) => onUpdate(item.id, { lease_fields: checked })}
                />
                <Label htmlFor={`lease_fields_${item.id}`} className="text-xs font-normal text-slate-500 dark:text-slate-400 cursor-pointer">
                  Leasing fields
                </Label>
              </div>
            </div>
          ))
        )}
      </div>

      <AlertDialog open={!!deleteItem} onOpenChange={(open) => !open && setDeleteItem(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Remove Category?</AlertDialogTitle>
            <AlertDialogDescription>
              This will remove "{deleteItem?.name}" from the list. Matters already using it keep their category name.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-red-600 hover:bg-red-700">
              Remove
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <AlertDialog open={!!duplicateAlert} onOpenChange={(open) => !open && setDuplicateAlert(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Duplicate Entry</AlertDialogTitle>
            <AlertDialogDescription>
              This category already exists: "{duplicateAlert?.existingValue}"
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogAction onClick={() => setDuplicateAlert(null)}>OK</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}