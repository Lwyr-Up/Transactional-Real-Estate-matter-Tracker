import { format } from "date-fns";
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Label } from "@/components/ui/label";
import { Pencil, Building2, User, Users, FileText, Calendar, Clock, MessageSquare, Ruler, CheckCircle2, XCircle, ChevronLeft } from "lucide-react";
import { motion } from "framer-motion";
import { cn } from "@/lib/utils";
import { isMobileViewport } from "@/lib/isMobileViewport";



const statusColors = {
  Open: "bg-emerald-50 text-emerald-700 border-emerald-200 dark:bg-emerald-950 dark:text-emerald-400 dark:border-emerald-900",
  Closed: "bg-slate-100 text-slate-600 border-slate-200 dark:bg-slate-900 dark:text-slate-400 dark:border-slate-800",
  "Deal Died": "bg-red-50 text-red-700 border-red-200 dark:bg-red-950 dark:text-red-400 dark:border-red-900",
  "On Hold": "bg-amber-50 text-amber-700 border-amber-200 dark:bg-amber-950 dark:text-amber-400 dark:border-amber-900",
  "Pending Execution": "bg-yellow-50 text-yellow-700 border-yellow-200 dark:bg-yellow-950 dark:text-yellow-400 dark:border-yellow-900"
};

const pendingColors = {
  Tenant: "bg-blue-50 text-blue-700 border-blue-200 dark:bg-blue-950 dark:text-blue-400 dark:border-blue-900",
  Landlord: "bg-purple-50 text-purple-700 border-purple-200 dark:bg-purple-950 dark:text-purple-400 dark:border-purple-900",
  Client: "bg-cyan-50 text-cyan-700 border-cyan-200 dark:bg-cyan-950 dark:text-cyan-400 dark:border-cyan-900",
  Rob: "bg-rose-50 text-rose-700 border-rose-200 dark:bg-rose-950 dark:text-rose-400 dark:border-rose-900",
  "Pending Internal Review": "bg-purple-50 text-purple-700 border-purple-200 dark:bg-purple-950 dark:text-purple-400 dark:border-purple-900"
};

export default function MatterDetail({ matter, open, onOpenChange, onEdit }) {
  if (!matter) return null;

  const formatDate = (dateString) => {
    if (!dateString) return "Not set";
    return format(new Date(dateString), "MMMM d, yyyy");
  };

  const DetailRow = ({ icon: Icon, label, value, badge, badgeColor }) => (
    <div className="flex items-start gap-4 py-4">
      <div className="p-2 bg-slate-100 dark:bg-slate-900 rounded-lg">
        <Icon className="h-4 w-4 text-slate-500 dark:text-slate-400" />
      </div>
      <div className="flex-1">
        <p className="text-sm text-slate-500 dark:text-slate-400 mb-1">{label}</p>
        {badge ? (
          <Badge variant="outline" className={cn("font-medium", badgeColor)}>
            {value}
          </Badge>
        ) : (
          <p className="font-medium text-slate-900 dark:text-slate-100">{value}</p>
        )}
      </div>
    </div>
  );

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent
        className="w-full sm:max-w-lg overflow-y-auto dark:bg-slate-950 dark:border-slate-800"
        style={{ paddingBottom: "env(safe-area-inset-bottom)" }}
      >
        <motion.div
          initial={isMobileViewport() ? { x: 56, opacity: 0 } : false}
          animate={{ x: 0, opacity: 1 }}
          transition={{ duration: 0.22, ease: "easeOut" }}
        >
        <SheetHeader className="pb-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-1">
              <Button
                variant="ghost"
                size="icon"
                onClick={() => onOpenChange(false)}
                aria-label="Back"
                className="sm:hidden -ml-2 text-slate-500 dark:text-slate-400"
              >
                <ChevronLeft className="h-5 w-5" />
              </Button>
              <SheetTitle className="text-xl font-semibold text-slate-900 dark:text-slate-100">
                Matter Details
              </SheetTitle>
            </div>
            <Button 
              variant="outline" 
              size="sm"
              onClick={() => onEdit(matter)}
              className="border-slate-200 dark:border-slate-800 dark:bg-slate-900 dark:text-slate-200"
            >
              <Pencil className="h-4 w-4 mr-2" />
              Edit
            </Button>
          </div>
        </SheetHeader>

        <div className="space-y-1">
          <DetailRow
            icon={User}
            label="Client Name"
            value={matter.client_name}
          />
          <Separator className="dark:bg-slate-800" />

          {matter.assigned_partner && (
            <>
              <DetailRow
                icon={Users}
                label="Assigned Partner"
                value={matter.assigned_partner}
              />
              <Separator className="dark:bg-slate-800" />
            </>
          )}
          
          <DetailRow
            icon={Building2}
            label="Property Address"
            value={matter.property_address}
          />
          <Separator className="dark:bg-slate-800" />

          {matter.opposing_party && (
            <>
              <DetailRow
                icon={Users}
                label="Opposing Party"
                value={matter.opposing_party}
              />
              <Separator className="dark:bg-slate-800" />
            </>
          )}

          <DetailRow
            icon={FileText}
            label="Instrument Type"
            value={matter.instrument_type === "Other" && matter.instrument_type_other ? `${matter.instrument_type} (${matter.instrument_type_other})` : matter.instrument_type}
          />
          <Separator className="dark:bg-slate-800" />

          <DetailRow
            icon={Clock}
            label="Pending With"
            value={matter.pending_with}
            badge
            badgeColor={pendingColors[matter.pending_with]}
          />
          <Separator className="dark:bg-slate-800" />

          <div className="flex items-start gap-4 py-4">
            <div className="p-2 bg-slate-100 dark:bg-slate-900 rounded-lg">
              <FileText className="h-4 w-4 text-slate-500 dark:text-slate-400" />
            </div>
            <div className="flex-1">
              <p className="text-sm text-slate-500 dark:text-slate-400 mb-1">Status</p>
              <Badge variant="outline" className={cn("font-medium", statusColors[matter.status])}>
                {matter.status}
              </Badge>
            </div>
          </div>
          <Separator className="dark:bg-slate-800" />

          <DetailRow
            icon={Calendar}
            label="Date Received"
            value={formatDate(matter.date_received)}
          />
          <Separator className="dark:bg-slate-800" />

          <DetailRow
            icon={Calendar}
            label="Date Closed"
            value={matter.date_closed ? formatDate(matter.date_closed) : "Still Open"}
          />
          <Separator className="dark:bg-slate-800" />

          <DetailRow
            icon={Clock}
            label="Last Updated"
            value={formatDate(matter.updated_date)}
          />

          {matter.comments && (
            <>
              <Separator className="dark:bg-slate-800" />
              <div className="py-4">
                <div className="flex items-center gap-2 mb-3">
                  <div className="p-2 bg-slate-100 dark:bg-slate-900 rounded-lg">
                    <MessageSquare className="h-4 w-4 text-slate-500 dark:text-slate-400" />
                  </div>
                  <p className="text-sm text-slate-500 dark:text-slate-400">Comments</p>
                </div>
                <div className="bg-slate-50 dark:bg-slate-900 rounded-lg p-4">
                  <p className="text-slate-700 dark:text-slate-300 whitespace-pre-wrap">{matter.comments}</p>
                </div>
              </div>
            </>
          )}

          {/* Lease Metrics Section */}
          {(matter.rentable_sqft || matter.lease_term_months || 
            matter.has_extension_option || matter.has_right_of_first_offer || 
            matter.has_right_of_first_refusal || matter.has_expansion_option || 
            matter.has_termination_option || matter.has_parking ||
            (matter.lease_provisions || []).length > 0) && (
            <>
              <Separator className="dark:bg-slate-800" />
              <div className="py-4">
                <div className="flex items-center gap-2 mb-4">
                  <div className="p-2 bg-slate-100 dark:bg-slate-900 rounded-lg">
                    <Ruler className="h-4 w-4 text-slate-500 dark:text-slate-400" />
                  </div>
                  <p className="text-sm font-medium text-slate-700 dark:text-slate-300">Lease Metrics</p>
                </div>
                
                {(matter.rentable_sqft || matter.lease_term_months) && (
                  <div className="grid grid-cols-2 gap-4 mb-4">
                    {matter.rentable_sqft && (
                      <div className="bg-slate-50 dark:bg-slate-900 rounded-lg p-3">
                        <p className="text-xs text-slate-500 dark:text-slate-400 mb-1">Rentable SF</p>
                        <p className="font-semibold text-slate-900 dark:text-slate-100">
                          {matter.rentable_sqft.toLocaleString()} SF
                        </p>
                      </div>
                    )}
                    {matter.lease_term_months && (
                      <div className="bg-slate-50 dark:bg-slate-900 rounded-lg p-3">
                        <p className="text-xs text-slate-500 dark:text-slate-400 mb-1">Lease Term</p>
                        <p className="font-semibold text-slate-900 dark:text-slate-100">
                          {matter.lease_term_months} months
                        </p>
                      </div>
                    )}
                  </div>
                )}

                <div className="space-y-2">
                  <p className="text-xs text-slate-500 dark:text-slate-400 mb-2">Lease Provisions</p>
                  <div className="grid grid-cols-1 gap-2">
                    {[
                      { key: 'has_expansion_option', label: 'Expansion Option' },
                      { key: 'has_extension_option', label: 'Extension Option' },
                      { key: 'has_parking', label: 'Parking' },
                      { key: 'has_right_of_first_offer', label: 'Right of First Offer' },
                      { key: 'has_right_of_first_refusal', label: 'Right of First Refusal' },
                      { key: 'has_termination_option', label: 'Termination Option' }
                    ].map(({ key, label }) => (
                      <div key={key} className="flex items-center gap-2">
                        {matter[key] ? (
                          <CheckCircle2 className="h-4 w-4 text-emerald-500 dark:text-emerald-400" />
                        ) : (
                          <XCircle className="h-4 w-4 text-slate-300 dark:text-slate-700" />
                        )}
                        <span className={cn(
                          "text-sm",
                          matter[key] ? "text-slate-700 dark:text-slate-300" : "text-slate-400 dark:text-slate-600"
                        )}>
                          {label}
                        </span>
                      </div>
                    ))}
                    {(matter.lease_provisions || [])
                      .filter((name) => ![
                        "Expansion Option", "Extension Option", "Parking",
                        "Right of First Offer", "Right of First Refusal", "Termination Option"
                      ].includes(name))
                      .map((name) => (
                        <div key={name} className="flex items-center gap-2">
                          <CheckCircle2 className="h-4 w-4 text-emerald-500 dark:text-emerald-400" />
                          <span className="text-sm text-slate-700 dark:text-slate-300">{name}</span>
                        </div>
                      ))}
                  </div>
                </div>
              </div>
            </>
          )}
        </div>
        </motion.div>
      </SheetContent>
    </Sheet>
  );
}