import { Fragment, useState, useEffect, useMemo } from "react";
import { DragDropContext, Droppable, Draggable } from "@hello-pangea/dnd";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger,
  DropdownMenuCheckboxItem, DropdownMenuLabel, DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu";
import {
  MoreHorizontal, Pencil, Trash2, Eye, ArrowUpDown, ArrowUp, ArrowDown,
  Settings2, GripVertical, SlidersHorizontal,
} from "lucide-react";
import { cn } from "@/lib/utils";
import EditableCommentCell from "@/components/matters/EditableCommentCell";
import MobileMatterList from "@/components/matters/MobileMatterList";
import { useTableView } from "@/hooks/useTableView";
import RelatedMattersToggle from "@/components/matters/RelatedMattersToggle";
import RelatedMatterList from "@/components/matters/RelatedMatterList";
import { buildRelatedMatters } from "@/lib/relatedMatters";
import {
  EditableTextCell, EditableNumberCell, EditableSelectCell, EditableDateCell,
} from "@/components/matters/EditableCells";
import {
  DEFAULT_COLUMNS, DEFAULT_WIDTHS, INSTRUMENT_TYPES, PENDING_WITH_OPTIONS,
  STATUS_OPTIONS, SUBLEASE_TERM_TYPES, STATUS_COLORS, PENDING_COLORS,
  getLeaseProvisions,
} from "@/lib/matterColumns";
import { getCellFormat, getRowFormat } from "@/lib/formattingRules";

export default function MatterTable({
  matters,
  onEdit,
  onDelete,
  onView,
  onQuickUpdate,
  sortConfig,
  onSort,
  activeStatusFilter,
  searchTerm = "",
  clients = [],
  properties = [],
  opposingParties = [],
  partners = [],
  instrumentTypes = [],
  pendingWithOptions = PENDING_WITH_OPTIONS,
  statusOptions = STATUS_OPTIONS,
  customColumns = [],
  formattingRules = [],
  onManageColumns,
  allMatters = [],
}) {
  const showTable = useTableView();
  const instrumentOptions = instrumentTypes.length ? instrumentTypes.map((t) => t.name) : INSTRUMENT_TYPES;
  const clientNames = clients.map((c) => c.name).sort();
  const propertyAddresses = properties.map((p) => p.address).sort();
  const opposingPartyNames = opposingParties.map((o) => o.name).sort();
  const partnerNames = partners.map((p) => p.name).sort();

  const [visibleColumns, setVisibleColumns] = useState(() => {
    const saved = localStorage.getItem("matterTableColumns");
    const defaultVisible = DEFAULT_COLUMNS.filter((c) => c.defaultVisible).map((c) => c.key);

    if (saved) {
      let parsed = JSON.parse(saved);
      if (parsed.includes("date_closed")) parsed = parsed.filter((k) => k !== "date_closed");
      if (!parsed.includes("assigned_partner")) parsed = [...parsed, "assigned_partner"];
      if (!parsed.includes("matter_group")) parsed = [...parsed, "matter_group"];
      localStorage.setItem("matterTableColumns", JSON.stringify(parsed));
      return parsed;
    }
    return defaultVisible;
  });

  const [columnOrder, setColumnOrder] = useState(() => {
    const saved = localStorage.getItem("matterTableColumnOrder");
    const defaultOrder = DEFAULT_COLUMNS.map((c) => c.key);

    if (saved) {
      let parsed = JSON.parse(saved);
      const lastActivityIdx = parsed.indexOf("last_activity_date");
      const commentsIdx = parsed.indexOf("comments");
      if (lastActivityIdx > commentsIdx) {
        parsed = parsed.filter((k) => k !== "last_activity_date");
        parsed.splice(commentsIdx, 0, "last_activity_date");
      }
      if (!parsed.includes("assigned_partner")) {
        const clientIdx = parsed.indexOf("client_name");
        parsed.splice(clientIdx + 1, 0, "assigned_partner");
      }
      if (!parsed.includes("matter_group")) {
        const partnerIdx = parsed.indexOf("assigned_partner");
        parsed.splice(partnerIdx + 1, 0, "matter_group");
      }
      localStorage.setItem("matterTableColumnOrder", JSON.stringify(parsed));
      return parsed;
    }
    return defaultOrder;
  });

  const [columnWidths, setColumnWidths] = useState(() => {
    const saved = localStorage.getItem("matterTableWidths");
    if (saved) return JSON.parse(saved);
    return { ...DEFAULT_WIDTHS };
  });

  useEffect(() => {
    localStorage.setItem("matterTableColumns", JSON.stringify(visibleColumns));
  }, [visibleColumns]);

  useEffect(() => {
    localStorage.setItem("matterTableWidths", JSON.stringify(columnWidths));
  }, [columnWidths]);

  useEffect(() => {
    localStorage.setItem("matterTableColumnOrder", JSON.stringify(columnOrder));
  }, [columnOrder]);

  const customKeys = useMemo(
    () => customColumns.map((c) => c.field_key),
    [customColumns]
  );

  const relatedMatters = useMemo(
    () => buildRelatedMatters(allMatters.length ? allMatters : matters),
    [allMatters, matters]
  );

  const [expandedRelated, setExpandedRelated] = useState([]);

  const toggleRelated = (matterId) => {
    setExpandedRelated((prev) =>
      prev.includes(matterId) ? prev.filter((id) => id !== matterId) : [...prev, matterId]
    );
  };

  // Ordered keys = saved order (filtered to existing columns) + any newly added columns
  const orderedKeys = useMemo(() => {
    const allKeys = [...DEFAULT_COLUMNS.map((c) => c.key), ...customKeys];
    const inOrder = columnOrder.filter((k) => allKeys.includes(k));
    const missing = allKeys.filter((k) => !inOrder.includes(k));
    return [...inOrder, ...missing];
  }, [columnOrder, customKeys]);

  const isCustomKey = (key) => customKeys.includes(key);

  const getColumnLabel = (key) =>
    DEFAULT_COLUMNS.find((c) => c.key === key)?.label ||
    customColumns.find((c) => c.field_key === key)?.label ||
    key;

  const isColumnVisible = (columnKey) => {
    if (isCustomKey(columnKey)) return true;
    if (!visibleColumns.includes(columnKey)) return false;
    if (columnKey === "pending_with" && activeStatusFilter === "Closed") return false;
    if (columnKey === "date_closed" && (activeStatusFilter === "Open" || activeStatusFilter === "On Hold" || activeStatusFilter === "All Statuses")) return false;
    if (columnKey === "comments" && activeStatusFilter === "Closed") return false;
    return true;
  };

  const visibleKeys = orderedKeys.filter((key) => isColumnVisible(key));

  const [resizingColumn, setResizingColumn] = useState(null);

  const defaultWidthFor = (column) =>
    isCustomKey(column) ? 160 : DEFAULT_WIDTHS[column] || 150;

  const handleResizeStart = (column, e) => {
    if (e.pointerType === "mouse" && e.button !== 0) return;
    e.preventDefault();
    e.stopPropagation();

    const target = e.currentTarget;
    const pointerId = e.pointerId;
    const startX = e.clientX;
    const startWidth = columnWidths[column] || defaultWidthFor(column);

    setResizingColumn(column);
    try {
      target.setPointerCapture(pointerId);
    } catch {
      // Pointer capture is optional; the listeners below still work without it
    }

    const handlePointerMove = (moveEvent) => {
      const diff = moveEvent.clientX - startX;
      setColumnWidths((prev) => ({ ...prev, [column]: Math.max(80, Math.round(startWidth + diff)) }));
    };

    const stopResizing = () => {
      setResizingColumn(null);
      try {
        target.releasePointerCapture(pointerId);
      } catch {
        // Already released
      }
      target.removeEventListener("pointermove", handlePointerMove);
      target.removeEventListener("pointerup", stopResizing);
      target.removeEventListener("pointercancel", stopResizing);
    };

    target.addEventListener("pointermove", handlePointerMove);
    target.addEventListener("pointerup", stopResizing);
    target.addEventListener("pointercancel", stopResizing);
  };

  const resetColumnWidth = (column) => {
    setColumnWidths((prev) => ({ ...prev, [column]: defaultWidthFor(column) }));
  };

  // Keep the table at least as wide as its columns so the rows scroll instead of
  // squeezing the columns into each other (which made text overlap).
  const tableMinWidth = visibleKeys.reduce(
    (sum, key) => sum + (columnWidths[key] || defaultWidthFor(key)),
    0
  ) + 64;

  const toggleColumn = (columnKey) => {
    setVisibleColumns((prev) =>
      prev.includes(columnKey) ? prev.filter((k) => k !== columnKey) : [...prev, columnKey]
    );
  };

  const handleDragEnd = (result) => {
    if (!result.destination) return;
    const items = [...orderedKeys];
    const [reordered] = items.splice(result.source.index, 1);
    items.splice(result.destination.index, 0, reordered);
    setColumnOrder(items);
  };

  const getCellValue = (matter, key) => {
    if (isCustomKey(key)) return matter.custom_fields?.[key] ?? "";
    if (key === "amendment_types") return (matter.amendment_types || []).join(", ");
    if (key === "lease_provisions") return getLeaseProvisions(matter).join(", ");
    return matter[key] ?? "";
  };

  const saveCustomField = (matter, key, value) => {
    onQuickUpdate(matter.id, "custom_fields", {
      ...(matter.custom_fields || {}),
      [key]: value,
    });
  };

  const renderCellContent = (matter, key) => {
    const custom = customColumns.find((c) => c.field_key === key);
    if (custom) {
      const value = matter.custom_fields?.[key] ?? "";
      const save = (val) => saveCustomField(matter, key, val);
      if (custom.type === "select") {
        return <EditableSelectCell value={value} onSave={save} options={custom.options || []} searchTerm={searchTerm} />;
      }
      if (custom.type === "date") return <EditableDateCell value={value} onSave={save} />;
      if (custom.type === "number") return <EditableNumberCell value={value} onSave={save} />;
      return <EditableTextCell value={value} onSave={save} searchTerm={searchTerm} />;
    }

    switch (key) {
      case "client_name":
        return (
          <EditableSelectCell
            value={matter.client_name}
            onSave={(val) => onQuickUpdate(matter.id, "client_name", val)}
            options={clientNames}
            searchTerm={searchTerm}
            className="font-medium text-slate-900 dark:text-slate-100"
          />
        );
      case "assigned_partner":
        return (
          <EditableSelectCell
            value={matter.assigned_partner}
            onSave={(val) => onQuickUpdate(matter.id, "assigned_partner", val)}
            options={partnerNames}
            searchTerm={searchTerm}
          />
        );
      case "opposing_party":
        return (
          <EditableSelectCell
            value={matter.opposing_party}
            onSave={(val) => onQuickUpdate(matter.id, "opposing_party", val)}
            options={opposingPartyNames}
            searchTerm={searchTerm}
          />
        );
      case "property_address":
        return (
          <EditableSelectCell
            value={matter.property_address}
            onSave={(val) => onQuickUpdate(matter.id, "property_address", val)}
            options={propertyAddresses}
            searchTerm={searchTerm}
            className="truncate"
          />
        );
      case "instrument_type":
        return (
          <div onClick={(e) => e.stopPropagation()}>
            <Select value={matter.instrument_type} onValueChange={(value) => onQuickUpdate(matter.id, "instrument_type", value)}>
              <SelectTrigger className="h-7 border-0 font-normal text-xs px-2 text-slate-600 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 dark:bg-slate-900">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="dark:bg-slate-900 dark:border-slate-800">
                {instrumentOptions.map((option) => (
                  <SelectItem key={option} value={option}>{option}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            {matter.instrument_type === "Other" && matter.instrument_type_other && (
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 px-2 truncate">{matter.instrument_type_other}</p>
            )}
          </div>
        );
      case "pending_with":
        return (
          <div onClick={(e) => e.stopPropagation()}>
            <Select value={matter.pending_with} onValueChange={(value) => onQuickUpdate(matter.id, "pending_with", value)}>
              <SelectTrigger className={cn(
                "h-7 border-0 font-medium text-xs px-2 dark:border dark:border-slate-700",
                PENDING_COLORS[matter.pending_with]
              )}>
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="dark:bg-slate-900 dark:border-slate-800">
                {pendingWithOptions.map((option) => (
                  <SelectItem key={option} value={option}>{option}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        );
      case "status":
        return (
          <div onClick={(e) => e.stopPropagation()}>
            <Select
              value={matter.status}
              onValueChange={(value) => {
                if (value === "Closed") {
                  const today = new Date().toISOString().split("T")[0];
                  onQuickUpdate(matter.id, "status", value);
                  onQuickUpdate(matter.id, "date_closed", today);
                } else {
                  onQuickUpdate(matter.id, "status", value);
                }
              }}
            >
              <SelectTrigger className={cn(
                "h-7 border-0 font-medium text-xs px-2 dark:border dark:border-slate-700",
                STATUS_COLORS[matter.status]
              )}>
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="dark:bg-slate-900 dark:border-slate-800">
                {statusOptions.map((option) => (
                  <SelectItem key={option} value={option}>{option}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        );
      case "date_closed":
        return <EditableDateCell value={matter.date_closed} onSave={(val) => onQuickUpdate(matter.id, "date_closed", val)} />;
      case "date_received":
        return <EditableDateCell value={matter.date_received} onSave={(val) => onQuickUpdate(matter.id, "date_received", val)} />;
      case "last_activity_date":
        return <EditableDateCell value={matter.last_activity_date} onSave={(val) => onQuickUpdate(matter.id, "last_activity_date", val)} />;
      case "comments":
        return (
          <div onClick={(e) => e.stopPropagation()}>
            <EditableCommentCell
              value={matter.comments}
              title={matter.client_name}
              onSave={(val) => onQuickUpdate(matter.id, "comments", val)}
              searchTerm={searchTerm}
            />
          </div>
        );
      case "rentable_sqft":
        return <EditableNumberCell value={matter.rentable_sqft} suffix=" SF" onSave={(val) => onQuickUpdate(matter.id, "rentable_sqft", val)} />;
      case "lease_term_months":
        return <EditableNumberCell value={matter.lease_term_months} suffix=" mo" onSave={(val) => onQuickUpdate(matter.id, "lease_term_months", val)} />;
      case "sublet_sqft":
        return <EditableNumberCell value={matter.sublet_sqft} suffix=" SF" onSave={(val) => onQuickUpdate(matter.id, "sublet_sqft", val)} />;
      case "opposing_counsel":
        return <EditableTextCell value={matter.opposing_counsel} onSave={(val) => onQuickUpdate(matter.id, "opposing_counsel", val)} searchTerm={searchTerm} />;
      case "sublessee_assignee_name":
        return <EditableTextCell value={matter.sublessee_assignee_name} onSave={(val) => onQuickUpdate(matter.id, "sublessee_assignee_name", val)} searchTerm={searchTerm} />;
      case "sublease_term_type":
        return (
          <EditableSelectCell
            value={matter.sublease_term_type}
            onSave={(val) => onQuickUpdate(matter.id, "sublease_term_type", val)}
            options={SUBLEASE_TERM_TYPES}
          />
        );
      case "amendment_types":
        return (
          <EditableTextCell
            value={(matter.amendment_types || []).join(", ")}
            onSave={(val) => onQuickUpdate(matter.id, "amendment_types", val.split(",").map((v) => v.trim()).filter(Boolean))}
          />
        );
      case "lease_provisions": {
        const provisions = getLeaseProvisions(matter);
        return <span className="text-slate-600 dark:text-slate-300">{provisions.length ? provisions.join(", ") : "—"}</span>;
      }
      case "matter_group": {
        const siblings = relatedMatters[matter.id] || [];
        if (!siblings.length) return <span className="text-slate-400 text-xs">—</span>;
        return (
          <RelatedMattersToggle
            count={siblings.length}
            expanded={expandedRelated.includes(matter.id)}
            onToggle={() => toggleRelated(matter.id)}
          />
        );
      }
      default:
        return null;
    }
  };

  const SortableHeader = ({ column, children }) => {
    const isSorted = sortConfig?.key === column;
    const Icon = isSorted ? (sortConfig.direction === "asc" ? ArrowUp : ArrowDown) : ArrowUpDown;
    return (
      <button onClick={() => onSort(column)} className="flex items-center gap-1 hover:text-slate-900 dark:hover:text-slate-100 transition-colors">
        {children}
        <Icon className={cn("h-3 w-3", isSorted ? "text-slate-900 dark:text-slate-100" : "text-slate-400")} />
      </button>
    );
  };

  if (matters.length === 0) {
    return (
      <div className="bg-white dark:bg-black rounded-xl border border-slate-200 dark:border-slate-800 p-12 text-center">
        <div className="mx-auto w-16 h-16 bg-slate-100 dark:bg-slate-900 rounded-full flex items-center justify-center mb-4">
          <Eye className="h-8 w-8 text-slate-400" />
        </div>
        <h3 className="text-lg font-medium text-slate-900 dark:text-slate-100 mb-2">No matters found</h3>
        <p className="text-slate-500 dark:text-slate-400">Create your first matter to get started.</p>
      </div>
    );
  }

  return (
    <div className="bg-white dark:bg-black rounded-xl border border-slate-200 dark:border-slate-800 overflow-hidden shadow-sm w-full">
      {/* Toolbar */}
      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-100 p-2 dark:border-slate-800">
        <span className={cn("text-xs text-slate-500 dark:text-slate-400 px-1", showTable && "hidden")}>
          {matters.length} matter{matters.length === 1 ? "" : "s"}
        </span>
        <div className="flex items-center gap-1 ml-auto">
          <Button
            variant="outline"
            size="sm"
            onClick={onManageColumns}
            className="h-9 border-slate-300 bg-white text-slate-700 hover:bg-slate-100 hover:text-slate-900 dark:border-slate-600 dark:bg-slate-800 dark:text-slate-100 dark:hover:bg-slate-700 dark:hover:text-white"
          >
            <SlidersHorizontal className="h-4 w-4 mr-1.5" />
            <span className="text-xs">Edit columns</span>
          </Button>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="sm" className="h-9 text-slate-500 hover:text-slate-700 dark:text-slate-400 dark:hover:text-slate-200">
                <Settings2 className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-60 dark:bg-slate-900 dark:border-slate-800">
              <DropdownMenuLabel>Show / hide columns</DropdownMenuLabel>
              <DropdownMenuSeparator />
              <div className="max-h-[400px] overflow-y-auto">
                <DragDropContext onDragEnd={handleDragEnd}>
                  <Droppable droppableId="column-list">
                    {(provided) => (
                      <div ref={provided.innerRef} {...provided.droppableProps}>
                        {orderedKeys.map((key, index) => (
                          <Draggable key={key} draggableId={key} index={index}>
                            {(dragProvided, snapshot) => (
                              <div
                                ref={dragProvided.innerRef}
                                {...dragProvided.draggableProps}
                                className={cn("flex items-center gap-2 px-2 py-1.5 hover:bg-slate-100 dark:hover:bg-slate-800", snapshot.isDragging && "bg-slate-100 dark:bg-slate-800 shadow-lg")}
                              >
                                <div {...dragProvided.dragHandleProps} className="cursor-grab active:cursor-grabbing">
                                  <GripVertical className="h-4 w-4 text-slate-400" />
                                </div>
                                <DropdownMenuCheckboxItem
                                  checked={isCustomKey(key) ? true : visibleColumns.includes(key)}
                                  onCheckedChange={() => !isCustomKey(key) && toggleColumn(key)}
                                  disabled={isCustomKey(key)}
                                  className="flex-1 cursor-pointer"
                                  onSelect={(e) => e.preventDefault()}
                                >
                                  {getColumnLabel(key)}
                                </DropdownMenuCheckboxItem>
                              </div>
                            )}
                          </Draggable>
                        ))}
                        {provided.placeholder}
                      </div>
                    )}
                  </Droppable>
                </DragDropContext>
              </div>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={() => setColumnWidths({ ...DEFAULT_WIDTHS })} className="text-slate-500">
                Reset column widths
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => setColumnOrder(DEFAULT_COLUMNS.map((c) => c.key))} className="text-slate-500">
                Reset column order
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>

      {/* Mobile cards */}
      <MobileMatterList
        matters={matters}
        onView={onView}
        onEdit={onEdit}
        onDelete={onDelete}
        formattingRules={formattingRules}
        relatedMatters={relatedMatters}
        visibleKeys={visibleKeys}
        getColumnLabel={getColumnLabel}
        getCellValue={getCellValue}
        renderCell={renderCellContent}
        show={!showTable}
      />

      {/* Desktop table — also used on phones in landscape */}
      <div className={cn("overflow-x-auto", showTable ? "block" : "hidden")}>
        <Table className="w-full border-collapse" style={{ tableLayout: "fixed", minWidth: tableMinWidth }}>
          <TableHeader>
            <TableRow className="bg-slate-50/50 dark:bg-slate-950 hover:bg-slate-50/50 dark:hover:bg-slate-950 text-center border-b border-slate-200 dark:border-slate-800">
              {visibleKeys.map((columnKey) => (
                <TableHead
                  key={columnKey}
                  className="font-semibold text-slate-600 dark:text-slate-300 text-center relative border-r border-slate-200 dark:border-slate-800"
                  style={{ width: columnWidths[columnKey] || (isCustomKey(columnKey) ? 160 : undefined) }}
                >
                  <div className="flex items-center justify-between group relative">
                    {columnKey === "matter_group" ? (
                      <span className="flex items-center gap-1">{getColumnLabel(columnKey)}</span>
                    ) : (
                      <SortableHeader column={columnKey}>
                        <span className="flex items-center gap-1">{getColumnLabel(columnKey)}</span>
                      </SortableHeader>
                    )}
                    <button
                      type="button"
                      aria-label={`Resize ${getColumnLabel(columnKey)} column`}
                      title="Drag to resize. Double-tap to reset."
                      className="absolute -right-2 top-0 bottom-0 z-20 w-4 flex items-center justify-center cursor-col-resize touch-none select-none group/resize"
                      style={{ touchAction: "none" }}
                      onPointerDown={(e) => handleResizeStart(columnKey, e)}
                      onClick={(e) => e.stopPropagation()}
                      onDoubleClick={(e) => {
                        e.stopPropagation();
                        resetColumnWidth(columnKey);
                      }}
                    >
                      <span
                        className={cn(
                          "w-[3px] rounded-full transition-colors",
                          resizingColumn === columnKey
                            ? "bg-blue-500"
                            : "bg-slate-300 group-hover/resize:bg-blue-400 dark:bg-slate-700 dark:group-hover/resize:bg-blue-500"
                        )}
                        style={{ height: "70%" }}
                      />
                    </button>
                  </div>
                </TableHead>
              ))}
              <TableHead className="w-12 border-r border-slate-200"></TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {matters.map((matter) => {
              const siblings = relatedMatters[matter.id] || [];
              const showRelated = expandedRelated.includes(matter.id) && siblings.length > 0;
              const rowFormat = getRowFormat(formattingRules, matter);
              return (
              <Fragment key={matter.id}>
              <TableRow
                className={cn(
                  "matter-row cursor-pointer border-b border-slate-200 dark:border-slate-800",
                  rowFormat?.className
                )}
                style={rowFormat?.style}
                onClick={() => onView(matter)}
              >
                {visibleKeys.map((columnKey) => {
                  const cellValue = getCellValue(matter, columnKey);
                  const cellFormat = getCellFormat(formattingRules, columnKey, cellValue, matter);
                  return (
                    <TableCell
                      key={columnKey}
                      className={cn(
                        "text-slate-600 dark:text-slate-300 text-sm border-r border-slate-200 dark:border-slate-800 align-middle",
                        cellFormat?.className
                      )}
                      style={cellFormat?.style}
                    >
                      <div className="min-w-0 overflow-hidden">
                        {renderCellContent(matter, columnKey)}
                      </div>
                    </TableCell>
                  );
                })}
                <TableCell className="border-r border-slate-200 dark:border-slate-800">
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild onClick={(e) => e.stopPropagation()}>
                      <Button variant="ghost" size="icon" className="h-8 w-8">
                        <MoreHorizontal className="h-4 w-4 text-slate-400" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end" className="w-40 dark:bg-slate-900 dark:border-slate-800">
                      <DropdownMenuItem onClick={(e) => { e.stopPropagation(); onView(matter); }}>
                        <Eye className="h-4 w-4 mr-2" />
                        View details
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={(e) => { e.stopPropagation(); onEdit(matter); }}>
                        <Pencil className="h-4 w-4 mr-2" />
                        Edit
                      </DropdownMenuItem>
                      <DropdownMenuItem
                        onClick={(e) => { e.stopPropagation(); onDelete(matter); }}
                        className="text-red-600 focus:text-red-600"
                      >
                        <Trash2 className="h-4 w-4 mr-2" />
                        Delete
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </TableCell>
              </TableRow>
              {showRelated && (
                <TableRow className="bg-slate-50/80 dark:bg-slate-950/60 hover:bg-slate-50/80 dark:hover:bg-slate-950/60">
                  <TableCell
                    colSpan={visibleKeys.length + 1}
                    className="p-0 border-b border-slate-200 dark:border-slate-800"
                  >
                    <div className="border-l-4 border-indigo-300 dark:border-indigo-800">
                      <p className="px-4 pt-2 pb-1 text-xs uppercase tracking-wide text-slate-500 dark:text-slate-400">
                        Related matters · same client, property and opposing party
                      </p>
                      <RelatedMatterList matters={siblings} onView={onView} />
                    </div>
                  </TableCell>
                </TableRow>
              )}
              </Fragment>
              );
            })}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}