import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";

export default function CommentHistoryDialog({ open, onOpenChange, comments, title }) {
  const entries = (comments || "").split("\n").filter((line) => line.trim());

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg" onClick={(e) => e.stopPropagation()}>
        <DialogHeader>
          <DialogTitle>Comment History{title ? ` — ${title}` : ""}</DialogTitle>
        </DialogHeader>
        <div className="max-h-[60vh] overflow-y-auto space-y-2">
          {entries.length === 0 ? (
            <p className="text-sm text-slate-500 text-center py-4">No comments yet.</p>
          ) : (
            entries.map((entry, i) => (
              <div
                key={i}
                className="text-sm text-slate-700 dark:text-slate-200 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg px-3 py-2 whitespace-pre-wrap"
              >
                {entry}
              </div>
            ))
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}