import { useState } from "react";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus, Trash2 } from "lucide-react";

const TYPE_LABELS = {
  text: "Text",
  number: "Number",
  date: "Date",
  select: "Dropdown",
};

export default function ColumnManagerModal({
  open,
  onOpenChange,
  columns = [],
  onCreateColumn,
  onUpdateColumn,
  onDeleteColumn,
}) {
  const [newLabel, setNewLabel] = useState("");
  const [newType, setNewType] = useState("text");
  const [newOptions, setNewOptions] = useState("");
  const [creating, setCreating] = useState(false);

  const customColumns = columns.filter((c) => c.kind === "custom");

  const handleCreate = async () => {
    const label = newLabel.trim();
    if (!label) return;
    setCreating(true);
    try {
      await onCreateColumn({
        field_key: `custom_${Date.now().toString(36)}`,
        label,
        kind: "custom",
        type: newType,
        options:
          newType === "select"
            ? newOptions.split(",").map((o) => o.trim()).filter(Boolean)
            : [],
        position: customColumns.length + 1,
      });
      setNewLabel("");
      setNewType("text");
      setNewOptions("");
    } finally {
      setCreating(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto dark:bg-slate-900 dark:border-slate-800">
        <DialogHeader>
          <DialogTitle>Edit columns</DialogTitle>
          <DialogDescription>
            Add your own columns, rename them, or remove the ones you no longer use.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6">
          <section>
            <h3 className="text-sm font-semibold text-slate-900 dark:text-slate-100 mb-1">Your columns</h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mb-3">
              These columns are saved to every matter you track.
            </p>
            {customColumns.length === 0 ? (
              <div className="rounded-lg border border-dashed border-slate-300 dark:border-slate-600 p-4 text-sm text-slate-600 dark:text-slate-300">
                No custom columns yet.
              </div>
            ) : (
              <div className="space-y-2">
                {customColumns.map((column) => (
                  <div
                    key={column.id}
                    className="flex items-center gap-2 rounded-lg border border-slate-200 bg-white dark:border-slate-700 dark:bg-slate-800 p-2"
                  >
                    <Input
                      defaultValue={column.label}
                      onBlur={(e) => {
                        const label = e.target.value.trim();
                        if (label && label !== column.label) onUpdateColumn(column.id, { label });
                      }}
                      className="h-9 text-sm font-medium border-slate-300 bg-white text-slate-900 dark:border-slate-600 dark:bg-slate-950 dark:text-slate-100"
                    />
                    <span className="text-xs text-slate-600 dark:text-slate-300 w-20 text-right shrink-0">
                      {TYPE_LABELS[column.type] || "Text"}
                    </span>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-9 w-9 text-red-600 hover:text-red-700 hover:bg-red-50 dark:text-red-400 dark:hover:text-red-300 dark:hover:bg-red-950/40 shrink-0"
                      onClick={() => onDeleteColumn(column.id)}
                      aria-label={`Delete ${column.label} column`}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                ))}
              </div>
            )}
          </section>

          <section className="rounded-lg bg-slate-50 dark:bg-slate-950 p-4 space-y-3">
            <h3 className="text-sm font-semibold text-slate-900 dark:text-slate-100">Add a column</h3>
            <div className="grid gap-3 sm:grid-cols-2">
              <div className="space-y-1.5">
                <Label htmlFor="column-label" className="text-xs">Column name</Label>
                <Input
                  id="column-label"
                  value={newLabel}
                  onChange={(e) => setNewLabel(e.target.value)}
                  placeholder="e.g. Lender"
                  className="h-9 border-slate-300 bg-white text-slate-900 dark:border-slate-600 dark:bg-slate-900 dark:text-slate-100"
                />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs">Entry type</Label>
                <Select value={newType} onValueChange={setNewType}>
                  <SelectTrigger className="h-9 border-slate-300 bg-white text-slate-900 dark:border-slate-600 dark:bg-slate-900 dark:text-slate-100">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {Object.entries(TYPE_LABELS).map(([value, label]) => (
                      <SelectItem key={value} value={value}>{label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            {newType === "select" && (
              <div className="space-y-1.5">
                <Label className="text-xs">Options (comma separated)</Label>
                <Input
                  value={newOptions}
                  onChange={(e) => setNewOptions(e.target.value)}
                  placeholder="Low, Medium, High"
                  className="h-9 border-slate-300 bg-white text-slate-900 dark:border-slate-600 dark:bg-slate-900 dark:text-slate-100"
                />
              </div>
            )}
            <Button onClick={handleCreate} disabled={!newLabel.trim() || creating} className="w-full sm:w-auto">
              <Plus className="h-4 w-4 mr-2" />
              Add column
            </Button>
          </section>
        </div>
      </DialogContent>
    </Dialog>
  );
}