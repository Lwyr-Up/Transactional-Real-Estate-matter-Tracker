import { useState } from "react";
import { Label } from "@/components/ui/label";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { SWIPE_ACTION_OPTIONS, loadSwipeActions, saveSwipeActions } from "@/lib/swipeActions";

const SELECT_CLASS = "dark:bg-slate-900 dark:border-slate-700 dark:text-slate-200";

export default function SwipeActionsSettings() {
  const [actions, setActions] = useState(loadSwipeActions);

  const update = (side, value) => {
    const next = { ...actions, [side]: value };
    setActions(next);
    saveSwipeActions(next);
  };

  return (
    <div className="space-y-6">
      <p className="text-sm text-slate-600 dark:text-slate-400">
        Choose what happens when you swipe a matter card sideways in the phone layout.
        Swiping left pulls the card toward the left edge; swiping right pushes it the other way.
      </p>

      <div className="space-y-2">
        <Label className="text-sm block text-slate-700 dark:text-slate-300">Swipe left</Label>
        <Select value={actions.left} onValueChange={(value) => update("left", value)}>
          <SelectTrigger className={SELECT_CLASS}>
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {SWIPE_ACTION_OPTIONS.map((option) => (
              <SelectItem key={option.value} value={option.value}>{option.label}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-2">
        <Label className="text-sm block text-slate-700 dark:text-slate-300">Swipe right</Label>
        <Select value={actions.right} onValueChange={(value) => update("right", value)}>
          <SelectTrigger className={SELECT_CLASS}>
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {SWIPE_ACTION_OPTIONS.map((option) => (
              <SelectItem key={option.value} value={option.value}>{option.label}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
    </div>
  );
}