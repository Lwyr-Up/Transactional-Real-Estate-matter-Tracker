import { ChevronRight } from "lucide-react";
import { cn } from "@/lib/utils";
import { STATUS_COLORS, PENDING_COLORS, formatMatterDate } from "@/lib/matterColumns";

export default function RelatedMatterList({ matters = [], onView }) {
  return (
    <div className="divide-y divide-slate-100 dark:divide-slate-800/60">
      {matters.map((matter) => (
        <button
          key={matter.id}
          type="button"
          onClick={(e) => {
            e.stopPropagation();
            onView(matter);
          }}
          className="w-full flex items-center gap-2 px-4 py-2.5 text-left hover:bg-slate-100/70 dark:hover:bg-slate-800/50 transition-colors"
        >
          <span className="w-1.5 h-1.5 rounded-full bg-indigo-400 shrink-0" />
          <span className="text-sm font-medium text-slate-800 dark:text-slate-100 truncate max-w-[40%]">
            {matter.instrument_type || "Matter"}
          </span>
          <span className="text-xs text-slate-500 dark:text-slate-400 truncate">
            {formatMatterDate(matter.date_received)}
          </span>
          <span className="flex items-center gap-1.5 ml-auto shrink-0">
            {matter.status && (
              <span
                className={cn(
                  "text-[11px] font-medium px-2 py-0.5 rounded-full border",
                  STATUS_COLORS[matter.status] || "bg-slate-100 text-slate-600 border-slate-200"
                )}
              >
                {matter.status}
              </span>
            )}
            {matter.pending_with && (
              <span
                className={cn(
                  "text-[11px] font-medium px-2 py-0.5 rounded-full border hidden sm:inline",
                  PENDING_COLORS[matter.pending_with] || "bg-slate-100 text-slate-600 border-slate-200"
                )}
              >
                {matter.pending_with}
              </span>
            )}
            <ChevronRight className="h-4 w-4 text-slate-300 dark:text-slate-600" />
          </span>
        </button>
      ))}
    </div>
  );
}