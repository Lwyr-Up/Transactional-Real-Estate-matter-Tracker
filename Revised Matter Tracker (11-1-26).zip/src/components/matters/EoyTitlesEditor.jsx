import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";

export default function EoyTitlesEditor({ titles, notes, year, onChange }) {
  const setTitle = (key, value) => onChange({ titles: { ...titles, [key]: value } });
  const setNote = (key, value) => onChange({ notes: { ...notes, [key]: value } });

  return (
    <div className="space-y-3">
      <div>
        <Label className="text-xs text-slate-500 mb-1 block">Report title</Label>
        <Input
          value={titles.report ?? ""}
          placeholder={`End of Year Report - ${year}`}
          onChange={(e) => setTitle("report", e.target.value)}
          className="h-9"
        />
      </div>

      <div>
        <Label className="text-xs text-slate-500 mb-1 block">Metrics heading</Label>
        <Input value={titles.tiles ?? ""} onChange={(e) => setTitle("tiles", e.target.value)} className="h-9" />
      </div>

      <div className="grid gap-2">
        <Input
          value={titles.highlights ?? ""}
          placeholder="Highlights heading"
          onChange={(e) => setTitle("highlights", e.target.value)}
          className="h-9"
        />
        <Textarea
          value={notes.highlights ?? ""}
          placeholder="Add a short summary of the year's highlights for this report…"
          onChange={(e) => setNote("highlights", e.target.value)}
          rows={3}
        />
      </div>

      <div className="grid gap-2">
        <Input
          value={titles.closing ?? ""}
          placeholder="Closing notes heading"
          onChange={(e) => setTitle("closing", e.target.value)}
          className="h-9"
        />
        <Textarea
          value={notes.closing ?? ""}
          placeholder="Add closing notes…"
          onChange={(e) => setNote("closing", e.target.value)}
          rows={3}
        />
      </div>
    </div>
  );
}