import { useState } from "react";
import { Save, Trash2, RotateCcw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  loadEoyProfiles,
  saveEoyProfile,
  deleteEoyProfile,
  normalizeConfig,
} from "@/lib/eoyReport";

export default function EoyProfileBar({ config, onLoad }) {
  const [profiles, setProfiles] = useState(loadEoyProfiles);
  const [name, setName] = useState("");
  const [selected, setSelected] = useState("");

  const handleSave = () => {
    const label = name.trim() || selected;
    if (!label) return;
    setProfiles(saveEoyProfile(label, config));
    setName("");
    setSelected(label);
  };

  const handleLoad = (profileName) => {
    setSelected(profileName);
    const profile = profiles.find((p) => p.name === profileName);
    if (profile) onLoad(normalizeConfig(profile.config));
  };

  const handleDelete = () => {
    if (!selected) return;
    setProfiles(deleteEoyProfile(selected));
    setSelected("");
  };

  return (
    <div className="flex flex-wrap items-center gap-2">
      <Input
        value={name}
        onChange={(e) => setName(e.target.value)}
        placeholder="Save as profile…"
        className="h-9 w-full sm:w-44"
      />
      <Button type="button" size="sm" variant="outline" onClick={handleSave} disabled={!name.trim() && !selected}>
        <Save className="h-4 w-4 mr-1" />
        Save
      </Button>

      <Select value={selected} onValueChange={handleLoad}>
        <SelectTrigger className="h-9 w-full sm:w-44">
          <SelectValue placeholder="Load profile" />
        </SelectTrigger>
        <SelectContent>
          {profiles.length === 0 ? (
            <div className="px-2 py-1.5 text-xs text-slate-500">No saved profiles yet</div>
          ) : (
            profiles.map((p) => (
              <SelectItem key={p.name} value={p.name}>{p.name}</SelectItem>
            ))
          )}
        </SelectContent>
      </Select>

      {selected && (
        <Button type="button" size="sm" variant="ghost" className="text-slate-500 hover:text-red-600" onClick={handleDelete}>
          <Trash2 className="h-4 w-4" />
        </Button>
      )}

      <Button type="button" size="sm" variant="ghost" className="text-slate-500" onClick={() => onLoad(normalizeConfig({}))}>
        <RotateCcw className="h-4 w-4 mr-1" />
        Reset
      </Button>
    </div>
  );
}