import { useState } from "react";
import { ChevronDown } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { cn } from "@/lib/utils";

// Multi-select of the entries a list field actually uses.
export default function EoyFilterValues({ options = [], values = [], onChange }) {
  const [open, setOpen] = useState(false);
  const selected = values || [];

  const toggle = (option) => {
    onChange(
      selected.includes(option)
        ? selected.filter((v) => v !== option)
        : [...selected, option]
    );
  };

  const summary =
    selected.length === 0
      ? "Any entry"
      : selected.length === 1
        ? selected[0]
        : `${selected.length} selected`;

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button
          type="button"
          variant="outline"
          className="h-auto min-h-8 w-full min-w-0 justify-between px-2 font-normal sm:h-8 sm:w-auto sm:min-w-[10rem] sm:max-w-[16rem]"
        >
          <span className={cn("min-w-0 flex-1 whitespace-normal break-words text-left sm:truncate sm:whitespace-nowrap", selected.length === 0 && "text-muted-foreground")}>
            {summary}
          </span>
          <ChevronDown className="h-3.5 w-3.5 shrink-0 opacity-60" />
        </Button>
      </PopoverTrigger>
      <PopoverContent align="start" className="pointer-events-auto w-64 p-1">
        <div className="max-h-56 overflow-auto">
          {options.map((option) => (
            <label
              key={option}
              className="flex cursor-pointer items-center gap-2 rounded-sm px-2 py-1.5 text-sm hover:bg-accent"
            >
              <Checkbox checked={selected.includes(option)} onCheckedChange={() => toggle(option)} />
              <span className="min-w-0 flex-1 break-words sm:truncate">{option}</span>
            </label>
          ))}
          {options.length === 0 && (
            <p className="px-2 py-2 text-xs text-muted-foreground">No entries yet.</p>
          )}
        </div>
        {selected.length > 0 && (
          <Button
            type="button"
            variant="ghost"
            size="sm"
            className="mt-1 h-7 w-full justify-start text-xs text-muted-foreground"
            onClick={() => onChange([])}
          >
            Clear selection
          </Button>
        )}
      </PopoverContent>
    </Popover>
  );
}