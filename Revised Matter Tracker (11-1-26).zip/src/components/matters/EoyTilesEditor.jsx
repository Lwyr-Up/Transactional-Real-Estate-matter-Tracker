import { useState } from "react";
import { DragDropContext, Droppable, Draggable } from "@hello-pangea/dnd";
import { Filter, GripVertical, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import EoyMetricPicker from "@/components/matters/EoyMetricPicker";
import EoyFilterValues from "@/components/matters/EoyFilterValues";
import { tileSourceLabel } from "@/lib/eoyReport";

export default function EoyTilesEditor({ tiles, catalog, fields = [], preview = {}, onChange }) {
  const [openFilter, setOpenFilter] = useState(null);

  const move = (from, to) => {
    const next = [...tiles];
    const [moved] = next.splice(from, 1);
    next.splice(to, 0, moved);
    onChange(next);
  };

  // Tiles are edited by position so a saved report profile without tile keys still edits cleanly.
  const patch = (index, data) => onChange(tiles.map((t, i) => (i === index ? { ...t, ...data } : t)));

  return (
    <div className="space-y-2">
      <DragDropContext
        onDragEnd={({ source, destination }) => {
          setOpenFilter(null);
          if (destination) move(source.index, destination.index);
        }}
      >
        <Droppable droppableId="eoy-tiles">
          {(dropProvided) => (
            <div ref={dropProvided.innerRef} {...dropProvided.droppableProps} className="space-y-1.5">
              {tiles.map((tile, index) => {
                const key = tile.key || `tile-${index}-${tile.id}`;
                const metric = catalog.find((c) => c.id === tile.id);
                // A tile can point at any catalog entry no other tile already uses.
                const sources = catalog.filter(
                  (c) => c.id === tile.id || !tiles.some((t) => t !== tile && t.id === c.id)
                );
                const filter = tile.filter || { fieldKey: "", value: "" };
                // List fields offer their real entries as a multi-select instead of free text.
                const listOptions = fields.find((f) => f.key === filter.fieldKey)?.options || [];
                const editingFilter = openFilter === index;

                return (
                  <Draggable key={key} draggableId={key} index={index}>
                    {(dragProvided, snapshot) => (
                      <div
                        ref={dragProvided.innerRef}
                        {...dragProvided.draggableProps}
                        style={dragProvided.draggableProps.style}
                        className={`rounded-md bg-white dark:bg-slate-900 ${
                          snapshot.isDragging ? "shadow-lg ring-1 ring-slate-200 dark:ring-slate-700" : ""
                        }`}
                      >
                        <div className="grid grid-cols-[auto_minmax(0,1fr)_auto_auto] items-start gap-1.5 sm:flex">
                          <button
                            type="button"
                            {...dragProvided.dragHandleProps}
                            className="col-start-1 row-start-1 flex h-11 w-11 shrink-0 items-center justify-center text-slate-400 hover:text-slate-600 cursor-grab active:cursor-grabbing sm:mt-2 sm:h-auto sm:w-auto"
                            aria-label="Reorder tile"
                          >
                            <GripVertical className="h-4 w-4" />
                          </button>

                          <div className="col-span-4 col-start-1 row-start-2 grid min-w-0 flex-1 grid-cols-1 gap-1.5 sm:grid-cols-2">
                            {metric ? (
                              <Select value={tile.id} onValueChange={(id) => patch(index, { id })}>
                                <SelectTrigger className="h-9 min-w-0"><SelectValue /></SelectTrigger>
                                <SelectContent>
                                  {sources.map((c) => (
                                    <SelectItem key={c.id} value={c.id}>{c.label}</SelectItem>
                                  ))}
                                </SelectContent>
                              </Select>
                            ) : (
                              <div
                                title={tileSourceLabel(tile)}
                                className="flex min-h-9 min-w-0 items-center break-words rounded-md border border-input bg-slate-50 px-2 text-[11px] text-slate-500 dark:bg-slate-800 dark:text-slate-400 sm:h-9 sm:truncate"
                              >
                                {tileSourceLabel(tile)}
                              </div>
                            )}
                            <Input
                              value={tile.label ?? ""}
                              placeholder={metric?.label || "Tile label"}
                              onChange={(e) => patch(index, { label: e.target.value })}
                              className="h-9 text-base sm:text-sm"
                            />
                          </div>

                          <Button
                            type="button"
                            variant="ghost"
                            size="icon"
                            title="Filter this tile"
                            className={`col-start-3 row-start-1 mt-0.5 h-8 w-8 shrink-0 ${
                              tile.filter?.fieldKey ? "text-indigo-600 dark:text-indigo-400" : "text-slate-400"
                            }`}
                            onClick={() => setOpenFilter(editingFilter ? null : index)}
                          >
                            <Filter className="h-4 w-4" />
                          </Button>
                          <Button
                            type="button"
                            variant="ghost"
                            size="icon"
                            className="col-start-4 row-start-1 mt-0.5 h-8 w-8 shrink-0 text-slate-400 hover:text-red-600"
                            onClick={() => onChange(tiles.filter((_, i) => i !== index))}
                          >
                            <X className="h-4 w-4" />
                          </Button>
                        </div>

                        {editingFilter && (
                          <div className="flex min-w-0 flex-col items-stretch gap-1.5 pb-1.5 pt-2 sm:flex-row sm:flex-wrap sm:items-center sm:pl-6 sm:pr-8 sm:pt-1">
                            <Select
                              value={filter.fieldKey}
                              onValueChange={(fieldKey) =>
                                patch(index, { filter: { fieldKey, value: "", values: [] } })
                              }
                            >
                              <SelectTrigger className="h-8 w-full min-w-0 sm:w-40"><SelectValue placeholder="Any field" /></SelectTrigger>
                              <SelectContent className="max-h-64">
                                {fields.map((f) => (
                                  <SelectItem key={f.key} value={f.key}>{f.label}</SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            {listOptions.length > 0 ? (
                              <EoyFilterValues
                                options={listOptions}
                                values={filter.values || []}
                                onChange={(values) => patch(index, { filter: { ...filter, values, value: "" } })}
                              />
                            ) : (
                              <Input
                                value={filter.value}
                                placeholder="contains…"
                                disabled={!filter.fieldKey}
                                onChange={(e) => patch(index, { filter: { ...filter, value: e.target.value } })}
                                className="h-8 w-full min-w-0 text-base sm:w-40 sm:text-sm"
                              />
                            )}
                            {tile.filter && (
                              <Button
                                type="button"
                                variant="ghost"
                                size="sm"
                                className="h-8 text-xs text-slate-500"
                                onClick={() => patch(index, { filter: null })}
                              >
                                Clear
                              </Button>
                            )}
                          </div>
                        )}
                      </div>
                    )}
                  </Draggable>
                );
              })}
              {dropProvided.placeholder}
            </div>
          )}
        </Droppable>
      </DragDropContext>

      {tiles.length === 0 && <p className="text-xs text-slate-500">No metrics yet. Add one below.</p>}

      <EoyMetricPicker
        catalog={catalog}
        fields={fields}
        preview={preview}
        onAdd={(newTiles) => onChange([...tiles, ...newTiles])}
      />
    </div>
  );
}