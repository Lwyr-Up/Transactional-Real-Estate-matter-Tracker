import { useState } from "react";
import { Check, Plus, Search } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { SCOPE_OPTIONS, buildFieldTile, formatTileValue, newTileKey } from "@/lib/eoyReport";

export default function EoyMetricPicker({ catalog, fields = [], preview = {}, onAdd }) {
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");
  const [picked, setPicked] = useState([]);
  const [kind, setKind] = useState("sum");
  const [scope, setScope] = useState("all");
  const [fieldKey, setFieldKey] = useState(fields[0]?.key || "");

  const needle = query.trim().toLowerCase();
  const matches = catalog.filter(
    (c) =>
      !needle ||
      c.label.toLowerCase().includes(needle) ||
      String(c.desc || "").toLowerCase().includes(needle)
  );
  const groups = [...new Set(matches.map((c) => c.group || "Metrics"))];

  const reset = () => {
    setPicked([]);
    setQuery("");
  };

  const toggle = (id) =>
    setPicked((current) => (current.includes(id) ? current.filter((m) => m !== id) : [...current, id]));

  // Several metrics can be picked at once; each becomes its own tile.
  const addPicked = () => {
    if (!picked.length) return;
    onAdd(
      picked
        .map((id) => catalog.find((c) => c.id === id))
        .filter(Boolean)
        .map((metric) => ({ key: newTileKey(), id: metric.id, label: "", filter: null }))
    );
    setOpen(false);
    reset();
  };

  const addField = () => {
    const column = fields.find((f) => f.key === fieldKey);
    if (kind !== "count" && !column) return;
    onAdd([buildFieldTile(column, kind, scope)]);
    setOpen(false);
    reset();
  };

  return (
    <Popover
      open={open}
      onOpenChange={(next) => {
        setOpen(next);
        if (!next) reset();
      }}
    >
      <PopoverTrigger asChild>
        <Button type="button" variant="outline" className="w-full border-dashed text-slate-600">
          <Plus className="h-4 w-4 mr-1.5" />
          Add metric
        </Button>
      </PopoverTrigger>
      <PopoverContent align="start" className="print-report-popover pointer-events-auto w-[440px] max-w-[92vw] p-0">
        <div className="p-2 border-b border-slate-200 dark:border-slate-800">
          <div className="relative">
            <Search className="absolute left-2 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-slate-400" />
            <Input
              autoFocus
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search metrics…"
              className="h-8 pl-7 text-base sm:text-sm"
            />
          </div>
        </div>

        <div className="max-h-64 overflow-auto p-1">
          {groups.map((group) => (
            <div key={group} className="mb-1">
              <p className="px-2 py-1 text-[10px] font-semibold uppercase tracking-wide text-slate-400">{group}</p>
              {matches
                .filter((c) => (c.group || "Metrics") === group)
                .map((metric) => {
                  const value = preview[metric.id];
                  const isPicked = picked.includes(metric.id);
                  return (
                    <button
                      key={metric.id}
                      type="button"
                      onClick={() => toggle(metric.id)}
                      aria-pressed={isPicked}
                      className={`flex w-full items-start gap-2 rounded-md px-2 py-1.5 text-left ${
                        isPicked
                          ? "bg-indigo-50 dark:bg-indigo-950/40"
                          : "hover:bg-slate-100 dark:hover:bg-slate-800"
                      }`}
                    >
                      <span
                        className={`mt-0.5 flex h-4 w-4 shrink-0 items-center justify-center rounded-sm border ${
                          isPicked
                            ? "border-indigo-600 bg-indigo-600 text-white"
                            : "border-slate-300 dark:border-slate-600"
                        }`}
                      >
                        {isPicked && <Check className="h-3 w-3" />}
                      </span>
                      <span className="min-w-0 flex-1">
                        <span className="block break-words text-sm text-slate-800 dark:text-slate-100 sm:truncate">{metric.label}</span>
                        {metric.desc && <span className="block text-[11px] leading-tight text-slate-400">{metric.desc}</span>}
                      </span>
                      <span className="shrink-0 text-xs text-slate-500 dark:text-slate-400">
                        {value ? formatTileValue(value) : "—"}
                      </span>
                    </button>
                  );
                })}
            </div>
          ))}
          {matches.length === 0 && (
            <p className="px-2 py-3 text-xs text-slate-500">No metric matches that search. Build one below.</p>
          )}
        </div>

        {picked.length > 0 && (
          <div className="border-t border-slate-200 p-2 dark:border-slate-800">
            <Button type="button" size="sm" className="w-full" onClick={addPicked}>
              Add {picked.length} {picked.length === 1 ? "metric" : "metrics"}
            </Button>
          </div>
        )}

        <div className="space-y-2 border-t border-slate-200 p-2 dark:border-slate-800">
          <p className="px-1 text-[10px] font-semibold uppercase tracking-wide text-slate-400">Build from any field</p>
          <div className="grid grid-cols-2 gap-1.5">
            <Select value={kind} onValueChange={setKind}>
              <SelectTrigger className="h-8"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="count">Count matters</SelectItem>
                <SelectItem value="sum">Total</SelectItem>
                <SelectItem value="avg">Average</SelectItem>
              </SelectContent>
            </Select>
            <Select value={scope} onValueChange={setScope}>
              <SelectTrigger className="h-8"><SelectValue /></SelectTrigger>
              <SelectContent>
                {SCOPE_OPTIONS.map((opt) => (
                  <SelectItem key={opt.key} value={opt.key}>{opt.label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          {kind !== "count" && (
            <Select value={fieldKey} onValueChange={setFieldKey}>
              <SelectTrigger className="h-8"><SelectValue placeholder="Choose a field" /></SelectTrigger>
              <SelectContent className="max-h-64">
                {fields.map((f) => (
                  <SelectItem key={f.key} value={f.key}>{f.label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          )}
          <Button type="button" size="sm" variant="outline" className="w-full" onClick={addField}>
            {kind === "count" ? "Add count" : "Add metric"}
          </Button>
        </div>
      </PopoverContent>
    </Popover>
  );
}