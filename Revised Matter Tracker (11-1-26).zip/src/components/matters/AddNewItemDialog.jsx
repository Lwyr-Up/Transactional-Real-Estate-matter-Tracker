import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Loader2 } from "lucide-react";

export default function AddNewItemDialog({ open, onOpenChange, type, onSave }) {
  const [value, setValue] = useState("");
  const [isSaving, setIsSaving] = useState(false);

  const labels = {
    client: { title: "Add New Client", field: "Client Name", placeholder: "Enter client name" },
    property: { title: "Add New Property", field: "Property Address", placeholder: "Enter property address" },
    opposingParty: { title: "Add New Opposing Party", field: "Opposing Party Name", placeholder: "Enter opposing party name" }
  };

  const config = labels[type] || labels.client;

  const handleSave = async () => {
    if (value.trim()) {
      setIsSaving(true);
      await onSave(value.trim());
      setValue("");
      setIsSaving(false);
      onOpenChange(false);
    }
  };

  const handleClose = () => {
    setValue("");
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>{config.title}</DialogTitle>
        </DialogHeader>

        <div className="space-y-4 py-4">
          <div className="space-y-2">
            <Label htmlFor="newValue">{config.field}</Label>
            <Input
              id="newValue"
              value={value}
              onChange={(e) => setValue(e.target.value)}
              placeholder={config.placeholder}
              onKeyDown={(e) => e.key === 'Enter' && handleSave()}
              autoFocus
            />
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={handleClose}>Cancel</Button>
          <Button onClick={handleSave} disabled={!value.trim() || isSaving}>
            {isSaving ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : null}
            Add
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}