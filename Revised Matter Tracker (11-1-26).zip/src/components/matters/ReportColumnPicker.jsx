import { DragDropContext, Droppable, Draggable } from "@hello-pangea/dnd";
import { GripVertical } from "lucide-react";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";

export default function ReportColumnPicker({
  groups = [],
  selected = {},
  ordered = [],
  onToggle,
  onReorder,
  onSelectAll,
  onClear,
}) {
  const total = groups.reduce((n, g) => n + g.columns.length, 0);

  const handleDragEnd = (result) => {
    const { source, destination } = result;
    if (!destination || destination.index === source.index) return;
    onReorder(source.index, destination.index);
  };

  return (
    <div className="rounded-lg border border-slate-200 dark:border-slate-800 overflow-hidden">
      <div className="flex items-center justify-between gap-2 px-3 py-1.5 border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/60">
        <span className="text-xs text-slate-500 dark:text-slate-400">
          {ordered.length} of {total} columns
        </span>
        <div className="flex items-center gap-1">
          <Button type="button" variant="ghost" size="sm" onClick={onSelectAll}>
            Select all
          </Button>
          <Button type="button" variant="ghost" size="sm" onClick={onClear}>
            Clear
          </Button>
        </div>
      </div>

      <div className="px-3 py-3 space-y-3">
        {/* Column selection, always visible */}
        <div className="max-h-56 overflow-y-auto space-y-2.5 pr-1">
          {groups.map((group) => (
            <div key={group.title}>
              <p className="text-[11px] font-semibold uppercase tracking-wide text-slate-400 mb-1">
                {group.title}
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-x-4 gap-y-1.5">
                {group.columns.map(({ key, label }) => (
                  <div key={key} className="flex items-center gap-2 min-w-0">
                    <Checkbox
                      id={`report-col-${key}`}
                      checked={!!selected[key]}
                      onCheckedChange={() => onToggle(key)}
                    />
                    <Label
                      htmlFor={`report-col-${key}`}
                      title={label}
                      className="min-w-0 flex-1 break-words text-sm font-normal cursor-pointer sm:truncate"
                    >
                      {label}
                    </Label>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>

        {/* Print order of the selected columns */}
        {ordered.length > 0 && (
          <div>
            <p className="text-[11px] font-semibold uppercase tracking-wide text-slate-400 mb-1.5">
              Report order — drag to rearrange
            </p>
            <DragDropContext onDragEnd={handleDragEnd}>
              <Droppable droppableId="report-column-order">
                {(provided) => (
                  <div
                    ref={provided.innerRef}
                    {...provided.droppableProps}
                    className="max-h-40 overflow-y-auto rounded-md border border-slate-200 dark:border-slate-800 divide-y divide-slate-100 dark:divide-slate-800"
                  >
                    {ordered.map((column, index) => (
                      <Draggable key={column.key} draggableId={column.key} index={index}>
                        {(dragProvided, snapshot) => (
                          <div
                            ref={dragProvided.innerRef}
                            {...dragProvided.draggableProps}
                            className={`flex items-center gap-2 px-2 py-1.5 bg-white dark:bg-slate-900 ${
                              snapshot.isDragging
                                ? "shadow-lg ring-1 ring-slate-300 dark:ring-slate-600 rounded-md"
                                : ""
                            }`}
                          >
                            <button
                              type="button"
                              {...dragProvided.dragHandleProps}
                              aria-label={`Reorder ${column.label}`}
                              className="flex h-11 w-11 shrink-0 items-center justify-center text-slate-400 cursor-grab active:cursor-grabbing sm:h-auto sm:w-auto"
                            >
                              <GripVertical className="h-3.5 w-3.5" />
                            </button>
                            <span className="w-4 shrink-0 text-[11px] text-slate-400 tabular-nums">
                              {index + 1}
                            </span>
                            <span
                              className="flex-1 min-w-0 break-words text-sm text-slate-700 dark:text-slate-200 sm:truncate"
                              title={column.label}
                            >
                              {column.label}
                            </span>
                          </div>
                        )}
                      </Draggable>
                    ))}
                    {provided.placeholder}
                  </div>
                )}
              </Droppable>
            </DragDropContext>
          </div>
        )}
      </div>
    </div>
  );
}