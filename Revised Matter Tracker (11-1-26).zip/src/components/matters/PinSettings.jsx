import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Shield } from "lucide-react";
import { toast } from "sonner";
import { hasPin, setPin, clearPin } from "@/lib/pin";

// Optional on-device PIN, asked for each time the app opens.
export default function PinSettings() {
  const [enabled, setEnabled] = useState(() => hasPin());
  const [value, setValue] = useState("");

  const save = async () => {
    if (value.length < 4) {
      toast.error("PIN must be at least 4 digits");
      return;
    }
    await setPin(value);
    setEnabled(true);
    setValue("");
    toast.success("PIN set. It will be asked for each time the app opens.");
  };

  const remove = () => {
    clearPin();
    setEnabled(false);
    toast.success("PIN removed");
  };

  return (
    <div className="border-t pt-4 space-y-3">
      <div>
        <h3 className="text-sm font-semibold mb-2 flex items-center gap-2">
          <Shield className="h-4 w-4" />
          App PIN
        </h3>
        <p className="text-sm text-slate-600 dark:text-slate-400">
          Optionally ask for a PIN each time the app opens. It keeps casual viewers out; it does not encrypt the stored data.
        </p>
      </div>
      {enabled ? (
        <Button variant="outline" onClick={remove} className="w-full">Remove PIN</Button>
      ) : (
        <div className="flex gap-2">
          <Input
            type="password"
            inputMode="numeric"
            placeholder="New PIN (4+ digits)"
            value={value}
            onChange={(e) => setValue(e.target.value.replace(/\D/g, ""))}
          />
          <Button onClick={save}>Set PIN</Button>
        </div>
      )}
    </div>
  );
}
