import { useState } from "react";
import { Check, ChevronDown } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { cn } from "@/lib/utils";

// Multi-select filter where an empty selection means "All".
export default function MultiSelectFilter({
  options = [],
  values = [],
  onChange,
  allLabel = "All",
}) {
  const [open, setOpen] = useState(false);
  const allSelected = values.length === 0;

  const summary = allSelected
    ? allLabel
    : values.length === 1
      ? values[0]
      : `${values.length} selected`;

  const toggle = (option) => {
    onChange(
      values.includes(option) ? values.filter((v) => v !== option) : [...values, option]
    );
  };

  const Row = ({ label, checked, onSelect }) => (
    <button
      type="button"
      onClick={onSelect}
      className={cn(
        "flex w-full items-center gap-2 rounded-sm px-2 py-1.5 text-left text-sm hover:bg-indigo-100 hover:text-indigo-900 dark:hover:bg-indigo-500/30 dark:hover:text-indigo-50",
        checked && "bg-indigo-50 text-indigo-900 dark:bg-indigo-500/20 dark:text-indigo-50"
      )}
    >
      <span
        className={cn(
          "flex h-4 w-4 shrink-0 items-center justify-center rounded-sm border",
          checked
            ? "border-indigo-600 bg-indigo-600 text-white"
            : "border-slate-300 dark:border-slate-600"
        )}
      >
        {checked && <Check className="h-3 w-3" />}
      </span>
      <span className="min-w-0 flex-1 break-words">{label}</span>
    </button>
  );

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button
          type="button"
          variant="outline"
          role="combobox"
          aria-expanded={open}
          className="h-auto min-h-9 w-full justify-between gap-2 px-3 py-2 text-left font-normal"
        >
          <span className="min-w-0 flex-1 break-words">{summary}</span>
          <ChevronDown className="h-4 w-4 shrink-0 opacity-50" />
        </Button>
      </PopoverTrigger>
      <PopoverContent align="start" className="w-72 max-w-[92vw] p-1">
        <div className="max-h-64 overflow-auto">
          <Row label={allLabel} checked={allSelected} onSelect={() => onChange([])} />
          <div className="my-1 h-px bg-border" />
          {options.map((option) => (
            <Row
              key={option}
              label={option}
              checked={values.includes(option)}
              onSelect={() => toggle(option)}
            />
          ))}
        </div>
      </PopoverContent>
    </Popover>
  );
}