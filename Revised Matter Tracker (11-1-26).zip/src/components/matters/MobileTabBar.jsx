import { useState } from "react";
import { Briefcase, Printer, Database } from "lucide-react";
import { cn } from "@/lib/utils";

const TABS = [
  { key: "matters", label: "Matters", icon: Briefcase },
  { key: "reports", label: "Reports", icon: Printer },
  { key: "data", label: "Data", icon: Database },
];

export default function MobileTabBar({ onMatters, onReports, onData }) {
  const [active, setActive] = useState("matters");

  const handlers = {
    matters: onMatters,
    reports: onReports,
    data: onData,
  };

  return (
    <nav
      className="sm:hidden fixed inset-x-0 bottom-0 z-40 border-t border-slate-200 bg-white/95 backdrop-blur dark:border-slate-800 dark:bg-slate-950/95"
      style={{ paddingBottom: "env(safe-area-inset-bottom)" }}
    >
      <div className="grid grid-cols-3">
        {TABS.map(({ key, label, icon: Icon }) => (
          <button
            key={key}
            type="button"
            onClick={() => {
              setActive(key);
              handlers[key]?.();
            }}
            className={cn(
              "flex h-14 flex-col items-center justify-center gap-1 text-xs font-medium transition-colors",
              active === key
                ? "text-slate-900 dark:text-slate-100"
                : "text-slate-500 dark:text-slate-400"
            )}
          >
            <Icon className="h-5 w-5" />
            {label}
          </button>
        ))}
      </div>
    </nav>
  );
}