import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { ChevronRight, Pencil } from "lucide-react";
import { cn } from "@/lib/utils";
import RelatedMattersToggle from "@/components/matters/RelatedMattersToggle";
import RelatedMatterList from "@/components/matters/RelatedMatterList";
import SwipeableMatterCard from "@/components/matters/SwipeableMatterCard";
import { getCellFormat, getRowFormat } from "@/lib/formattingRules";
import { loadSwipeActions, subscribeSwipeActions } from "@/lib/swipeActions";

// Already shown in the card header / related toggle, so no need to repeat them
const HIDDEN_IN_CARD = ["client_name", "property_address", "matter_group"];

export default function MobileMatterList({
  matters,
  onView,
  onEdit,
  onDelete,
  formattingRules = [],
  relatedMatters = {},
  visibleKeys = [],
  getColumnLabel,
  getCellValue,
  renderCell,
  show = true,
}) {
  const [expandedRelated, setExpandedRelated] = useState([]);
  const [swipeActions, setSwipeActions] = useState(loadSwipeActions);

  useEffect(() => subscribeSwipeActions(() => setSwipeActions(loadSwipeActions())), []);

  const handleSwipeAction = (matter, action) => {
    if (action === "archive") onDelete?.(matter);
    else if (action === "edit") onEdit?.(matter);
    else if (action === "details") onView?.(matter);
  };

  const toggleRelated = (matterId) =>
    setExpandedRelated((prev) =>
      prev.includes(matterId) ? prev.filter((id) => id !== matterId) : [...prev, matterId]
    );

  const shownKeys = visibleKeys.filter((key) => !HIDDEN_IN_CARD.includes(key));

  return (
    <div className={cn("divide-y divide-slate-200 dark:divide-slate-800", !show && "hidden")}>
      {matters.map((matter) => {
        const rowFormat = getRowFormat(formattingRules, matter);
        return (
          <SwipeableMatterCard
            key={matter.id}
            leftAction={swipeActions.left}
            rightAction={swipeActions.right}
            onAction={(action) => handleSwipeAction(matter, action)}
          >
          <div
            onClick={() => onView(matter)}
            className={cn(
              "p-4 active:bg-slate-100/70 dark:active:bg-slate-900/70 transition-colors",
              rowFormat?.className
            )}
            style={rowFormat?.style}
          >
            <div className="flex items-start justify-between gap-2">
              <div className="min-w-0">
                <div className="flex items-center gap-1.5">
                  <h3 className="font-semibold text-slate-900 dark:text-slate-100 truncate">
                    {matter.client_name || "Untitled matter"}
                  </h3>
                </div>
                <p className="text-sm text-slate-500 dark:text-slate-400 truncate mt-0.5">
                  {matter.property_address || "—"}
                </p>
              </div>
              <ChevronRight className="h-5 w-5 text-slate-300 dark:text-slate-600 shrink-0 mt-0.5" />
            </div>

            {(relatedMatters[matter.id]?.length || 0) > 0 && (
              <div className="mt-2.5" onClick={(e) => e.stopPropagation()}>
                <RelatedMattersToggle
                  count={relatedMatters[matter.id].length}
                  expanded={expandedRelated.includes(matter.id)}
                  onToggle={() => toggleRelated(matter.id)}
                />
              </div>
            )}

            {expandedRelated.includes(matter.id) && (relatedMatters[matter.id]?.length || 0) > 0 && (
              <div
                className="mt-3 -mx-1 rounded-lg border border-slate-200 dark:border-slate-800 overflow-hidden"
                onClick={(e) => e.stopPropagation()}
              >
                <p className="px-3 pt-2 pb-1 text-xs uppercase tracking-wide text-slate-500 dark:text-slate-400 bg-slate-50 dark:bg-slate-950">
                  Related matters
                </p>
                <RelatedMatterList matters={relatedMatters[matter.id]} onView={onView} />
              </div>
            )}

            {/* Every visible table column, editable in place */}
            <div className="mt-3 space-y-0.5" onClick={(e) => e.stopPropagation()}>
              {shownKeys.map((key) => {
                const cellValue = getCellValue(matter, key);
                const cellFormat = getCellFormat(formattingRules, key, cellValue, matter);
                return (
                  <div
                    key={key}
                    className={cn(
                      "flex items-center gap-2 rounded-md px-1 py-0.5",
                      cellFormat?.className
                    )}
                    style={cellFormat?.style}
                  >
                    <span className="w-[38%] shrink-0 truncate text-xs uppercase tracking-wide text-slate-500 dark:text-slate-400">
                      {getColumnLabel(key)}
                    </span>
                    <div className="flex-1 min-w-0 text-sm">{renderCell(matter, key)}</div>
                  </div>
                );
              })}
            </div>

            <div className="flex gap-2 mt-3">
              <Button
                size="sm"
                variant="outline"
                className="flex-1 h-9 dark:border-slate-700 dark:text-slate-200"
                onClick={(e) => { e.stopPropagation(); onEdit(matter); }}
              >
                <Pencil className="h-3.5 w-3.5 mr-1.5" />
                Edit
              </Button>
              <Button
                size="sm"
                variant="ghost"
                className="flex-1 h-9 text-slate-600 dark:text-slate-300"
                onClick={(e) => { e.stopPropagation(); onView(matter); }}
              >
                Details
              </Button>
            </div>
          </div>
          </SwipeableMatterCard>
        );
      })}
    </div>
  );
}