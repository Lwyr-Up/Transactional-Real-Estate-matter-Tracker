import { useState } from "react";
import { ChevronDown, ChevronRight, Sliders } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import EoyTilesEditor from "@/components/matters/EoyTilesEditor";
import EoyChartsEditor from "@/components/matters/EoyChartsEditor";
import EoyTitlesEditor from "@/components/matters/EoyTitlesEditor";
import EoyProfileBar from "@/components/matters/EoyProfileBar";
import { DATE_FIELD_OPTIONS } from "@/lib/eoyReport";

const Section = ({ title, hint, children }) => (
  <div className="space-y-2">
    <div>
      <p className="text-xs font-semibold uppercase tracking-wide text-slate-500">{title}</p>
      {hint && <p className="text-[11px] text-slate-400 mt-0.5">{hint}</p>}
    </div>
    {children}
  </div>
);

const StatusChecks = ({ legend, options, selected, onToggle }) => (
  <div>
    <p className="text-[11px] text-slate-500 mb-1">{legend}</p>
    <div className="flex flex-wrap gap-x-4 gap-y-1.5">
      {options.map((status) => (
        <div key={status} className="flex items-center gap-2">
          <Checkbox
            id={`eoy-${legend}-${status}`}
            checked={selected.includes(status)}
            onCheckedChange={() => onToggle(status)}
          />
          <Label htmlFor={`eoy-${legend}-${status}`} className="text-sm font-normal cursor-pointer">
            {status}
          </Label>
        </div>
      ))}
    </div>
  </div>
);

export default function EoyReportSettings({
  config,
  onChange,
  year,
  statusOptions,
  catalog,
  fields = [],
  preview = {},
  groupOptions,
}) {
  const [open, setOpen] = useState(false);
  const settings = config.settings;

  const toggleStatus = (key, status) => {
    const current = settings[key];
    const next = current.includes(status) ? current.filter((s) => s !== status) : [...current, status];
    onChange({ settings: { ...settings, [key]: next } });
  };

  return (
    <div className="rounded-lg border border-slate-200 dark:border-slate-800">
      <Button
        type="button"
        variant="ghost"
        onClick={() => setOpen((v) => !v)}
        className="w-full justify-between px-3 py-2 h-auto text-sm font-medium"
      >
        <span className="flex items-center gap-2">
          <Sliders className="h-4 w-4 text-slate-500" />
          Report settings
        </span>
        {open ? <ChevronDown className="h-4 w-4 text-slate-400" /> : <ChevronRight className="h-4 w-4 text-slate-400" />}
      </Button>

      {open && (
        <div className="px-3 pb-4 pt-1 space-y-5 divide-y divide-slate-100 dark:divide-slate-800">
          <Section title="What counts" hint="Decide which matters and dates feed the report.">
            <div className="space-y-3">
              <StatusChecks
                legend="Counted as closed"
                options={statusOptions}
                selected={settings.closedStatuses}
                onToggle={(s) => toggleStatus("closedStatuses", s)}
              />
              <StatusChecks
                legend="Counted as open"
                options={statusOptions}
                selected={settings.openStatuses}
                onToggle={(s) => toggleStatus("openStatuses", s)}
              />
              <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
                <div>
                  <p className="text-[11px] text-slate-500 mb-1">Year runs on</p>
                  <Select
                    value={settings.dateField}
                    onValueChange={(v) => onChange({ settings: { ...settings, dateField: v } })}
                  >
                    <SelectTrigger className="h-9"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {DATE_FIELD_OPTIONS.map((opt) => (
                        <SelectItem key={opt.key} value={opt.key}>{opt.label}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="flex items-end pb-2">
                  <div className="flex items-center gap-2">
                    <Checkbox
                      id="eoy-include-archived"
                      checked={!!settings.includeArchived}
                      onCheckedChange={(checked) => onChange({ settings: { ...settings, includeArchived: !!checked } })}
                    />
                    <Label htmlFor="eoy-include-archived" className="text-sm font-normal cursor-pointer">
                      Include archived matters
                    </Label>
                  </div>
                </div>
              </div>
            </div>
          </Section>

          <div className="pt-4">
            <Section title="Summary tiles" hint="Drag to reorder. Pick what each tile measures, name it, and use the filter to narrow it to a slice of matters.">
              <EoyTilesEditor
                tiles={config.tiles}
                catalog={catalog}
                fields={fields}
                preview={preview}
                onChange={(tiles) => onChange({ tiles })}
              />
            </Section>
          </div>

          <div className="pt-4">
            <Section title="Charts" hint="Group any field, pick the chart style and how many groups show.">
              <EoyChartsEditor
                charts={config.charts}
                groupOptions={groupOptions}
                onChange={(charts) => onChange({ charts })}
              />
            </Section>
          </div>

          <div className="pt-4">
            <Section title="Titles & notes" hint="Rename headings and add your own commentary.">
              <EoyTitlesEditor
                titles={config.titles}
                notes={config.notes}
                year={year}
                onChange={(patch) => onChange(patch)}
              />
            </Section>
          </div>

          <div className="pt-4">
            <Section title="Saved profiles" hint="Keep several report set-ups and switch between them.">
              <EoyProfileBar config={config} onLoad={(next) => onChange(next, true)} />
            </Section>
          </div>
        </div>
      )}
    </div>
  );
}