import { ChevronRight, ChevronDown } from "lucide-react";
import { cn } from "@/lib/utils";

export default function RelatedMattersToggle({ count, expanded, onToggle }) {
  return (
    <button
      type="button"
      onClick={(e) => {
        e.stopPropagation();
        onToggle();
      }}
      aria-expanded={expanded}
      title={expanded ? "Hide related matters" : "Show related matters"}
      className={cn(
        "inline-flex items-center gap-1 h-9 px-2 rounded-md border text-[11px] font-medium whitespace-nowrap transition-colors",
        expanded
          ? "bg-indigo-50 text-indigo-700 border-indigo-200 dark:bg-indigo-950 dark:text-indigo-300 dark:border-indigo-900"
          : "bg-white text-slate-600 border-slate-200 hover:bg-slate-50 dark:bg-slate-900 dark:text-slate-300 dark:border-slate-700 dark:hover:bg-slate-800"
      )}
    >
      {expanded ? <ChevronDown className="h-3.5 w-3.5" /> : <ChevronRight className="h-3.5 w-3.5" />}
      {count} related
    </button>
  );
}