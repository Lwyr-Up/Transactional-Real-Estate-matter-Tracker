import { ChevronUp, ChevronDown, X, Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { SCOPE_OPTIONS } from "@/lib/eoyReport";

export default function EoyChartsEditor({ charts, groupOptions, onChange }) {
  const update = (id, patch) => onChange(charts.map((c) => (c.id === id ? { ...c, ...patch } : c)));

  const move = (index, direction) => {
    const target = index + direction;
    if (target < 0 || target >= charts.length) return;
    const next = [...charts];
    [next[index], next[target]] = [next[target], next[index]];
    onChange(next);
  };

  const add = () =>
    onChange([
      ...charts,
      { id: `c${Date.now()}`, title: "New chart", groupBy: "client_name", scope: "all", type: "bar", topN: 0, rollup: false },
    ]);

  return (
    <div className="space-y-3">
      {charts.map((chart, index) => (
        <div key={chart.id} className="rounded-lg border border-slate-200 dark:border-slate-800 p-3 space-y-2">
          <div className="flex flex-wrap items-center gap-1.5">
            <Input
              value={chart.title ?? ""}
              placeholder="Chart title"
              onChange={(e) => update(chart.id, { title: e.target.value })}
              className="h-9 flex-1 min-w-0 basis-full font-medium sm:basis-0"
            />
            <Button type="button" variant="ghost" size="icon" className="h-8 w-8 shrink-0" disabled={index === 0} onClick={() => move(index, -1)}>
              <ChevronUp className="h-4 w-4" />
            </Button>
            <Button type="button" variant="ghost" size="icon" className="h-8 w-8 shrink-0" disabled={index === charts.length - 1} onClick={() => move(index, 1)}>
              <ChevronDown className="h-4 w-4" />
            </Button>
            <Button type="button" variant="ghost" size="icon" className="h-8 w-8 shrink-0 text-slate-400 hover:text-red-600" onClick={() => onChange(charts.filter((c) => c.id !== chart.id))}>
              <X className="h-4 w-4" />
            </Button>
          </div>

          <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
            <div>
              <Label className="text-xs text-slate-500 mb-1 block">Group by</Label>
              <Select value={chart.groupBy} onValueChange={(v) => update(chart.id, { groupBy: v })}>
                <SelectTrigger className="h-9"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {groupOptions.map((opt) => (
                    <SelectItem key={opt.key} value={opt.key}>{opt.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-xs text-slate-500 mb-1 block">Count</Label>
              <Select value={chart.scope || "all"} onValueChange={(v) => update(chart.id, { scope: v })}>
                <SelectTrigger className="h-9"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {SCOPE_OPTIONS.map((opt) => (
                    <SelectItem key={opt.key} value={opt.key}>{opt.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-xs text-slate-500 mb-1 block">Chart style</Label>
              <Select value={chart.type || "pie"} onValueChange={(v) => update(chart.id, { type: v })}>
                <SelectTrigger className="h-9"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="pie">Pie</SelectItem>
                  <SelectItem value="bar">Bar</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-xs text-slate-500 mb-1 block">Groups shown (0 = all)</Label>
              <Input
                type="number"
                min="0"
                value={chart.topN ?? 0}
                onChange={(e) => update(chart.id, { topN: parseInt(e.target.value || "0", 10) })}
                className="h-9"
              />
            </div>
          </div>

          <div className="flex items-center gap-2">
            <Checkbox
              id={`rollup-${chart.id}`}
              checked={!!chart.rollup}
              onCheckedChange={(checked) => update(chart.id, { rollup: !!checked })}
            />
            <Label htmlFor={`rollup-${chart.id}`} className="text-xs font-normal cursor-pointer">
              Roll the remainder into “Other”
            </Label>
          </div>
        </div>
      ))}

      <Button type="button" variant="outline" size="sm" onClick={add} className="w-full">
        <Plus className="h-4 w-4 mr-1" />
        Add chart
      </Button>
    </div>
  );
}