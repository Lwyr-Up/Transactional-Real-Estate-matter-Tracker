import { format } from "date-fns";
import {
  PieChart, Pie, Cell, ResponsiveContainer, Tooltip,
  BarChart, Bar, XAxis, YAxis, CartesianGrid,
} from "recharts";
import { formatTileValue } from "@/lib/eoyReport";

const COLORS = ['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#ec4899', '#06b6d4', '#84cc16', '#f97316', '#6366f1'];

const TONES = {
  emerald: { bg: "#ecfdf5", border: "#a7f3d0", label: "#047857", value: "#065f46", sub: "#059669" },
  slate: { bg: "#f8fafc", border: "#e2e8f0", label: "#64748b", value: "#1e293b", sub: "#94a3b8" },
  indigo: { bg: "#eef2ff", border: "#c7d2fe", label: "#4338ca", value: "#3730a3", sub: "#6366f1" },
};

const headingStyle = { fontSize: "14px", fontWeight: "600", marginBottom: "12px" };

const NoteBlock = ({ title, text }) => {
  if (!text?.trim()) return null;
  return (
    <div style={{ marginBottom: "24px" }}>
      <h3 style={headingStyle}>{title?.trim() || "Notes"}</h3>
      <p style={{ fontSize: "12px", lineHeight: 1.6, whiteSpace: "pre-wrap", color: "#334155" }}>{text}</p>
    </div>
  );
};

const ChartBlock = ({ chart }) => {
  const legendLabel = (entry) =>
    entry.name === "Other" && chart.otherCount > 0
      ? `Other (${chart.otherCount} groups): ${entry.value}`
      : `${entry.name}: ${entry.value}`;

  return (
    <div className="pie-section" style={{ marginBottom: "24px" }}>
      <h3 style={headingStyle}>{chart.title}</h3>

      {chart.type === "pie" ? (
        <>
          <div style={{ height: "250px" }}>
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={chart.data}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ percent }) => `${(percent * 100).toFixed(0)}%`}
                  outerRadius={80}
                  dataKey="value"
                >
                  {chart.data.map((entry, index) => (
                    <Cell key={entry.name} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="pie-legend" style={{ display: "flex", flexWrap: "wrap", gap: "12px", marginTop: "12px" }}>
            {chart.data.map((entry, index) => (
              <div key={entry.name} className="legend-item" style={{ display: "flex", alignItems: "center", gap: "6px", fontSize: "12px" }}>
                <div style={{ width: "12px", height: "12px", borderRadius: "2px", backgroundColor: COLORS[index % COLORS.length] }}></div>
                <span>{legendLabel(entry)}</span>
              </div>
            ))}
          </div>
        </>
      ) : (
        <div style={{ height: "230px" }}>
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={chart.data} margin={{ bottom: 60 }}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" tick={{ fontSize: 11, angle: -45, textAnchor: "end" }} interval={0} />
              <YAxis allowDecimals={false} />
              <Tooltip />
              <Bar dataKey="value" fill="#3b82f6" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      )}
    </div>
  );
};

export default function EoyReportPreview({ report, config, year, printRef }) {
  const { titles, notes } = config;

  return (
    <div ref={printRef}>
      <h1>{titles.report?.trim() || `End of Year Report - ${year}`}</h1>
      <p className="date">Generated: {format(new Date(), "MMMM d, yyyy")}</p>

      {report.tiles.length > 0 && (
        <div style={{ marginTop: "20px", marginBottom: "24px" }}>
          <h3 style={headingStyle}>{titles.tiles?.trim() || "Key Metrics"}</h3>
          <div
            className="stat-grid"
            style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(140px, 1fr))", gap: "16px" }}
          >
            {report.tiles.map((tile) => {
              const tone = TONES[tile.tone] || TONES.slate;
              return (
                <div
                  key={tile.id}
                  className="stat-card"
                  style={{ background: tone.bg, border: `1px solid ${tone.border}`, borderRadius: "8px", padding: "16px" }}
                >
                  <div className="stat-label" style={{ fontSize: "12px", color: tone.label, marginBottom: "4px" }}>{tile.label}</div>
                  <div className="stat-value" style={{ fontSize: "24px", fontWeight: "600", color: tone.value }}>{formatTileValue(tile)}</div>
                  {tile.sub && <div style={{ fontSize: "10px", color: tone.sub, marginTop: "2px" }}>{tile.sub}</div>}
                </div>
              );
            })}
          </div>
        </div>
      )}

      <NoteBlock title={titles.highlights} text={notes.highlights} />

      {report.charts.map((chart) => (
        <ChartBlock key={chart.id} chart={chart} />
      ))}

      <NoteBlock title={titles.closing} text={notes.closing} />

      {report.empty && (
        <p style={{ color: "#64748b", textAlign: "center", padding: "40px 0" }}>
          No matters found for {year}.
        </p>
      )}
    </div>
  );
}