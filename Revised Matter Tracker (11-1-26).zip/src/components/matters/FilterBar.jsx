import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Search, X } from "lucide-react";

const INSTRUMENT_TYPES = [
  "All Types", "Amendment", "Assignment", "Easement", "Estoppel Certificate", 
  "Lease", "Letter of Intent", "License Agreement", "Other", 
  "Purchase Agreement", "Sale Agreement", "SNDA", "Sublease"
];

const PENDING_WITH_OPTIONS = ["All", "Rob", "Client", "Landlord", "Tenant", "Pending Internal Review"];
const STATUS_OPTIONS = ["All Statuses", "Open", "Pending Execution", "On Hold", "Closed", "Deal Died"];

export default function FilterBar({ filters, onFilterChange, onClearFilters, clients = [], properties = [], matters = [], instrumentTypes = [], pendingWithOptions = PENDING_WITH_OPTIONS, statusOptions = STATUS_OPTIONS }) {
  const instrumentOptions = ["All Types", ...(instrumentTypes.length ? instrumentTypes.map((t) => t.name) : INSTRUMENT_TYPES.slice(1))];
  // Filter properties based on selected client
  const filteredProperties = filters.client !== "All Clients"
    ? properties.filter(property => 
        matters.some(matter => 
          matter.client_name === filters.client && matter.property_address === property.address
        )
      )
    : properties;

  const hasActiveFilters = filters.search || 
    (filters.status && filters.status !== "All Statuses") || 
    (filters.instrumentType && filters.instrumentType !== "All Types") ||
    (filters.pendingWith && filters.pendingWith !== "All") ||
    (filters.client && filters.client !== "All Clients") ||
    (filters.property && filters.property !== "All Properties");

  return (
    <div className="bg-white dark:bg-black rounded-xl border border-slate-200 dark:border-slate-800 p-4 shadow-sm">
      <div className="flex flex-col lg:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
          <Input
            placeholder="Search by client, property, or opposing party..."
            value={filters.search || ""}
            onChange={(e) => onFilterChange("search", e.target.value)}
            className="pl-10 border-slate-200 dark:border-slate-800 dark:bg-slate-950 dark:text-slate-200 focus:border-blue-500 focus:ring-blue-500"
          />
        </div>

        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:flex lg:flex-wrap lg:items-center">
          <Select
            value={filters.client || "All Clients"}
            onValueChange={(value) => onFilterChange("client", value)}
          >
            <SelectTrigger className="w-full border-slate-200 dark:border-slate-800 text-slate-900 dark:bg-slate-950 dark:text-slate-200 lg:w-40">
              <SelectValue placeholder="Client" />
            </SelectTrigger>
            <SelectContent className="dark:bg-slate-900 dark:border-slate-800 max-h-[300px]">
              <SelectItem value="All Clients">All Clients</SelectItem>
              {clients.map((client) => (
                <SelectItem key={client.id} value={client.name}>{client.name}</SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Select
            value={filters.property || "All Properties"}
            onValueChange={(value) => onFilterChange("property", value)}
          >
            <SelectTrigger className="w-full border-slate-200 dark:border-slate-800 text-slate-900 dark:bg-slate-950 dark:text-slate-200 lg:w-44">
              <SelectValue placeholder="Property" />
            </SelectTrigger>
            <SelectContent className="dark:bg-slate-900 dark:border-slate-800 max-h-[300px]">
              <SelectItem value="All Properties">All Properties</SelectItem>
              {filteredProperties.map((property) => (
                <SelectItem key={property.id} value={property.address}>{property.address}</SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Select
            value={filters.status || "All Statuses"}
            onValueChange={(value) => onFilterChange("status", value)}
          >
            <SelectTrigger className="w-full border-slate-200 dark:border-slate-800 text-slate-900 dark:bg-slate-950 dark:text-slate-200 lg:w-36">
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent className="dark:bg-slate-900 dark:border-slate-800">
              {statusOptions.map((status) => (
                <SelectItem key={status} value={status}>{status}</SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Select
            value={filters.instrumentType || "All Types"}
            onValueChange={(value) => onFilterChange("instrumentType", value)}
          >
            <SelectTrigger className="w-full border-slate-200 dark:border-slate-800 text-slate-900 dark:bg-slate-950 dark:text-slate-200 lg:w-44">
              <SelectValue placeholder="Instrument Type" />
            </SelectTrigger>
            <SelectContent className="dark:bg-slate-900 dark:border-slate-800">
              {instrumentOptions.map((type) => (
                <SelectItem key={type} value={type}>{type}</SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Select
            value={filters.pendingWith || "All"}
            onValueChange={(value) => onFilterChange("pendingWith", value)}
          >
            <SelectTrigger className="w-full border-slate-200 dark:border-slate-800 text-slate-900 dark:bg-slate-950 dark:text-slate-200 lg:w-36">
              <SelectValue placeholder="Pending With" />
            </SelectTrigger>
            <SelectContent className="dark:bg-slate-900 dark:border-slate-800">
              {pendingWithOptions.map((option) => (
                <SelectItem key={option} value={option}>{option}</SelectItem>
              ))}
            </SelectContent>
          </Select>

          {hasActiveFilters && (
            <Button
              variant="ghost"
              onClick={onClearFilters}
              className="col-span-2 text-slate-900 hover:text-slate-700 dark:text-slate-400 dark:hover:text-slate-200 sm:col-span-1"
            >
              <X className="h-4 w-4 mr-1" />
              Clear
            </Button>
          )}
        </div>
      </div>
    </div>
  );
}