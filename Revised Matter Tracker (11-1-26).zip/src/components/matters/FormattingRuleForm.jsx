import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { cn } from "@/lib/utils";
import FormattingColorSwatch from "@/components/matters/FormattingColorSwatch";
import FormattingColorWheel from "@/components/matters/FormattingColorWheel";
import { FORMATTING_COLORS, COLOR_KEYS, describeRule, getFieldType, getFieldLabel } from "@/lib/formattingRules";

const chipClass = (active) =>
  cn(
    "rounded-full border px-2.5 py-1 text-xs transition-colors",
    active
      ? "border-slate-900 bg-slate-900 text-white dark:border-slate-200 dark:bg-slate-200 dark:text-slate-900"
      : "border-slate-200 text-slate-600 hover:border-slate-300 dark:border-slate-700 dark:text-slate-300 dark:hover:border-slate-600"
  );

export default function FormattingRuleForm({
  fields = [],
  customColumns = [],
  statusOptions = [],
  initial = null,
  onSave,
  onCancel,
  saving = false,
}) {
  const [fieldKey, setFieldKey] = useState(initial?.field_key || "");
  const [direction, setDirection] = useState(initial?.direction || "older");
  const [days, setDays] = useState(String(initial?.days ?? 30));
  const [matchMode, setMatchMode] = useState(initial?.match_mode || "contains");
  const [textValues, setTextValues] = useState((initial?.text_values || []).join(", "));
  const [color, setColor] = useState(initial?.color || "red");
  const [scope, setScope] = useState(initial?.scope || "cell");
  const [ignoreStatuses, setIgnoreStatuses] = useState(initial?.ignore_statuses || []);

  // Keep the rule's own field selectable when it is no longer shown on the main table
  const fieldOptions =
    initial?.field_key && !fields.some((f) => f.key === initial.field_key)
      ? [
          ...fields,
          {
            key: initial.field_key,
            label: getFieldLabel(initial.field_key, customColumns),
            type: getFieldType(initial.field_key, customColumns),
          },
        ]
      : fields;

  const fieldType = fieldKey ? getFieldType(fieldKey, customColumns) : "text";
  const dateFields = fieldOptions.filter((f) => f.type === "date");
  const textFields = fieldOptions.filter((f) => f.type !== "date");

  const parsedValues = textValues.split(",").map((v) => v.trim()).filter(Boolean);
  const isReady = fieldKey && (fieldType === "date" ? days !== "" : parsedValues.length > 0);

  const toggleStatus = (status) =>
    setIgnoreStatuses((prev) =>
      prev.includes(status) ? prev.filter((s) => s !== status) : [...prev, status]
    );

  const handleSubmit = () => {
    const payload = {
      field_key: fieldKey,
      kind: fieldType === "date" ? "date_age" : "text_match",
      direction,
      days: fieldType === "date" ? Number(days) || 0 : undefined,
      match_mode: matchMode,
      text_values: fieldType === "date" ? [] : parsedValues,
      color,
      scope,
      ignore_statuses: ignoreStatuses,
      enabled: initial?.enabled ?? true,
    };
    onSave({ ...payload, name: describeRule(payload, fieldOptions) });
  };

  return (
    <div className="space-y-4 rounded-lg border border-slate-200 bg-slate-50 p-3 dark:border-slate-800 dark:bg-slate-900">
      <div>
        <Label className="mb-1.5 block text-xs font-medium text-slate-600 dark:text-slate-300">Field</Label>
        <Select value={fieldKey} onValueChange={setFieldKey}>
          <SelectTrigger className="h-9 border-slate-200 bg-white text-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100">
            <SelectValue placeholder="Choose a field" />
          </SelectTrigger>
          <SelectContent className="max-h-72 dark:bg-slate-900 dark:border-slate-800">
            {dateFields.length > 0 && (
              <>
                <div className="px-2 py-1.5 text-[11px] uppercase tracking-wide text-slate-400">Dates</div>
                {dateFields.map((field) => (
                  <SelectItem key={field.key} value={field.key}>{field.label}</SelectItem>
                ))}
              </>
            )}
            {textFields.length > 0 && (
              <>
                <div className="px-2 py-1.5 text-[11px] uppercase tracking-wide text-slate-400">Text & values</div>
                {textFields.map((field) => (
                  <SelectItem key={field.key} value={field.key}>{field.label}</SelectItem>
                ))}
              </>
            )}
          </SelectContent>
        </Select>
      </div>

      {fieldKey && (
        <div className="space-y-2">
          <Label className="block text-xs font-medium text-slate-600 dark:text-slate-300">
            {fieldType === "date" ? "When is it out of date?" : "What text should stand out?"}
          </Label>

          {fieldType === "date" ? (
            <div className="flex flex-wrap items-center gap-2">
              <Select value={direction} onValueChange={setDirection}>
                <SelectTrigger className="h-9 w-40 border-slate-200 bg-white text-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="dark:bg-slate-900 dark:border-slate-800">
                  <SelectItem value="older">Older than</SelectItem>
                  <SelectItem value="newer">Within the last</SelectItem>
                </SelectContent>
              </Select>
              <Input
                type="number"
                min="0"
                value={days}
                onChange={(e) => setDays(e.target.value)}
                className="h-9 w-24 border-slate-200 bg-white text-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
              />
              <span className="text-sm text-slate-500 dark:text-slate-400">days</span>
            </div>
          ) : (
            <div className="flex flex-col gap-2 sm:flex-row">
              <Select value={matchMode} onValueChange={setMatchMode}>
                <SelectTrigger className="h-9 w-full sm:w-40 border-slate-200 bg-white text-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="dark:bg-slate-900 dark:border-slate-800">
                  <SelectItem value="contains">Contains</SelectItem>
                  <SelectItem value="equals">Is exactly</SelectItem>
                </SelectContent>
              </Select>
              <Input
                value={textValues}
                onChange={(e) => setTextValues(e.target.value)}
                placeholder="e.g. Urgent, TBD"
                className="h-9 flex-1 border-slate-200 bg-white text-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
              />
            </div>
          )}
          {fieldType !== "date" && (
            <p className="text-[11px] text-slate-500 dark:text-slate-400">Separate several words or phrases with commas.</p>
          )}
        </div>
      )}

      <div>
        <Label className="mb-1.5 block text-xs font-medium text-slate-600 dark:text-slate-300">Contrasting color</Label>
        <div className="flex flex-wrap gap-1.5">
          {COLOR_KEYS.map((key) => (
            <button
              key={key}
              type="button"
              title={`${FORMATTING_COLORS[key].label} — left: light mode, right: dark mode`}
              aria-label={FORMATTING_COLORS[key].label}
              onClick={() => setColor(key)}
              className={cn(
                "rounded-full ring-offset-2 ring-offset-slate-50 transition-all dark:ring-offset-slate-900",
                color === key
                  ? "ring-2 ring-slate-900 dark:ring-slate-100"
                  : "ring-1 ring-slate-300 dark:ring-slate-600 hover:scale-105"
              )}
            >
              <FormattingColorSwatch colorKey={key} className="h-7 w-7" />
            </button>
          ))}
          <FormattingColorWheel color={color} onChange={setColor} />
        </div>
        <p className="mt-1.5 text-[11px] text-slate-500 dark:text-slate-400">
          Each color covers both modes: the left half is how it looks in light mode, the right half in dark mode.
          The circle on the right opens a color wheel for any other color.
        </p>
      </div>

      <div>
        <Label className="mb-1.5 block text-xs font-medium text-slate-600 dark:text-slate-300">Highlight</Label>
        <div className="flex gap-2">
          <button type="button" onClick={() => setScope("cell")} className={chipClass(scope === "cell")}>
            Just this value
          </button>
          <button type="button" onClick={() => setScope("row")} className={chipClass(scope === "row")}>
            Whole row
          </button>
        </div>
      </div>

      {statusOptions.length > 0 && (
        <div>
          <Label className="mb-1.5 block text-xs font-medium text-slate-600 dark:text-slate-300">
            Skip matters with status
          </Label>
          <div className="flex flex-wrap gap-1.5">
            {statusOptions.map((status) => (
              <button
                key={status}
                type="button"
                onClick={() => toggleStatus(status)}
                className={chipClass(ignoreStatuses.includes(status))}
              >
                {status}
              </button>
            ))}
          </div>
        </div>
      )}

      <div className="flex gap-2 pt-1">
        <Button size="sm" onClick={handleSubmit} disabled={!isReady || saving} className="flex-1">
          {initial ? "Save rule" : "Add rule"}
        </Button>
        <Button size="sm" variant="ghost" onClick={onCancel}>Cancel</Button>
      </div>
    </div>
  );
}