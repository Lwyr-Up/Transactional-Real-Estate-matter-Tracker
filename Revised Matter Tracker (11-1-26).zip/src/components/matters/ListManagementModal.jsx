import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Pencil, Trash2, Plus, Check, X, Loader2 } from "lucide-react";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { toast } from "sonner";
import CategoryEditor from "./CategoryEditor";

const US_STATES = [
  "Alabama", "Alaska", "Arizona", "Arkansas", "California", "Colorado", "Connecticut", "Delaware",
  "Florida", "Georgia", "Hawaii", "Idaho", "Illinois", "Indiana", "Iowa", "Kansas", "Kentucky",
  "Louisiana", "Maine", "Maryland", "Massachusetts", "Michigan", "Minnesota", "Mississippi",
  "Missouri", "Montana", "Nebraska", "Nevada", "New Hampshire", "New Jersey", "New Mexico",
  "New York", "North Carolina", "North Dakota", "Ohio", "Oklahoma", "Oregon", "Pennsylvania",
  "Rhode Island", "South Carolina", "South Dakota", "Tennessee", "Texas", "Utah", "Vermont",
  "Virginia", "Washington", "West Virginia", "Wisconsin", "Wyoming", "District of Columbia"
];

function PropertyEditor({ items, onCreate, onUpdate, onDelete, onUpdateMattersField }) {
  const [editingId, setEditingId] = useState(null);
  const [editData, setEditData] = useState({ address: "", city: "", state: "" });
  const [newData, setNewData] = useState({ address: "", city: "", state: "" });
  const [isAdding, setIsAdding] = useState(false);
  const [deleteItem, setDeleteItem] = useState(null);
  const [duplicateAlert, setDuplicateAlert] = useState(null);

  const checkDuplicate = (address, excludeId = null) => {
    const normalizedValue = address.trim().toLowerCase();
    return items.find(item => 
      item.address.toLowerCase() === normalizedValue && item.id !== excludeId
    );
  };

  const handleStartEdit = (item) => {
    setEditingId(item.id);
    setEditData({ address: item.address, city: item.city || "", state: item.state || "" });
  };

  const handleSaveEdit = async (item) => {
    if (editData.address.trim() && editData.city.trim() && editData.state.trim()) {
      const duplicate = checkDuplicate(editData.address, item.id);
      if (duplicate) {
        setDuplicateAlert({ type: "edit", existingValue: duplicate.address });
        setEditingId(null);
        setEditData({ address: "", city: "", state: "" });
        return;
      }
      const oldAddress = item.address;
      const newAddress = editData.address.trim();
      await onUpdate(item.id, { 
        address: newAddress, 
        city: editData.city.trim(), 
        state: editData.state.trim() 
      });
      if (onUpdateMattersField && oldAddress !== newAddress) {
        await onUpdateMattersField("property_address", oldAddress, newAddress);
      }
    }
    setEditingId(null);
    setEditData({ address: "", city: "", state: "" });
  };

  const handleAdd = async () => {
    if (newData.address.trim() && newData.city.trim() && newData.state.trim()) {
      const duplicate = checkDuplicate(newData.address);
      if (duplicate) {
        setDuplicateAlert({ type: "add", existingValue: duplicate.address });
        setNewData({ address: "", city: "", state: "" });
        return;
      }
      setIsAdding(true);
      await onCreate({ 
        address: newData.address.trim(), 
        city: newData.city.trim(), 
        state: newData.state.trim() 
      });
      setNewData({ address: "", city: "", state: "" });
      setIsAdding(false);
    }
  };

  const handleDelete = async () => {
    if (deleteItem) {
      await onDelete(deleteItem.id);
      setDeleteItem(null);
    }
  };

  const canAdd = newData.address.trim() && newData.city.trim() && newData.state.trim();

  return (
    <div className="space-y-4">
      <div className="space-y-3 p-3 bg-slate-50 dark:bg-slate-900 rounded-lg">
        <div className="space-y-1">
          <Label className="text-xs text-slate-700 dark:text-slate-400">Address *</Label>
          <Input
            value={newData.address}
            onChange={(e) => setNewData(prev => ({ ...prev, address: e.target.value }))}
            placeholder="Street address"
            className="h-8 bg-white text-slate-900 placeholder:text-slate-500 dark:bg-slate-950 dark:text-slate-200 dark:placeholder:text-slate-500 dark:border-slate-800"
          />
        </div>
        <div className="grid grid-cols-2 gap-2">
          <div className="space-y-1">
            <Label className="text-xs text-slate-700 dark:text-slate-400">City/Town *</Label>
            <Input
              value={newData.city}
              onChange={(e) => setNewData(prev => ({ ...prev, city: e.target.value }))}
              placeholder="City"
              className="h-8 bg-white text-slate-900 placeholder:text-slate-500 dark:bg-slate-950 dark:text-slate-200 dark:placeholder:text-slate-500 dark:border-slate-800"
            />
          </div>
          <div className="space-y-1">
            <Label className="text-xs text-slate-700 dark:text-slate-400">State *</Label>
            <Select
              value={newData.state || undefined}
              onValueChange={(value) => setNewData(prev => ({ ...prev, state: value }))}
            >
              <SelectTrigger className="h-8 bg-white text-slate-900 text-sm dark:bg-slate-950 dark:text-slate-200 dark:border-slate-800">
                <SelectValue placeholder="Select state" />
              </SelectTrigger>
              <SelectContent>
                {US_STATES.map(state => (
                  <SelectItem key={state} value={state}>{state}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
        <Button onClick={handleAdd} disabled={!canAdd || isAdding} size="sm" className="w-full">
          {isAdding ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : <Plus className="h-4 w-4 mr-2" />}
          Add Property
        </Button>
      </div>

      <div className="border rounded-lg divide-y max-h-[250px] overflow-y-auto dark:border-slate-800">
        {items.length === 0 ? (
          <div className="p-4 text-center text-slate-600 dark:text-slate-400 text-sm">
            No properties added yet
          </div>
        ) : (
          items.map((item) => (
            <div key={item.id} className="p-3 hover:bg-slate-50 dark:hover:bg-slate-900 dark:border-slate-800">
              {editingId === item.id ? (
                <div className="space-y-2">
                  <Input
                    value={editData.address}
                    onChange={(e) => setEditData(prev => ({ ...prev, address: e.target.value }))}
                    placeholder="Address"
                    className="h-8 bg-white text-slate-900 placeholder:text-slate-500 dark:bg-slate-950 dark:text-slate-200 dark:placeholder:text-slate-500 dark:border-slate-800"
                    autoFocus
                  />
                  <div className="grid grid-cols-2 gap-2">
                    <Input
                      value={editData.city}
                      onChange={(e) => setEditData(prev => ({ ...prev, city: e.target.value }))}
                      placeholder="City"
                      className="h-8 bg-white text-slate-900 placeholder:text-slate-500 dark:bg-slate-950 dark:text-slate-200 dark:placeholder:text-slate-500 dark:border-slate-800"
                    />
                    <Select
                      value={editData.state || undefined}
                      onValueChange={(value) => setEditData(prev => ({ ...prev, state: value }))}
                    >
                      <SelectTrigger className="h-8 bg-white text-slate-900 text-sm dark:bg-slate-950 dark:text-slate-200 dark:border-slate-800">
                        <SelectValue placeholder="Select state" />
                      </SelectTrigger>
                      <SelectContent>
                        {US_STATES.map(state => (
                          <SelectItem key={state} value={state}>{state}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="flex justify-end gap-2">
                    <Button size="sm" variant="ghost" onClick={() => { setEditingId(null); setEditData({ address: "", city: "", state: "" }); }}>
                      <X className="h-4 w-4 mr-1" /> Cancel
                    </Button>
                    <Button size="sm" onClick={() => handleSaveEdit(item)} disabled={!editData.address.trim() || !editData.city.trim() || !editData.state.trim()}>
                      <Check className="h-4 w-4 mr-1" /> Save
                    </Button>
                  </div>
                </div>
              ) : (
                <div className="flex items-start justify-between">
                  <div>
                    <div className="text-sm font-medium text-slate-900 dark:text-slate-200">{item.address}</div>
                    <div className="text-xs text-slate-600 dark:text-slate-400">{item.city || ""}{item.city && item.state ? ", " : ""}{item.state || ""}</div>
                  </div>
                  <div className="flex items-center gap-1">
                    <Button size="icon" variant="ghost" className="h-8 w-8 text-slate-400 hover:text-slate-600" onClick={() => handleStartEdit(item)}>
                      <Pencil className="h-3.5 w-3.5" />
                    </Button>
                    <Button size="icon" variant="ghost" className="h-8 w-8 text-slate-400 hover:text-red-600" onClick={() => setDeleteItem(item)}>
                      <Trash2 className="h-3.5 w-3.5" />
                    </Button>
                  </div>
                </div>
              )}
            </div>
          ))
        )}
      </div>

      <AlertDialog open={!!deleteItem} onOpenChange={(open) => !open && setDeleteItem(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Remove Property?</AlertDialogTitle>
            <AlertDialogDescription>
              This will remove "{deleteItem?.address}" from the dropdown list. 
              Existing matters using this property will not be affected.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-red-600 hover:bg-red-700">
              Remove
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <AlertDialog open={!!duplicateAlert} onOpenChange={(open) => !open && setDuplicateAlert(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Duplicate Entry</AlertDialogTitle>
            <AlertDialogDescription>
              This property already exists: "{duplicateAlert?.existingValue}"
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogAction onClick={() => setDuplicateAlert(null)}>
              OK
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

function ListEditor({ items, onAdd, onCreate, onUpdate, onDelete, label, fieldName, matterFieldName, onUpdateMattersField }) {
  const [editingId, setEditingId] = useState(null);
  const [editValue, setEditValue] = useState("");
  const [newValue, setNewValue] = useState("");
  const [isAdding, setIsAdding] = useState(false);
  const [deleteItem, setDeleteItem] = useState(null);
  const [duplicateAlert, setDuplicateAlert] = useState(null);

  const checkDuplicate = (value, excludeId = null) => {
    const normalizedValue = value.trim().toLowerCase();
    return items.find(item => 
      item[fieldName].toLowerCase() === normalizedValue && item.id !== excludeId
    );
  };

  const handleStartEdit = (item) => {
    setEditingId(item.id);
    setEditValue(item[fieldName]);
  };

  const handleSaveEdit = async (item) => {
    if (editValue.trim()) {
      const duplicate = checkDuplicate(editValue, item.id);
      if (duplicate) {
        setDuplicateAlert({ type: "edit", existingValue: duplicate[fieldName] });
        setEditingId(null);
        setEditValue("");
        return;
      }
      const oldValue = item[fieldName];
      const newValue = editValue.trim();
      await onUpdate(item.id, { [fieldName]: newValue });
      // Update all matters that use this value
      if (onUpdateMattersField && oldValue !== newValue) {
        await onUpdateMattersField(matterFieldName, oldValue, newValue);
      }
    }
    setEditingId(null);
    setEditValue("");
  };

  const handleAdd = async () => {
    if (newValue.trim()) {
      const duplicate = checkDuplicate(newValue);
      if (duplicate) {
        setDuplicateAlert({ type: "add", existingValue: duplicate[fieldName] });
        setNewValue("");
        return;
      }
      setIsAdding(true);
      await onCreate({ [fieldName]: newValue.trim() });
      setNewValue("");
      setIsAdding(false);
    }
  };

  const handleDelete = async () => {
    if (deleteItem) {
      await onDelete(deleteItem.id);
      setDeleteItem(null);
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex gap-2">
        <Input
          value={newValue}
          onChange={(e) => setNewValue(e.target.value)}
          placeholder={`Add new ${label.toLowerCase()}...`}
          onKeyDown={(e) => e.key === 'Enter' && handleAdd()}
          className="flex-1 bg-white text-slate-900 placeholder:text-slate-500 dark:bg-slate-950 dark:text-slate-200 dark:placeholder:text-slate-500 dark:border-slate-800"
        />
        <Button onClick={handleAdd} disabled={!newValue.trim() || isAdding} size="sm">
          {isAdding ? <Loader2 className="h-4 w-4 animate-spin" /> : <Plus className="h-4 w-4" />}
        </Button>
      </div>

      <div className="border rounded-lg divide-y max-h-[300px] overflow-y-auto">
        {items.length === 0 ? (
          <div className="p-4 text-center text-slate-600 dark:text-slate-400 text-sm">
            No {label.toLowerCase()}s added yet
          </div>
        ) : (
          items.map((item) => (
            <div key={item.id} className="flex items-center justify-between p-3 hover:bg-slate-50 dark:hover:bg-slate-800">
              {editingId === item.id ? (
                <div className="flex items-center gap-2 flex-1">
                  <Input
                    value={editValue}
                    onChange={(e) => setEditValue(e.target.value)}
                    className="flex-1 h-8 bg-white text-slate-900 placeholder:text-slate-500 dark:bg-slate-950 dark:text-slate-200 dark:placeholder:text-slate-500 dark:border-slate-800"
                    autoFocus
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') handleSaveEdit(item);
                      if (e.key === 'Escape') { setEditingId(null); setEditValue(""); }
                    }}
                  />
                  <Button size="icon" variant="ghost" className="h-8 w-8 text-green-600" onClick={() => handleSaveEdit(item)}>
                    <Check className="h-4 w-4" />
                  </Button>
                  <Button size="icon" variant="ghost" className="h-8 w-8 text-slate-400" onClick={() => { setEditingId(null); setEditValue(""); }}>
                    <X className="h-4 w-4" />
                  </Button>
                </div>
              ) : (
                <>
                  <span className="text-sm text-slate-900 dark:text-slate-200">{item[fieldName]}</span>
                  <div className="flex items-center gap-1">
                    <Button size="icon" variant="ghost" className="h-8 w-8 text-slate-400 hover:text-slate-600" onClick={() => handleStartEdit(item)}>
                      <Pencil className="h-3.5 w-3.5" />
                    </Button>
                    <Button size="icon" variant="ghost" className="h-8 w-8 text-slate-400 hover:text-red-600" onClick={() => setDeleteItem(item)}>
                      <Trash2 className="h-3.5 w-3.5" />
                    </Button>
                  </div>
                </>
              )}
            </div>
          ))
        )}
      </div>

      <AlertDialog open={!!deleteItem} onOpenChange={(open) => !open && setDeleteItem(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Remove {label}?</AlertDialogTitle>
            <AlertDialogDescription>
              This will remove "{deleteItem?.[fieldName]}" from the dropdown list. 
              Existing matters using this {label.toLowerCase()} will not be affected.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-red-600 hover:bg-red-700">
              Remove
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <AlertDialog open={!!duplicateAlert} onOpenChange={(open) => !open && setDuplicateAlert(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Duplicate Entry</AlertDialogTitle>
            <AlertDialogDescription>
              This {label.toLowerCase()} already exists: "{duplicateAlert?.existingValue}"
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogAction onClick={() => setDuplicateAlert(null)}>
              OK
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

export default function ListManagementModal({ 
  open, 
  onOpenChange,
  defaultTab = "clients",
  clients, 
  properties, 
  opposingParties,
  partners = [],
  matterCategories = [],
  instrumentTypes = [],
  assetTypes = [],
  pendingWithRecords = [],
  statusRecords = [],
  onCreateClient,
  onUpdateClient,
  onDeleteClient,
  onCreateProperty,
  onUpdateProperty,
  onDeleteProperty,
  onCreateOpposingParty,
  onUpdateOpposingParty,
  onDeleteOpposingParty,
  onCreatePartner,
  onUpdatePartner,
  onDeletePartner,
  onCreateCategory,
  onUpdateCategory,
  onDeleteCategory,
  onCreateInstrumentType,
  onUpdateInstrumentType,
  onDeleteInstrumentType,
  onCreateAssetType,
  onUpdateAssetType,
  onDeleteAssetType,
  leaseProvisionOptions = [],
  onCreateLeaseProvision,
  onUpdateLeaseProvision,
  onDeleteLeaseProvision,
  onCreatePendingWith,
  onUpdatePendingWith,
  onDeletePendingWith,
  onCreateStatus,
  onUpdateStatus,
  onDeleteStatus,
  onUpdateMattersField,
  embedded = false
}) {
  if (embedded) {
    return (
      <Tabs defaultValue={defaultTab} key={defaultTab} className="w-full">
        <TabsList className="flex flex-wrap w-full h-auto gap-1">
          <TabsTrigger value="clients" className="text-xs">Clients</TabsTrigger>
          <TabsTrigger value="properties" className="text-xs">Properties</TabsTrigger>
          <TabsTrigger value="opposing" className="text-xs">Opposing</TabsTrigger>
          <TabsTrigger value="partners" className="text-xs">Partners</TabsTrigger>
          <TabsTrigger value="categories" className="text-xs">Categories</TabsTrigger>
          <TabsTrigger value="instruments" className="text-xs">Instruments</TabsTrigger>
          <TabsTrigger value="assets" className="text-xs">Asset Types</TabsTrigger>
          <TabsTrigger value="pending" className="text-xs">Pending With</TabsTrigger>
          <TabsTrigger value="statuses" className="text-xs">Statuses</TabsTrigger>
          <TabsTrigger value="provisions" className="text-xs">Lease Provisions</TabsTrigger>
        </TabsList>

        <TabsContent value="clients" className="mt-4">
          <ListEditor
            items={clients}
            onCreate={onCreateClient}
            onUpdate={onUpdateClient}
            onDelete={onDeleteClient}
            label="Client"
            fieldName="name"
            matterFieldName="client_name"
            onUpdateMattersField={onUpdateMattersField}
          />
        </TabsContent>

        <TabsContent value="properties" className="mt-4">
          <PropertyEditor
            items={properties}
            onCreate={onCreateProperty}
            onUpdate={onUpdateProperty}
            onDelete={onDeleteProperty}
            onUpdateMattersField={onUpdateMattersField}
          />
        </TabsContent>

        <TabsContent value="opposing" className="mt-4">
          <ListEditor
            items={opposingParties}
            onCreate={onCreateOpposingParty}
            onUpdate={onUpdateOpposingParty}
            onDelete={onDeleteOpposingParty}
            label="Opposing Party"
            fieldName="name"
            matterFieldName="opposing_party"
            onUpdateMattersField={onUpdateMattersField}
          />
        </TabsContent>

        <TabsContent value="partners" className="mt-4">
          <ListEditor
            items={partners}
            onCreate={onCreatePartner}
            onUpdate={onUpdatePartner}
            onDelete={onDeletePartner}
            label="Partner"
            fieldName="name"
            matterFieldName="assigned_partner"
            onUpdateMattersField={onUpdateMattersField}
          />
        </TabsContent>

        <TabsContent value="categories" className="mt-4">
          <CategoryEditor
            items={matterCategories}
            onCreate={onCreateCategory}
            onUpdate={onUpdateCategory}
            onDelete={onDeleteCategory}
            onUpdateMattersField={onUpdateMattersField}
          />
        </TabsContent>

        <TabsContent value="instruments" className="mt-4">
          <ListEditor
            items={instrumentTypes}
            onCreate={onCreateInstrumentType}
            onUpdate={onUpdateInstrumentType}
            onDelete={onDeleteInstrumentType}
            label="Instrument Type"
            fieldName="name"
            matterFieldName="instrument_type"
            onUpdateMattersField={onUpdateMattersField}
          />
        </TabsContent>

        <TabsContent value="assets" className="mt-4">
          <ListEditor
            items={assetTypes}
            onCreate={onCreateAssetType}
            onUpdate={onUpdateAssetType}
            onDelete={onDeleteAssetType}
            label="Asset Type"
            fieldName="name"
            matterFieldName="asset_type"
            onUpdateMattersField={onUpdateMattersField}
          />
        </TabsContent>

        <TabsContent value="pending" className="mt-4">
          <ListEditor
            items={pendingWithRecords}
            onCreate={onCreatePendingWith}
            onUpdate={onUpdatePendingWith}
            onDelete={onDeletePendingWith}
            label="Pending With Option"
            fieldName="name"
            matterFieldName="pending_with"
            onUpdateMattersField={onUpdateMattersField}
          />
        </TabsContent>

        <TabsContent value="statuses" className="mt-4">
          <ListEditor
            items={statusRecords}
            onCreate={onCreateStatus}
            onUpdate={onUpdateStatus}
            onDelete={onDeleteStatus}
            label="Status"
            fieldName="name"
            matterFieldName="status"
            onUpdateMattersField={onUpdateMattersField}
          />
        </TabsContent>

        <TabsContent value="provisions" className="mt-4">
          <ListEditor
            items={leaseProvisionOptions}
            onCreate={onCreateLeaseProvision}
            onUpdate={onUpdateLeaseProvision}
            onDelete={onDeleteLeaseProvision}
            label="Lease Provision"
            fieldName="name"
          />
        </TabsContent>
      </Tabs>
    );
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle>Manage Lists</DialogTitle>
        </DialogHeader>

        <Tabs defaultValue={defaultTab} key={defaultTab} className="w-full">
          <TabsList className="flex flex-wrap w-full h-auto gap-1">
            <TabsTrigger value="clients" className="text-xs">Clients</TabsTrigger>
            <TabsTrigger value="properties" className="text-xs">Properties</TabsTrigger>
            <TabsTrigger value="opposing" className="text-xs">Opposing</TabsTrigger>
            <TabsTrigger value="partners" className="text-xs">Partners</TabsTrigger>
            <TabsTrigger value="categories" className="text-xs">Categories</TabsTrigger>
            <TabsTrigger value="instruments" className="text-xs">Instruments</TabsTrigger>
            <TabsTrigger value="assets" className="text-xs">Asset Types</TabsTrigger>
            <TabsTrigger value="pending" className="text-xs">Pending With</TabsTrigger>
            <TabsTrigger value="statuses" className="text-xs">Statuses</TabsTrigger>
            <TabsTrigger value="provisions" className="text-xs">Lease Provisions</TabsTrigger>
          </TabsList>

          <TabsContent value="clients" className="mt-4">
            <ListEditor
              items={clients}
              onCreate={onCreateClient}
              onUpdate={onUpdateClient}
              onDelete={onDeleteClient}
              label="Client"
              fieldName="name"
              matterFieldName="client_name"
              onUpdateMattersField={onUpdateMattersField}
            />
          </TabsContent>

          <TabsContent value="properties" className="mt-4">
            <PropertyEditor
              items={properties}
              onCreate={onCreateProperty}
              onUpdate={onUpdateProperty}
              onDelete={onDeleteProperty}
              onUpdateMattersField={onUpdateMattersField}
            />
          </TabsContent>

          <TabsContent value="opposing" className="mt-4">
            <ListEditor
              items={opposingParties}
              onCreate={onCreateOpposingParty}
              onUpdate={onUpdateOpposingParty}
              onDelete={onDeleteOpposingParty}
              label="Opposing Party"
              fieldName="name"
              matterFieldName="opposing_party"
              onUpdateMattersField={onUpdateMattersField}
            />
          </TabsContent>

          <TabsContent value="partners" className="mt-4">
            <ListEditor
              items={partners}
              onCreate={onCreatePartner}
              onUpdate={onUpdatePartner}
              onDelete={onDeletePartner}
              label="Partner"
              fieldName="name"
              matterFieldName="assigned_partner"
              onUpdateMattersField={onUpdateMattersField}
            />
          </TabsContent>

          <TabsContent value="categories" className="mt-4">
            <CategoryEditor
              items={matterCategories}
              onCreate={onCreateCategory}
              onUpdate={onUpdateCategory}
              onDelete={onDeleteCategory}
              onUpdateMattersField={onUpdateMattersField}
            />
          </TabsContent>

          <TabsContent value="instruments" className="mt-4">
            <ListEditor
              items={instrumentTypes}
              onCreate={onCreateInstrumentType}
              onUpdate={onUpdateInstrumentType}
              onDelete={onDeleteInstrumentType}
              label="Instrument Type"
              fieldName="name"
              matterFieldName="instrument_type"
              onUpdateMattersField={onUpdateMattersField}
            />
          </TabsContent>

          <TabsContent value="assets" className="mt-4">
            <ListEditor
              items={assetTypes}
              onCreate={onCreateAssetType}
              onUpdate={onUpdateAssetType}
              onDelete={onDeleteAssetType}
              label="Asset Type"
              fieldName="name"
              matterFieldName="asset_type"
              onUpdateMattersField={onUpdateMattersField}
            />
          </TabsContent>

          <TabsContent value="pending" className="mt-4">
            <ListEditor
              items={pendingWithRecords}
              onCreate={onCreatePendingWith}
              onUpdate={onUpdatePendingWith}
              onDelete={onDeletePendingWith}
              label="Pending With Option"
              fieldName="name"
              matterFieldName="pending_with"
              onUpdateMattersField={onUpdateMattersField}
            />
          </TabsContent>

          <TabsContent value="statuses" className="mt-4">
            <ListEditor
              items={statusRecords}
              onCreate={onCreateStatus}
              onUpdate={onUpdateStatus}
              onDelete={onDeleteStatus}
              label="Status"
              fieldName="name"
              matterFieldName="status"
              onUpdateMattersField={onUpdateMattersField}
            />
          </TabsContent>

          <TabsContent value="provisions" className="mt-4">
            <ListEditor
              items={leaseProvisionOptions}
              onCreate={onCreateLeaseProvision}
              onUpdate={onUpdateLeaseProvision}
              onDelete={onDeleteLeaseProvision}
              label="Lease Provision"
              fieldName="name"
            />
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}