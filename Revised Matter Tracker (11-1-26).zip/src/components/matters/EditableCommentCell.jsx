import { useState } from "react";
import { format } from "date-fns";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Pencil, History } from "lucide-react";
import CommentHistoryDialog from "./CommentHistoryDialog";
import { addCommentEntry } from "@/lib/commentLog";

const highlightMatch = (text, search) => {
  if (!text || !search) return text || "—";
  const index = text.toLowerCase().indexOf(search.toLowerCase());
  if (index === -1) return text;
  return (
    <>
      {text.substring(0, index)}
      <span className="bg-yellow-200">{text.substring(index, index + search.length)}</span>
      {text.substring(index + search.length)}
    </>
  );
};

const todayValue = () => format(new Date(), "yyyy-MM-dd");

export default function EditableCommentCell({ value, onSave, searchTerm, title }) {
  const [isEditing, setIsEditing] = useState(false);
  const [isEditingLog, setIsEditingLog] = useState(false);
  const [historyOpen, setHistoryOpen] = useState(false);
  const [tempValue, setTempValue] = useState("");
  const [entryDate, setEntryDate] = useState(todayValue);

  const lines = (value || "").split("\n").filter((l) => l.trim());
  const latest = lines[0] || "";
  const hasMore = lines.length > 1;

  const startEditing = () => {
    setTempValue("");
    setEntryDate(todayValue());
    setIsEditing(true);
  };

  // New entry is stamped with the chosen date, then the log is re-sorted and merged
  const handleSave = () => {
    const newText = tempValue.trim();
    if (!newText) {
      setIsEditing(false);
      return;
    }
    const date = entryDate ? new Date(`${entryDate}T00:00:00`) : new Date();
    onSave(addCommentEntry(value, newText, date));
    setTempValue("");
    setEntryDate(todayValue());
    setIsEditing(false);
  };

  // Full-log edit: saved exactly as typed
  const handleSaveLog = () => {
    setIsEditingLog(false);
    if (tempValue !== (value || "")) onSave(tempValue.trim());
  };

  if (isEditingLog) {
    return (
      <Textarea
        value={tempValue}
        onChange={(e) => setTempValue(e.target.value)}
        onBlur={handleSaveLog}
        onKeyDown={(e) => {
          if (e.key === "Escape") { setTempValue(value || ""); setIsEditingLog(false); }
        }}
        className="text-base sm:text-sm min-h-[140px]"
        autoFocus
      />
    );
  }

  if (isEditing) {
    return (
      <div className="space-y-1.5 py-1" onClick={(e) => e.stopPropagation()}>
        <Textarea
          value={tempValue}
          onChange={(e) => setTempValue(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Enter" && !e.shiftKey) {
              e.preventDefault();
              handleSave();
            }
            if (e.key === "Escape") { setTempValue(""); setIsEditing(false); }
          }}
          placeholder="Add update..."
          className="text-base sm:text-sm min-h-[60px]"
          autoFocus
        />
        <div className="flex items-center gap-1.5 flex-wrap">
          <span className="text-[11px] text-slate-500 dark:text-slate-400">Date</span>
          <Input
            type="date"
            value={entryDate}
            onChange={(e) => setEntryDate(e.target.value)}
            className="h-9 sm:h-7 w-[135px] text-base sm:text-xs px-2"
          />
          <Button type="button" size="sm" className="h-7 px-2 text-xs ml-auto" onClick={handleSave}>
            Add
          </Button>
          <Button
            type="button"
            size="sm"
            variant="ghost"
            className="h-7 px-2 text-xs"
            onClick={() => { setTempValue(""); setIsEditing(false); }}
          >
            Cancel
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="relative group">
      <div
        onClick={(e) => { e.stopPropagation(); startEditing(); }}
        className="cursor-pointer hover:bg-slate-100 dark:hover:bg-slate-800 px-2 py-1 rounded whitespace-pre-wrap min-h-[28px]"
      >
        {highlightMatch(latest, searchTerm)}
      </div>
      {value && (
        <div className="flex items-center gap-3 px-2 mt-0.5">
          <button
            type="button"
            onClick={(e) => { e.stopPropagation(); setHistoryOpen(true); }}
            className="flex items-center gap-1 text-xs text-blue-600 hover:text-blue-800 dark:text-blue-400"
          >
            <History className="h-3 w-3" />
            View history{hasMore ? ` (${lines.length})` : ""}
          </button>
        </div>
      )}
      {value && (
        <button
          type="button"
          title="Edit full log (change dates or entries)"
          onClick={(e) => { e.stopPropagation(); setIsEditingLog(true); setTempValue(value); }}
          className="absolute top-1 right-1 opacity-0 group-hover:opacity-100 transition-opacity bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded p-1 text-slate-500 hover:text-slate-900"
        >
          <Pencil className="h-3 w-3" />
        </button>
      )}
      <CommentHistoryDialog
        open={historyOpen}
        onOpenChange={setHistoryOpen}
        comments={value}
        title={title}
      />
    </div>
  );
}