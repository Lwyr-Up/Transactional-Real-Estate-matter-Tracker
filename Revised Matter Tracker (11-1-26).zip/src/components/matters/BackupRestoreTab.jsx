import { useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { Download, Upload, FileJson, Cloud } from "lucide-react";
import * as XLSX from "@e965/xlsx";
import { format } from "date-fns";
import { toast } from "sonner";
import { useQueryClient } from "@tanstack/react-query";
import { formatDistanceToNow } from "date-fns";
import { importAll, importCsvRows, ENTITY_NAMES } from "@/api/localDb";
import { saveBackup, usePreparedBackup, getLastBackupAt } from "@/lib/backup";

const META_FIELDS = ["id", "created_date", "updated_date", "created_by", "created_by_id"];

export default function BackupRestoreTab({
  allMatters = [],
  onRestore,
  backupDownloaded,
  onBackupDownloaded
}) {
  const excelInputRef = useRef(null);
  const jsonInputRef = useRef(null);
  const csvInputRef = useRef(null);
  const queryClient = useQueryClient();
  const [csvTarget, setCsvTarget] = useState("Matter");
  // Prepared ahead of time so the iOS share sheet can open straight from the tap.
  const [openedAt] = useState(() => Date.now());
  const prepared = usePreparedBackup(JSON.stringify([openedAt, allMatters.map((m) => m.updated_date)]));
  const lastBackupAt = getLastBackupAt();

  const handleCloudBackup = async () => {
    try {
      const result = await saveBackup(prepared);
      if (result === "cancelled") return;
      onBackupDownloaded?.();
      toast.success(result === "shared" ? "Backup saved" : "Backup downloaded. Move it to iCloud Drive in Files.");
    } catch (error) {
      toast.error("Backup failed: " + error.message);
    }
  };

  const handleCsvImport = async (event) => {
    const file = event.target.files[0];
    if (!file) return;
    try {
      const wb = XLSX.read(await file.arrayBuffer());
      const rows = XLSX.utils.sheet_to_json(wb.Sheets[wb.SheetNames[0]], { defval: "" });
      const count = await importCsvRows(csvTarget, rows);
      queryClient.invalidateQueries();
      toast.success(`Imported ${count} ${csvTarget} records`);
    } catch (error) {
      toast.error("Import failed: " + error.message);
    } finally {
      event.target.value = "";
    }
  };

  const handleExcelBackup = () => {
    try {
      const data = allMatters.map((matter) => ({
        "Client Name": matter.client_name || "",
        "Assigned Partner": matter.assigned_partner || "",
        "Property Address": matter.property_address || "",
        "Opposing Party": matter.opposing_party || "",
        "Instrument Type": matter.instrument_type || "",
        "Asset Type": matter.asset_type || "",
        "Amendment Types": matter.amendment_types ? matter.amendment_types.join(", ") : "",
        "Sublessee/Assignee Name": matter.sublessee_assignee_name || "",
        "Sublet SF": matter.sublet_sqft || "",
        "Sublease Term Type": matter.sublease_term_type || "",
        "Date Received": matter.date_received || "",
        "Date Closed": matter.date_closed || "",
        "Pending With": matter.pending_with || "",
        "Status": matter.status || "",
        "Comments": matter.comments || "",
        "Last Activity Date": matter.last_activity_date || "",
        "Rentable SF": matter.rentable_sqft || "",
        "Lease Term (Months)": matter.lease_term_months || "",
        "Opposing Counsel": matter.opposing_counsel || "",
        "Extension Option": matter.has_extension_option ? "Yes" : "No",
        "Right of First Offer": matter.has_right_of_first_offer ? "Yes" : "No",
        "Right of First Refusal": matter.has_right_of_first_refusal ? "Yes" : "No",
        "Expansion Option": matter.has_expansion_option ? "Yes" : "No",
        "Termination Option": matter.has_termination_option ? "Yes" : "No",
        "Parking": matter.has_parking ? "Yes" : "No",
        "Archived": matter.archived ? "Yes" : "No",
        "Archived Date": matter.archived_date || ""
      }));

      const ws = XLSX.utils.json_to_sheet(data);
      const wb = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, ws, "Matters");
      XLSX.writeFile(wb, `matters-backup-${format(new Date(), "yyyy-MM-dd-HHmmss")}.xlsx`);

      onBackupDownloaded?.();
      toast.success("Backup downloaded successfully");
    } catch (error) {
      toast.error("Backup failed: " + error.message);
    }
  };

  const handleJsonBackup = () => {
    try {
      const payload = {
        format: "matter-tracker-backup",
        version: 1,
        exported_at: new Date().toISOString(),
        matters: allMatters
      };
      const blob = new Blob([JSON.stringify(payload, null, 2)], {
        type: "application/json"
      });
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.download = `matters-backup-${format(new Date(), "yyyy-MM-dd-HHmmss")}.json`;
      document.body.appendChild(link);
      link.click();
      link.remove();
      URL.revokeObjectURL(url);

      onBackupDownloaded?.();
      toast.success("JSON backup downloaded successfully");
    } catch (error) {
      toast.error("Backup failed: " + error.message);
    }
  };

  const handleExcelRestore = async (event) => {
    const file = event.target.files[0];
    if (!file) return;

    try {
      const data = await file.arrayBuffer();
      const workbook = XLSX.read(data);
      const worksheet = workbook.Sheets[workbook.SheetNames[0]];
      const jsonData = XLSX.utils.sheet_to_json(worksheet);

      if (!jsonData || jsonData.length === 0) {
        throw new Error("No data found in file");
      }

      const matters = jsonData.map((row) => ({
        client_name: row["Client Name"] || "",
        assigned_partner: row["Assigned Partner"] || "",
        property_address: row["Property Address"] || "",
        opposing_party: row["Opposing Party"] || "",
        instrument_type: row["Instrument Type"] || "",
        asset_type: row["Asset Type"] || "",
        amendment_types: row["Amendment Types"] ? row["Amendment Types"].split(", ").filter(Boolean) : [],
        sublessee_assignee_name: row["Sublessee/Assignee Name"] || "",
        sublet_sqft: row["Sublet SF"] || undefined,
        sublease_term_type: row["Sublease Term Type"] || "",
        date_received: row["Date Received"] || "",
        date_closed: row["Date Closed"] || "",
        pending_with: row["Pending With"] || "",
        status: row["Status"] || "Open",
        comments: row["Comments"] || "",
        last_activity_date: row["Last Activity Date"] || "",
        rentable_sqft: row["Rentable SF"] || undefined,
        lease_term_months: row["Lease Term (Months)"] || undefined,
        opposing_counsel: row["Opposing Counsel"] || "",
        has_extension_option: row["Extension Option"] === "Yes",
        has_right_of_first_offer: row["Right of First Offer"] === "Yes",
        has_right_of_first_refusal: row["Right of First Refusal"] === "Yes",
        has_expansion_option: row["Expansion Option"] === "Yes",
        has_termination_option: row["Termination Option"] === "Yes",
        has_parking: row["Parking"] === "Yes",
        archived: row["Archived"] === "Yes",
        archived_date: row["Archived Date"] || ""
      }));

      await onRestore(matters);
      toast.success(`Restored ${matters.length} matters and their list entries`);
    } catch (error) {
      toast.error("Restore failed: " + error.message);
    } finally {
      event.target.value = "";
    }
  };

  const handleJsonRestore = async (event) => {
    const file = event.target.files[0];
    if (!file) return;

    try {
      const parsed = JSON.parse(await file.text());

      // A full backup made by this app: restores matters, lists, columns and rules.
      if (parsed?.app === "matter-tracker-local") {
        if (!confirm("Restore from this full backup? This replaces ALL current matters, lists, columns and rules.")) return;
        await importAll(parsed, { replace: true });
        queryClient.invalidateQueries();
        toast.success("Full backup restored");
        return;
      }

      const rows = Array.isArray(parsed) ? parsed : parsed?.matters;

      if (!Array.isArray(rows) || rows.length === 0) {
        throw new Error("No matters found in file");
      }

      const matters = rows.map((row) => {
        const clean = {};
        Object.entries(row || {}).forEach(([key, value]) => {
          if (!META_FIELDS.includes(key)) clean[key] = value;
        });
        return clean;
      });

      if (!confirm(`Restore ${matters.length} matters from this JSON backup? This will replace all current data.`)) {
        return;
      }

      await onRestore(matters);
      toast.success(`Restored ${matters.length} matters and their list entries`);
    } catch (error) {
      toast.error("Restore failed: " + error.message);
    } finally {
      event.target.value = "";
    }
  };

  return (
    <div className="space-y-4">
      <div>
        <h3 className="text-sm font-semibold mb-2">Backup Data</h3>
        <p className="text-sm text-slate-600 mb-4">
          Your data is stored only on this device. The full backup saves everything (matters, lists, columns,
          formatting rules) to iCloud Drive. The other two cover matters only.
        </p>
        <div className="space-y-2">
          <Button onClick={handleCloudBackup} disabled={!prepared} className="w-full">
            <Cloud className="h-4 w-4 mr-2" />
            Save Full Backup to iCloud / Files
          </Button>
          <p className="text-xs text-slate-500">
            Choose Save to Files, then iCloud Drive. Last backup: {lastBackupAt ? formatDistanceToNow(lastBackupAt, { addSuffix: true }) : "never"}.
          </p>
          <Button onClick={handleJsonBackup} variant="outline" className="w-full">
            <FileJson className="h-4 w-4 mr-2" />
            Download Matters Only (JSON)
          </Button>
          <Button onClick={handleExcelBackup} variant="outline" className="w-full">
            <Download className="h-4 w-4 mr-2" />
            Download Matters Only (Excel)
          </Button>
        </div>
      </div>

      <div className="border-t pt-4">
        <h3 className="text-sm font-semibold mb-2">Restore Data</h3>
        <p className="text-sm text-slate-600 mb-4">
          Upload a full backup or a matters-only JSON or Excel backup. Warning: This will replace all current data.
          A full backup also restores lists, columns and rules; a matters-only file adds back the clients, partners,
          opposing parties, properties and other list entries it mentions.
        </p>
        <div className="space-y-2">
          <Button
            variant="outline"
            onClick={() => jsonInputRef.current?.click()}
            className="w-full"
          >
            <Upload className="h-4 w-4 mr-2" />
            Restore From JSON
          </Button>
          <Button
            variant="outline"
            onClick={() => excelInputRef.current?.click()}
            className="w-full"
          >
            <Upload className="h-4 w-4 mr-2" />
            Restore From Excel
          </Button>
        </div>
        <input
          ref={jsonInputRef}
          type="file"
          accept=".json,application/json"
          onChange={handleJsonRestore}
          className="hidden"
        />
        <input
          ref={excelInputRef}
          type="file"
          accept=".xlsx,.xls"
          onChange={handleExcelRestore}
          className="hidden"
        />
      </div>

      <div className="border-t pt-4">
        <h3 className="text-sm font-semibold mb-2">Import from Base44 (CSV)</h3>
        <p className="text-sm text-slate-600 mb-3">
          Choose which list the CSV belongs to, then pick the file exported from Base44. Records are added to what is already here.
        </p>
        <div className="flex gap-2">
          <select
            value={csvTarget}
            onChange={(e) => setCsvTarget(e.target.value)}
            className="h-9 rounded-md border border-input bg-transparent px-2 text-sm"
          >
            {ENTITY_NAMES.map((n) => <option key={n} value={n}>{n}</option>)}
          </select>
          <Button variant="outline" className="flex-1" onClick={() => csvInputRef.current?.click()}>
            <Upload className="h-4 w-4 mr-2" />
            Choose CSV
          </Button>
          <input ref={csvInputRef} type="file" accept=".csv,text/csv" onChange={handleCsvImport} className="hidden" />
        </div>
      </div>

      <div className="bg-amber-50 border border-amber-200 rounded-lg p-4">
        <p className="text-sm text-amber-800">
          <strong>Note:</strong> {backupDownloaded ? "A backup has been downloaded this session. " : ""}
          Backups automatically include all fields, even ones added in the future.
        </p>
      </div>
    </div>
  );
}