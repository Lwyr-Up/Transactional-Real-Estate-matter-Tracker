import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Pencil, Palette, Plus, Trash2 } from "lucide-react";
import FormattingRuleForm from "./FormattingRuleForm";
import FormattingColorSwatch from "./FormattingColorSwatch";
import { BUILT_IN_RULE_NAMES, describeRule, getFormattingFields } from "@/lib/formattingRules";

export default function FormattingRulesTab({
  rules = [],
  customColumns = [],
  statusOptions = [],
  onCreate,
  onUpdate,
  onDelete,
}) {
  const fields = getFormattingFields(customColumns);
  const [formOpen, setFormOpen] = useState(false);
  const [editingRule, setEditingRule] = useState(null);
  const [saving, setSaving] = useState(false);

  const openNew = () => {
    setEditingRule(null);
    setFormOpen(true);
  };

  const openEdit = (rule) => {
    setEditingRule(rule);
    setFormOpen(true);
  };

  const handleSave = async (data) => {
    setSaving(true);
    try {
      if (editingRule) {
        await onUpdate(editingRule.id, data);
      } else {
        await onCreate({ ...data, position: rules.length });
      }
      setFormOpen(false);
      setEditingRule(null);
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-4">
      <div>
        <h3 className="text-sm font-semibold text-slate-900 dark:text-slate-100">Color Formatting</h3>
        <p className="mt-1 text-sm text-slate-600 dark:text-slate-400">
          Color a value, or a whole row, when it matches a condition you set. Date fields use timing
          (for example activity older than 30 days); text fields use the words you list. The first matching
          rule wins. The app's built-in highlights, such as a matter pending with Rob or in internal review,
          are listed here too and can be edited or switched off.
        </p>
      </div>

      {formOpen ? (
        <FormattingRuleForm
          fields={fields}
          customColumns={customColumns}
          statusOptions={statusOptions}
          initial={editingRule}
          onSave={handleSave}
          onCancel={() => { setFormOpen(false); setEditingRule(null); }}
          saving={saving}
        />
      ) : (
        <Button size="sm" onClick={openNew} className="w-full sm:w-auto">
          <Plus className="h-4 w-4 mr-2" />
          Add formatting rule
        </Button>
      )}

      {rules.length === 0 ? (
        <div className="rounded-lg border border-dashed border-slate-200 p-6 text-center dark:border-slate-800">
          <Palette className="mx-auto h-6 w-6 text-slate-300 dark:text-slate-600" />
          <p className="mt-2 text-sm text-slate-500 dark:text-slate-400">No formatting rules yet.</p>
        </div>
      ) : (
        <div className="space-y-2">
          {[...rules]
            .sort((a, b) => (a.position ?? 0) - (b.position ?? 0))
            .map((rule) => (
              <div
                key={rule.id}
                className="flex items-start gap-3 rounded-lg border border-slate-200 bg-white p-3 dark:border-slate-800 dark:bg-slate-950"
              >
                <FormattingColorSwatch
                  colorKey={rule.color}
                  className="mt-0.5 h-4 w-4 shrink-0 ring-1 ring-slate-200 dark:ring-slate-700"
                />
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2">
                    <p className="text-sm font-medium text-slate-900 dark:text-slate-100">{rule.name || "Formatting rule"}</p>
                    {BUILT_IN_RULE_NAMES.has(rule.name) && (
                      <span className="rounded-full bg-slate-100 px-1.5 py-0.5 text-[10px] font-medium uppercase tracking-wide text-slate-500 dark:bg-slate-800 dark:text-slate-400">
                        Built-in
                      </span>
                    )}
                  </div>
                  <p className="mt-0.5 text-xs text-slate-500 dark:text-slate-400">
                    {describeRule(rule, fields)}
                    {rule.scope === "row" ? " · whole row" : " · value only"}
                    {rule.ignore_statuses?.length ? ` · skipped for ${rule.ignore_statuses.join(", ")}` : ""}
                  </p>
                </div>
                <div className="flex items-center gap-1">
                  <Switch
                    checked={rule.enabled !== false}
                    onCheckedChange={(checked) => onUpdate(rule.id, { enabled: checked })}
                    className="scale-90"
                  />
                  <Button variant="ghost" size="icon" className="h-8 w-8 text-slate-400" onClick={() => openEdit(rule)}>
                    <Pencil className="h-4 w-4" />
                  </Button>
                  <Button variant="ghost" size="icon" className="h-8 w-8 text-slate-400 hover:text-red-600" onClick={() => onDelete(rule.id)}>
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            ))}
        </div>
      )}
    </div>
  );
}