import { useRef, useState } from "react";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { isHexColor } from "@/lib/formattingRules";
import { cn } from "@/lib/utils";

const WHEEL = "conic-gradient(hsl(0 100% 50%), hsl(60 100% 50%), hsl(120 100% 50%), hsl(180 100% 50%), hsl(240 100% 50%), hsl(300 100% 50%), hsl(360 100% 50%))";

/** HSL (hue in degrees, lightness 0-1) to a #rrggbb string. */
const hslToHex = (hue, lightness) => {
  const a = Math.min(lightness, 1 - lightness);
  const channel = (n) => {
    const k = (n + hue / 30) % 12;
    const value = lightness - a * Math.max(-1, Math.min(k - 3, 9 - k, 1));
    return Math.round(255 * value).toString(16).padStart(2, "0");
  };
  return `#${channel(0)}${channel(8)}${channel(4)}`;
};

const colorAt = (element, clientX, clientY) => {
  const rect = element.getBoundingClientRect();
  const radius = rect.width / 2;
  const dx = clientX - (rect.left + radius);
  const dy = clientY - (rect.top + radius);
  const distance = Math.min(Math.hypot(dx, dy) / radius, 1);
  const hue = ((Math.atan2(dy, dx) * 180) / Math.PI + 90 + 360) % 360;
  return hslToHex(hue, 1 - distance * 0.5);
};

/**
 * A full color circle: the angle picks the hue, the distance from the middle
 * picks how light it is, so any color can be chosen.
 */
export default function FormattingColorWheel({ color, onChange }) {
  const [open, setOpen] = useState(false);
  const [picking, setPicking] = useState(false);
  const wheelRef = useRef(null);

  const pick = (event) => {
    if (!wheelRef.current) return;
    onChange(colorAt(wheelRef.current, event.clientX, event.clientY));
  };

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <button
          type="button"
          title="Pick any color"
          aria-label="Pick any color from the color circle"
          className={cn(
            "rounded-full ring-offset-2 ring-offset-slate-50 transition-all dark:ring-offset-slate-900",
            isHexColor(color)
              ? "ring-2 ring-slate-900 dark:ring-slate-100"
              : "ring-1 ring-slate-300 dark:ring-slate-600 hover:scale-105"
          )}
        >
          <span
            className="block h-7 w-7 rounded-full"
            style={{ background: isHexColor(color) ? color : WHEEL }}
          />
        </button>
      </PopoverTrigger>
      <PopoverContent align="start" className="w-auto p-3">
        <div
          ref={wheelRef}
          role="presentation"
          className="relative h-40 w-40 cursor-crosshair touch-none rounded-full ring-1 ring-slate-300 dark:ring-slate-700"
          style={{ background: WHEEL }}
          onPointerDown={(event) => {
            event.currentTarget.setPointerCapture(event.pointerId);
            setPicking(true);
            pick(event);
          }}
          onPointerMove={(event) => {
            if (picking) pick(event);
          }}
          onPointerUp={() => setPicking(false)}
          onPointerCancel={() => setPicking(false)}
        >
          <span
            className="pointer-events-none absolute inset-0 rounded-full"
            style={{ background: "radial-gradient(circle closest-side, #ffffff, rgba(255,255,255,0))" }}
          />
        </div>
        <div className="mt-2 flex items-center gap-2">
          <span
            className="h-6 w-6 shrink-0 rounded-full ring-1 ring-slate-300 dark:ring-slate-600"
            style={{ backgroundColor: isHexColor(color) ? color : "transparent" }}
          />
          <span className="text-xs text-slate-500 dark:text-slate-400">
            {isHexColor(color) ? color.toUpperCase() : "Drag on the circle to pick a color"}
          </span>
        </div>
      </PopoverContent>
    </Popover>
  );
}