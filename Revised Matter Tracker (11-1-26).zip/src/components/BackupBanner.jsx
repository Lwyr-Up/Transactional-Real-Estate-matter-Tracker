import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Cloud } from "lucide-react";
import { toast } from "sonner";
import { formatDistanceToNow } from "date-fns";
import { getLastBackupAt, saveBackup, usePreparedBackup } from "@/lib/backup";

const DAY_MS = 24 * 60 * 60 * 1000;

// Permanent bar at the top of the main page: one tap to save a full backup.
// Turns amber when there is data and no backup in the last day.
export default function BackupBanner({ hasData, dataVersion }) {
  const [last, setLast] = useState(() => getLastBackupAt());
  const [busy, setBusy] = useState(false);
  const prepared = usePreparedBackup(dataVersion, true);

  const overdue = hasData && Date.now() - last > DAY_MS;

  const onSave = async () => {
    setBusy(true);
    try {
      const result = await saveBackup(prepared);
      if (result === "shared") {
        toast.success("Backup saved");
        setLast(getLastBackupAt());
      } else if (result === "downloaded") {
        toast.success("Backup downloaded. Move it to iCloud Drive in Files.");
        setLast(getLastBackupAt());
      }
    } catch (e) {
      toast.error("Backup failed: " + e.message);
    } finally {
      setBusy(false);
    }
  };

  const tone = overdue
    ? "border-amber-200 bg-amber-50 dark:border-amber-900 dark:bg-amber-950/40"
    : "border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900";
  const text = overdue ? "text-amber-900 dark:text-amber-200" : "text-slate-700 dark:text-slate-300";
  const icon = overdue ? "text-amber-600 dark:text-amber-400" : "text-slate-500";

  return (
    <div className={`mb-4 flex items-center gap-3 rounded-xl border px-3 py-2 ${tone}`}>
      <Cloud className={`h-5 w-5 shrink-0 ${icon}`} />
      <p className={`flex-1 min-w-0 text-sm ${text}`}>
        <span className="font-medium">
          {last ? `Last backup ${formatDistanceToNow(last, { addSuffix: true })}` : "No backup yet"}
        </span>
        <span className="hidden sm:inline"> · data is stored only on this device. Save to Files → iCloud Drive.</span>
      </p>
      <Button size="sm" onClick={onSave} disabled={!prepared || busy}>
        {busy ? "Saving..." : "Save to iCloud"}
      </Button>
    </div>
  );
}
