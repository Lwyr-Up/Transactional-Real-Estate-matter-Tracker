import { useEffect, useRef } from "react";

/**
 * On mobile, mirrors an open sheet/dialog into the URL hash so the phone's
 * back gesture closes it instead of leaving the page. Desktop is untouched.
 */
export default function useSheetHistory(key, onBack) {
  const backRef = useRef(onBack);
  backRef.current = onBack;

  useEffect(() => {
    if (!key) return;
    if (!window.matchMedia("(max-width: 639px)").matches) return;

    const hash = `#${key}`;
    window.history.pushState({ sheet: key }, "", hash);

    const handlePop = () => backRef.current?.();
    window.addEventListener("popstate", handlePop);

    return () => {
      window.removeEventListener("popstate", handlePop);
      if (window.location.hash === hash) {
        window.history.replaceState(null, "", window.location.pathname + window.location.search);
      }
    };
  }, [key]);
}