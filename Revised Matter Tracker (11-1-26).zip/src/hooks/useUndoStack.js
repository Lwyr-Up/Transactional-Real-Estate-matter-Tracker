import { useRef, useState } from "react";

// Small localStorage-free undo history. Each entry describes how to reverse
// one change: { kind: "update" | "create" | "delete", ... }.
export default function useUndoStack(limit = 20) {
  const [stack, setStack] = useState([]);
  const stackRef = useRef([]);

  const commit = (next) => {
    stackRef.current = next;
    setStack(next);
  };

  const push = (entry) => {
    commit([entry, ...stackRef.current].slice(0, limit));
  };

  const pop = () => {
    const [first, ...rest] = stackRef.current;
    commit(rest);
    return first || null;
  };

  const clear = () => commit([]);

  return { stack, latest: stack[0] || null, push, pop, clear };
}