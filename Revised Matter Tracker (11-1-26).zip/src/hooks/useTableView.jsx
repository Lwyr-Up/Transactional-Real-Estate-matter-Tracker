import { useEffect, useState } from "react";

// Wide screens always get the table. Phones held sideways (landscape) also get
// the table, even though they are narrower than the desktop breakpoint.
const computeShowTable = () => {
  if (typeof window === "undefined") return false;
  const width = window.innerWidth;
  const height = window.innerHeight;
  if (width >= 1024) return true;
  return width > height && width >= 560;
};

export function useTableView() {
  const [showTable, setShowTable] = useState(computeShowTable);

  useEffect(() => {
    const update = () => setShowTable(computeShowTable());
    update();
    window.addEventListener("resize", update);
    window.addEventListener("orientationchange", update);
    return () => {
      window.removeEventListener("resize", update);
      window.removeEventListener("orientationchange", update);
    };
  }, []);

  return showTable;
}

export default useTableView;