import react from '@vitejs/plugin-react'
import { defineConfig } from 'vite'
import path from 'node:path'
import fs from 'node:fs'
import crypto from 'node:crypto'

// After the build, list every emitted file inside the service worker so the
// whole app is cached for offline use the first time it loads.
function precachePlugin() {
  let outDir = 'dist'
  return {
    name: 'precache-manifest',
    apply: 'build',
    configResolved(cfg) {
      outDir = path.resolve(cfg.root, cfg.build.outDir)
    },
    closeBundle() {
      const swPath = path.join(outDir, 'sw.js')
      if (!fs.existsSync(swPath)) return
      const files = []
      const walk = (dir) => {
        for (const name of fs.readdirSync(dir)) {
          const full = path.join(dir, name)
          if (fs.statSync(full).isDirectory()) walk(full)
          else files.push(path.relative(outDir, full).split(path.sep).join('/'))
        }
      }
      walk(outDir)
      const list = files.filter((f) => f !== 'sw.js')
      const version = crypto
        .createHash('sha1')
        .update(list.map((f) => f + fs.statSync(path.join(outDir, f)).size).join('|'))
        .digest('hex')
        .slice(0, 10)
      const src = fs
        .readFileSync(swPath, 'utf8')
        .replace('__PRECACHE_FILES__', JSON.stringify(list))
        .replace('__CACHE_VERSION__', version)
      fs.writeFileSync(swPath, src)
    },
  }
}

// https://vite.dev/config/
export default defineConfig({
  // Relative base so the app works from any folder (GitHub Pages, Netlify, ...)
  base: './',
  logLevel: 'error',
  plugins: [react(), precachePlugin()],
  resolve: {
    alias: { '@': path.resolve(import.meta.dirname, 'src') },
  },
})
