# Leasing Matter Tracker (offline, on-device)

A local-only copy of the Base44 "Commercial Real Estate Matter Tracker".
All data is stored in your browser's IndexedDB on the device. Nothing is sent
anywhere: no accounts, no emails, no servers.

## Put it on your iPad

1. Create a free account at github.com and a new **public** repository.
2. Upload every file and folder from this project (including the hidden
   `.github` folder) to the repository's `main` branch.
3. In the repository: **Settings > Pages > Build and deployment > Source:
   GitHub Actions**.
4. Open the **Actions** tab. The "Deploy to GitHub Pages" run builds the app
   (about 2 minutes). When it is green, your address is
   `https://YOUR-NAME.github.io/YOUR-REPO/`.
5. Open that address in **Safari** on the iPad and let it finish loading.
6. Tap **Share > Add to Home Screen**.
7. Open the app once from the Home Screen, then switch on Airplane Mode and open
   it again to confirm it works offline.

Your data lives only on that device. If you clear Safari website data or delete
the Home Screen app, it is erased. Use **Data Management > Backup & Restore**
regularly and keep the file in Files / iCloud Drive.

## Moving your Base44 data in

In Base44 open each collection (Matter, Client, Property, OpposingParty,
Partner) > More Actions > Export (CSV). In this app go to **Data Management >
Backup & Restore > Import from Base44 (CSV)**, choose the matching list, then
the file. Do not upload the CSVs to GitHub.

## What changed from the Base44 version

- Login is replaced by a single local profile. An optional PIN can be set under
  Data Management > Security.
- Emailed login alerts, emailed backups, weekly auto-email and the ban-user
  feature are removed (they need a server). Backups are now one-tap saves to iCloud Drive via the share sheet, with a
  daily on-screen prompt when a backup is due.
- "Delete Account" is now "Erase All Data" (it clears this device only).
- New: full JSON backup/restore (matters, lists, columns, rules) and CSV import.

## Develop locally

```
npm install
npm run dev      # http://localhost:5173
npm run build    # output in dist/
```
