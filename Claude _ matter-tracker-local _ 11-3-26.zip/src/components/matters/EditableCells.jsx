import { useState } from "react";
import { format } from "date-fns";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";
import { Command, CommandEmpty, CommandGroup, CommandItem, CommandList } from "@/components/ui/command";
import { CalendarIcon } from "lucide-react";
import { cn } from "@/lib/utils";
import { formatMatterDate } from "@/lib/matterColumns";
import { isMobileViewport } from "@/lib/isMobileViewport";

export const highlightMatch = (text, search) => {
  if (!text || !search) return text || "—";
  const lowerText = text.toLowerCase();
  const lowerSearch = search.toLowerCase();
  const index = lowerText.indexOf(lowerSearch);

  if (index !== -1) {
    return (
      <>
        {text.substring(0, index)}
        <span className="bg-yellow-200 text-slate-900">{text.substring(index, index + search.length)}</span>
        {text.substring(index + search.length)}
      </>
    );
  }
  return text;
};

export function EditableTextCell({ value, onSave, className, searchTerm, placeholder = "—", compact = false }) {
  const [isEditing, setIsEditing] = useState(false);
  const [tempValue, setTempValue] = useState(value || "");

  const handleSave = () => {
    onSave(tempValue);
    setIsEditing(false);
  };

  if (isEditing) {
    return (
      <Input
        value={tempValue}
        onChange={(e) => setTempValue(e.target.value)}
        onBlur={handleSave}
        onKeyDown={(e) => {
          if (e.key === "Enter") handleSave();
          if (e.key === "Escape") { setTempValue(value || ""); setIsEditing(false); }
        }}
        className={cn("text-sm", compact ? "h-9" : "h-7")}
        autoFocus
      />
    );
  }

  return (
    <div
      onClick={(e) => { e.stopPropagation(); setIsEditing(true); setTempValue(value || ""); }}
      className={cn(
        "cursor-pointer hover:bg-slate-100 dark:hover:bg-slate-800 px-2 py-1 rounded truncate",
        compact ? "min-h-[36px] flex items-center" : "min-h-[28px]",
        className
      )}
    >
      {highlightMatch(value, searchTerm) || placeholder}
    </div>
  );
}

export function EditableNumberCell({ value, onSave, suffix, className, compact = false }) {
  const [isEditing, setIsEditing] = useState(false);
  const [tempValue, setTempValue] = useState(value ?? "");

  const handleSave = () => {
    const trimmed = String(tempValue).trim();
    onSave(trimmed === "" ? "" : Number(trimmed.replace(/,/g, "")));
    setIsEditing(false);
  };

  if (isEditing) {
    return (
      <Input
        type="number"
        value={tempValue}
        onChange={(e) => setTempValue(e.target.value)}
        onBlur={handleSave}
        onKeyDown={(e) => {
          if (e.key === "Enter") handleSave();
          if (e.key === "Escape") { setTempValue(value ?? ""); setIsEditing(false); }
        }}
        className={cn("text-sm", compact ? "h-9" : "h-7")}
        autoFocus
      />
    );
  }

  return (
    <div
      onClick={(e) => { e.stopPropagation(); setIsEditing(true); setTempValue(value ?? ""); }}
      className={cn(
        "cursor-pointer hover:bg-slate-100 dark:hover:bg-slate-800 px-2 py-1 rounded",
        compact ? "min-h-[36px] flex items-center" : "min-h-[28px]",
        className
      )}
    >
      {value !== undefined && value !== null && value !== "" ? `${Number(value).toLocaleString()}${suffix || ""}` : "—"}
    </div>
  );
}

export function EditableSelectCell({ value, onSave, options = [], className, searchTerm, compact = false }) {
  const [isOpen, setIsOpen] = useState(false);
  const [inputValue, setInputValue] = useState(value || "");

  const filteredOptions = options.filter((opt) =>
    opt.toLowerCase().includes(inputValue.toLowerCase())
  );

  return (
    <Popover open={isOpen} onOpenChange={setIsOpen}>
      <PopoverTrigger asChild>
        <div
          onClick={(e) => { e.stopPropagation(); setIsOpen(true); setInputValue(""); }}
          className={cn(
            "cursor-pointer hover:bg-slate-100 dark:hover:bg-slate-800 px-2 py-1 rounded truncate",
            compact ? "min-h-[36px] flex items-center" : "min-h-[28px]",
            className
          )}
        >
          {highlightMatch(value, searchTerm)}
        </div>
      </PopoverTrigger>
      <PopoverContent className="w-[220px] p-0" align="start">
        <Command>
          <div className="p-2">
            <Input
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              placeholder="Search or type new..."
              className="h-9 text-sm"
              autoFocus
            />
          </div>
          <CommandList>
            <CommandGroup>
              {inputValue.trim() && !options.some((o) => o.toLowerCase() === inputValue.trim().toLowerCase()) && (
                <CommandItem
                  value={`__new_${inputValue}`}
                  onSelect={() => { onSave(inputValue.trim()); setIsOpen(false); }}
                  className="text-slate-600"
                >
                  Use "{inputValue.trim()}"
                </CommandItem>
              )}
              {filteredOptions.length === 0 ? (
                <CommandEmpty>No options found.</CommandEmpty>
              ) : (
                filteredOptions.map((option) => (
                  <CommandItem
                    key={option}
                    value={option}
                    onSelect={() => { onSave(option); setIsOpen(false); }}
                  >
                    {option}
                  </CommandItem>
                ))
              )}
            </CommandGroup>
          </CommandList>
        </Command>
      </PopoverContent>
    </Popover>
  );
}

export function EditableDateCell({ value, onSave, className, compact = false }) {
  const toDate = (val) => (val ? new Date(String(val).split("T")[0] + "T00:00:00") : undefined);
  const isoValue = value ? String(value).split("T")[0] : "";

  const cellClass = cn(
    "flex items-center gap-1 w-full hover:bg-slate-100 dark:hover:bg-slate-800 px-2 py-1 rounded text-left",
    compact ? "min-h-[36px]" : "min-h-[28px]",
    className
  );

  // On phones the system date picker is used: it opens full screen and is
  // confirmed with the native check mark, like the comment date field.
  if (isMobileViewport()) {
    return (
      <label className={cn(cellClass, "relative cursor-pointer")} onClick={(e) => e.stopPropagation()}>
        <CalendarIcon className="h-3 w-3 shrink-0 text-slate-400 dark:text-slate-500" />
        <span className="truncate">{formatMatterDate(value)}</span>
        <input
          type="date"
          value={isoValue}
          max={format(new Date(), "yyyy-MM-dd")}
          onChange={(e) => onSave(e.target.value)}
          onClick={(e) => e.stopPropagation()}
          onPointerDown={(e) => e.stopPropagation()}
          aria-label="Change date"
          className="absolute inset-0 h-full w-full cursor-pointer opacity-0 dark:[color-scheme:dark]"
        />
      </label>
    );
  }

  return (
    <Popover>
      <PopoverTrigger asChild>
        <button
          type="button"
          onClick={(e) => e.stopPropagation()}
          className={cn(
            "flex items-center gap-1 w-full hover:bg-slate-100 dark:hover:bg-slate-800 px-2 py-1 rounded text-left",
            compact ? "min-h-[36px]" : "min-h-[28px]",
            className
          )}
        >
          <CalendarIcon className="h-3 w-3 shrink-0 text-slate-400 dark:text-slate-500" />
          <span className="truncate">{formatMatterDate(value)}</span>
        </button>
      </PopoverTrigger>
      <PopoverContent
        className="w-auto p-0"
        align="start"
        onClick={(e) => e.stopPropagation()}
        onPointerDown={(e) => e.stopPropagation()}
      >
        <Calendar
          mode="single"
          selected={toDate(value)}
          onSelect={(date) => {
            if (!date) return;
            onSave(format(date, "yyyy-MM-dd"));
          }}
          disabled={(date) => date > new Date()}
          initialFocus
        />
        <div className="border-t p-2">
          <Button
            variant="ghost"
            size="sm"
            className="w-full text-slate-600 dark:text-slate-300"
            onClick={() => onSave("")}
          >
            Clear date
          </Button>
        </div>
      </PopoverContent>
    </Popover>
  );
}