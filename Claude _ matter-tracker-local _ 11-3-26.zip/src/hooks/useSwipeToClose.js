import { useRef } from "react";

/**
 * Detects a deliberate rightward swipe so a mobile panel can be dismissed by
 * dragging it sideways, without touching the element's vertical scrolling.
 */
export default function useSwipeToClose(onClose, { distance = 80 } = {}) {
  const start = useRef(null);

  return {
    onTouchStart: (e) => {
      if (e.touches.length !== 1) {
        start.current = null;
        return;
      }
      const touch = e.touches[0];
      start.current = { x: touch.clientX, y: touch.clientY };
    },
    onTouchEnd: (e) => {
      const from = start.current;
      start.current = null;
      if (!from) return;
      const touch = e.changedTouches[0];
      const dx = touch.clientX - from.x;
      const dy = touch.clientY - from.y;
      // Rightward and clearly horizontal, so a vertical scroll never closes it
      if (dx >= distance && Math.abs(dx) > Math.abs(dy) * 1.5) onClose?.();
    },
    onTouchCancel: () => {
      start.current = null;
    },
  };
}