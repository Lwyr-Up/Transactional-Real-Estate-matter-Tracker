import { useState } from "react";
import { getOpposingPartyDetails } from "@/lib/opposingParty";

const empty = () => ({ name: "", entity_type: "", state_of_formation: "" });
export default function useOpposingPartyEditor({ items, onCreate, onUpdate, onDelete, onUpdateMattersField }) {
  const [draft, setDraft] = useState(empty);
  const [editingId, setEditingId] = useState(null);
  const [edit, setEdit] = useState(empty);
  const [deleting, setDeleting] = useState(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const save = async (item) => {
    const value = item ? edit : draft;
    const data = Object.fromEntries(Object.entries(value).map(([key, text]) => [key, text.trim()]));
    if (!data.name) return;
    if (items.some((other) => other.id !== item?.id && getOpposingPartyDetails(other).name.toLowerCase() === data.name.toLowerCase())) {
      setError("An opposing party with this name already exists."); return;
    }
    setBusy(true); setError("");
    try {
      if (item) {
        await onUpdate(item.id, data);
        if (item.name !== data.name) await onUpdateMattersField?.("opposing_party", item.name, data.name);
        setEditingId(null);
      } else { await onCreate(data); setDraft(empty()); }
    } catch (failure) { setError(failure.message || "Unable to save opposing party."); }
    finally { setBusy(false); }
  };
  const remove = async (item = deleting) => {
    if (!item) return;
    setBusy(true); setError("");
    try { await onDelete(item.id); setDeleting(null); }
    catch (failure) { setError(failure.message || "Unable to delete opposing party."); }
    finally { setBusy(false); }
  };
  const startEdit = (item) => { setEdit(getOpposingPartyDetails(item)); setEditingId(item.id); setError(""); };
  return { draft, setDraft, editingId, edit, setEdit, deleting, setDeleting, busy, error, save, remove, startEdit, cancel: () => setEditingId(null) };
}