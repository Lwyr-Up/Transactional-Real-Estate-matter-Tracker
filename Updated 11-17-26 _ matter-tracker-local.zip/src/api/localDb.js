// Local-only data layer: stores everything in this device's IndexedDB.
// Mimics the small slice of the Base44 entity API the app uses
// (list / filter / get / create / update / delete), so the UI code barely changes.

const DB_NAME = "matter-tracker-local";
const DB_VERSION = 3; // v2 added AssetType, InstrumentType, MatterCategory, MatterColumn; v3 adds PendingWithOption, StatusOption, LeaseProvisionOption, FormattingRule (existing data is kept)
export const ENTITY_NAMES = [
  "Matter",
  "Client",
  "Property",
  "OpposingParty",
  "Partner",
  "InstrumentType",
  "AssetType",
  "MatterCategory",
  "MatterColumn",
  "PendingWithOption",
  "StatusOption",
  "LeaseProvisionOption",
  "FormattingRule",
];

export const LOCAL_USER = {
  id: "local-user",
  email: "local@this-device",
  full_name: "Local User",
  role: "admin",
};

let dbPromise = null;

function openDb() {
  if (dbPromise) return dbPromise;
  dbPromise = new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onupgradeneeded = () => {
      const db = req.result;
      for (const name of ENTITY_NAMES) {
        if (!db.objectStoreNames.contains(name)) {
          db.createObjectStore(name, { keyPath: "id" });
        }
      }
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
  return dbPromise;
}

function tx(storeName, mode, fn) {
  return openDb().then(
    (db) =>
      new Promise((resolve, reject) => {
        const t = db.transaction(storeName, mode);
        const store = t.objectStore(storeName);
        let result;
        Promise.resolve(fn(store))
          .then((r) => {
            result = r;
          })
          .catch(reject);
        t.oncomplete = () => resolve(result);
        t.onerror = () => reject(t.error);
        t.onabort = () => reject(t.error);
      })
  );
}

// Tell the rest of the app (e.g. the prepared iCloud backup) that stored data changed.
const notifyChanged = () => {
  try {
    if (typeof window !== "undefined") window.dispatchEvent(new Event("matter-db-changed"));
  } catch {
    /* ignore */
  }
};

const reqToPromise = (req) =>
  new Promise((resolve, reject) => {
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });

const newId = () =>
  typeof crypto !== "undefined" && crypto.randomUUID
    ? crypto.randomUUID()
    : `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}`;

function sortRows(rows, sort) {
  if (!sort) return rows;
  const desc = sort.startsWith("-");
  const key = desc ? sort.slice(1) : sort;
  return [...rows].sort((a, b) => {
    const av = a[key];
    const bv = b[key];
    if (av == null && bv == null) return 0;
    if (av == null) return 1;
    if (bv == null) return -1;
    let cmp;
    if (typeof av === "number" && typeof bv === "number") cmp = av - bv;
    else cmp = String(av).localeCompare(String(bv), undefined, { sensitivity: "base" });
    return desc ? -cmp : cmp;
  });
}

const isPlainObject = (v) => v !== null && typeof v === "object" && !Array.isArray(v);

// One field against one condition: a plain value, or an operator object such as
// { $in: [...] }, { $ne: x }, { $regex: "abc", $options: "i" }.
function fieldMatches(value, cond) {
  if (isPlainObject(cond) && Object.keys(cond).some((k) => k.startsWith("$"))) {
    return Object.entries(cond).every(([op, arg]) => {
      switch (op) {
        case "$ne": return Array.isArray(value) ? !value.includes(arg) : value !== arg;
        case "$in": return Array.isArray(value) ? value.some((x) => arg.includes(x)) : arg.includes(value);
        case "$nin": return Array.isArray(value) ? !value.some((x) => arg.includes(x)) : !arg.includes(value);
        case "$gt": return value != null && value > arg;
        case "$gte": return value != null && value >= arg;
        case "$lt": return value != null && value < arg;
        case "$lte": return value != null && value <= arg;
        case "$exists": return (value !== undefined && value !== null) === !!arg;
        case "$regex": {
          let re;
          try { re = new RegExp(arg, cond.$options || ""); } catch { return false; }
          return value != null && re.test(String(value));
        }
        case "$options": return true;
        default: return true;
      }
    });
  }
  // Mongo-style: an array field "equals" a value when it contains it.
  if (Array.isArray(value) && !Array.isArray(cond)) return value.includes(cond);
  return value === cond;
}

function matches(row, query) {
  if (!query) return true;
  return Object.entries(query).every(([k, v]) => {
    if (k === "created_by") return true; // single local user: every row is "mine"
    if (k === "$or") return v.some((q) => matches(row, q));
    if (k === "$and") return v.every((q) => matches(row, q));
    if (k === "$nor") return !v.some((q) => matches(row, q));
    return fieldMatches(row[k], v);
  });
}

function makeEntity(name) {
  return {
    async list(sort, limit) {
      const rows = await tx(name, "readonly", (s) => reqToPromise(s.getAll()));
      const sorted = sortRows(rows, sort);
      return limit ? sorted.slice(0, limit) : sorted;
    },
    // filter(query, sort, limit) returns an array. filter(query, { sort, limit, cursor })
    // returns a page { items, has_more, next_cursor } (the cursor is just an offset here).
    async filter(query, sortOrOptions, limit) {
      const rows = await tx(name, "readonly", (s) => reqToPromise(s.getAll()));
      if (isPlainObject(sortOrOptions)) {
        const { sort, limit: pageSize, cursor, skip } = sortOrOptions;
        const sorted = sortRows(rows.filter((r) => matches(r, query)), sort);
        const start = Number(cursor || skip || 0) || 0;
        const end = pageSize ? start + pageSize : sorted.length;
        return {
          items: sorted.slice(start, end),
          has_more: end < sorted.length,
          next_cursor: end < sorted.length ? String(end) : null,
        };
      }
      const sorted = sortRows(rows.filter((r) => matches(r, query)), sortOrOptions);
      return limit ? sorted.slice(0, limit) : sorted;
    },
    async get(id) {
      return tx(name, "readonly", (s) => reqToPromise(s.get(id)));
    },
    async create(data) {
      const now = new Date().toISOString();
      const row = {
        ...data,
        id: newId(),
        created_date: data.created_date || now,
        updated_date: data.updated_date || now,
        created_by: LOCAL_USER.email,
      };
      await tx(name, "readwrite", (s) => reqToPromise(s.add(row)));
      notifyChanged();
      return row;
    },
    async bulkCreate(items) {
      const now = new Date().toISOString();
      const rows = items.map((data) => ({
        ...data,
        id: newId(),
        created_date: data.created_date || now,
        updated_date: data.updated_date || now,
        created_by: LOCAL_USER.email,
      }));
      await tx(name, "readwrite", (s) => {
        rows.forEach((r) => s.add(r));
      });
      notifyChanged();
      return rows;
    },
    // bulkUpdate([{ id, ...fields }, ...]) in one transaction; returns the updated rows.
    async bulkUpdate(updates) {
      const now = new Date().toISOString();
      const out = await tx(name, "readwrite", async (s) => {
        const done = [];
        for (const { id, ...data } of updates) {
          const existing = await reqToPromise(s.get(id));
          if (!existing) continue;
          const row = { ...existing, ...data, id, updated_date: now };
          await reqToPromise(s.put(row));
          done.push(row);
        }
        return done;
      });
      notifyChanged();
      return out;
    },
    async update(id, data) {
      const updated = await tx(name, "readwrite", async (s) => {
        const existing = await reqToPromise(s.get(id));
        if (!existing) throw new Error(`${name} ${id} not found`);
        const row = { ...existing, ...data, id, updated_date: new Date().toISOString() };
        await reqToPromise(s.put(row));
        return row;
      });
      notifyChanged();
      return updated;
    },
    async delete(id) {
      await tx(name, "readwrite", (s) => reqToPromise(s.delete(id)));
      notifyChanged();
      return { success: true };
    },
    async clear() {
      await tx(name, "readwrite", (s) => reqToPromise(s.clear()));
      notifyChanged();
    },
  };
}

export const entities = Object.fromEntries(ENTITY_NAMES.map((n) => [n, makeEntity(n)]));

// ---- Whole-database backup / restore (JSON) ----

export async function exportAll() {
  const data = {};
  for (const n of ENTITY_NAMES) data[n] = await entities[n].list();
  return {
    app: "matter-tracker-local",
    version: 1,
    exported_at: new Date().toISOString(),
    data,
  };
}

export async function importAll(backup, { replace = true } = {}) {
  if (!backup || backup.app !== "matter-tracker-local" || !backup.data) {
    throw new Error("This is not a Matter Tracker backup file");
  }
  for (const n of ENTITY_NAMES) {
    const rows = Array.isArray(backup.data[n]) ? backup.data[n] : [];
    await tx(n, "readwrite", (s) => {
      if (replace) s.clear();
      rows.forEach((r) => s.put(r));
    });
  }
  notifyChanged();
}

// ---- Import of Base44 CSV collection exports ----

const NUMBER_FIELDS = new Set(["sublet_sqft", "rentable_sqft", "lease_term_months", "position", "days"]);
const BOOLEAN_FIELDS = new Set([
  "has_extension_option",
  "has_right_of_first_offer",
  "has_right_of_first_refusal",
  "has_expansion_option",
  "has_termination_option",
  "has_parking",
  "archived",
  "lease_fields",
  "enabled",
]);
const ARRAY_FIELDS = new Set(["amendment_types", "related_matter_ids", "options", "flag_values", "lease_provisions", "text_values", "ignore_statuses"]);
const OBJECT_FIELDS = new Set(["custom_fields"]);
const DROP_FIELDS = new Set(["id", "_id", "created_by", "created_by_id", "is_sample"]);

function coerceRow(raw) {
  const out = {};
  for (const [key, val] of Object.entries(raw)) {
    if (DROP_FIELDS.has(key)) continue;
    if (val === "" || val == null) continue;
    if (NUMBER_FIELDS.has(key)) {
      const n = Number(val);
      if (!Number.isNaN(n)) out[key] = n;
    } else if (BOOLEAN_FIELDS.has(key)) {
      out[key] = String(val).toLowerCase() === "true";
    } else if (OBJECT_FIELDS.has(key)) {
      if (typeof val === "object") out[key] = val;
      else {
        try {
          const parsed = JSON.parse(String(val));
          if (parsed && typeof parsed === "object") out[key] = parsed;
        } catch {
          /* ignore unreadable custom field data */
        }
      }
    } else if (ARRAY_FIELDS.has(key)) {
      if (Array.isArray(val)) out[key] = val;
      else {
        const s = String(val).trim();
        try {
          const parsed = JSON.parse(s);
          out[key] = Array.isArray(parsed) ? parsed : [String(parsed)];
        } catch {
          out[key] = s.split(/[,;]\s*/).filter(Boolean);
        }
      }
    } else {
      out[key] = val;
    }
  }
  return out;
}

export async function importCsvRows(entityName, rows) {
  if (!entities[entityName]) throw new Error(`Unknown list: ${entityName}`);
  const cleaned = rows.map(coerceRow).filter((r) => Object.keys(r).length > 0);
  if (cleaned.length === 0) throw new Error("No usable rows found in that file");
  await entities[entityName].bulkCreate(cleaned);
  return cleaned.length;
}

// Erase everything this app stores on the device (used by "Erase All Data").
export async function eraseAllData() {
  for (const n of ENTITY_NAMES) await entities[n].clear();
  try {
    localStorage.removeItem("matterTrackerCache");
    Object.keys(localStorage)
      .filter((k) => k.startsWith("formattingRulesBuiltInsSeeded_"))
      .forEach((k) => localStorage.removeItem(k));
  } catch {
    /* ignore */
  }
}

// Ask the browser not to evict our data when storage is low.
export async function requestPersistentStorage() {
  try {
    if (navigator.storage && navigator.storage.persist) {
      return await navigator.storage.persist();
    }
  } catch {
    /* ignore */
  }
  return false;
}
