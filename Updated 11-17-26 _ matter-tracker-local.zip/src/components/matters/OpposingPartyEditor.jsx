import { Button } from "@/components/ui/button";
import { AlertDialog, AlertDialogContent, AlertDialogHeader, AlertDialogTitle, AlertDialogDescription, AlertDialogFooter, AlertDialogCancel, AlertDialogAction } from "@/components/ui/alert-dialog";
import OpposingPartyFields from "@/components/matters/OpposingPartyFields";
import OpposingPartyRow from "@/components/matters/OpposingPartyRow";
import UnusedListWarning from "@/components/matters/UnusedListWarning";
import useOpposingPartyEditor from "@/hooks/useOpposingPartyEditor";
import { useListMatters, getUsedValues, isValueUnused } from "@/lib/listUsage";
import { getOpposingPartyName } from "@/lib/opposingParty";

export default function OpposingPartyEditor(props) {
  const editor = useOpposingPartyEditor(props);
  const matters = useListMatters();
  const used = matters.length ? getUsedValues(matters, "opposing_party") : null;
  const unused = (item) => isValueUnused(used, item.name);
  return (
    <div className="w-full min-w-0 space-y-4">
      <div className="min-w-0 space-y-3 rounded-lg border bg-muted/30 p-3">
        <OpposingPartyFields value={editor.draft} onChange={editor.setDraft} />
        <p className="text-xs text-muted-foreground">Entity type and state are saved here; only the name appears on matters and reports.</p>
        <Button className="w-full" onClick={() => editor.save()} disabled={editor.busy || !editor.draft.name.trim()}>{editor.busy ? "Saving…" : "Add Opposing Party"}</Button>
      </div>
      {editor.error && <p role="alert" className="break-words text-sm text-destructive">{editor.error}</p>}
      <UnusedListWarning items={used ? props.items.filter(unused) : []} label="Opposing Party" getLabel={getOpposingPartyName} onDeleteUnused={async (items) => { for (const item of items) await editor.remove(item); }} />
      <div className="min-w-0 divide-y rounded-lg border">
        {!props.items.length && <p className="p-4 text-center text-sm text-muted-foreground">No opposing parties added yet.</p>}
        {props.items.map((item) => <OpposingPartyRow key={item.id} item={item} editing={editor.editingId === item.id} value={editor.edit} onChange={editor.setEdit} onEdit={() => editor.startEdit(item)} onSave={() => editor.save(item)} onCancel={editor.cancel} onDelete={() => editor.setDeleting(item)} busy={editor.busy} unused={unused(item)} />)}
      </div>
      <AlertDialog open={!!editor.deleting} onOpenChange={(open) => !open && editor.setDeleting(null)}>
        <AlertDialogContent><AlertDialogHeader><AlertDialogTitle>Remove opposing party?</AlertDialogTitle><AlertDialogDescription>This removes {getOpposingPartyName(editor.deleting)} from the list. Existing matters are not changed.</AlertDialogDescription></AlertDialogHeader><AlertDialogFooter><AlertDialogCancel disabled={editor.busy}>Cancel</AlertDialogCancel><AlertDialogAction disabled={editor.busy} onClick={() => editor.remove()}>Remove</AlertDialogAction></AlertDialogFooter></AlertDialogContent>
      </AlertDialog>
    </div>
  );
}