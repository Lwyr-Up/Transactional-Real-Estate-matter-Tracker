import { useId } from "react";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";

export default function OpposingPartyFields({ value, onChange }) {
  const id = useId();
  const field = (key) => ({ value: value[key] || "", onChange: (event) => onChange({ ...value, [key]: event.target.value }) });
  return (
    <div className="min-w-0 space-y-3">
      <div className="min-w-0 space-y-1">
        <Label htmlFor={`${id}-name`}>Name *</Label>
        <Textarea id={`${id}-name`} {...field("name")} rows={2} placeholder="Opposing party name" className="min-h-16 w-full resize-y bg-background text-base text-foreground" />
      </div>
      <div className="grid min-w-0 grid-cols-1 gap-3 md:grid-cols-2">
        <div className="min-w-0 space-y-1"><Label htmlFor={`${id}-type`}>Entity type</Label><Input id={`${id}-type`} {...field("entity_type")} placeholder="e.g. Limited liability company" className="min-w-0 bg-background text-base text-foreground" /></div>
        <div className="min-w-0 space-y-1"><Label htmlFor={`${id}-state`}>State of formation</Label><Input id={`${id}-state`} {...field("state_of_formation")} placeholder="e.g. Delaware" className="min-w-0 bg-background text-base text-foreground" /></div>
      </div>
    </div>
  );
}