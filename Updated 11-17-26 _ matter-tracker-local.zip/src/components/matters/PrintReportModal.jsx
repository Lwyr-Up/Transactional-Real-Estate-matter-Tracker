import { useState, useRef, useMemo, useEffect, lazy, Suspense } from "react";
import { format } from "date-fns";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { FileSpreadsheet, Printer, Loader2 } from "lucide-react";
import {
  buildReportColumns,
  orderReportColumns,
  groupReportColumns,
  getDefaultSelection,
  getReportValue,
} from "@/lib/reportColumns";
import { printReport } from "@/lib/printReport";
import { getReportCellStyle } from "@/lib/reportFormatting";
import ReportColumnPicker from "@/components/matters/ReportColumnPicker";
import MultiSelectFilter from "@/components/matters/MultiSelectFilter";
import EoyReportSettings from "@/components/matters/EoyReportSettings";
const EoyReportPreview = lazy(() => import("@/components/matters/EoyReportPreview"));
import {
  computeEoyReport,
  loadEoyConfig,
  saveEoyConfig,
  getTileCatalog,
  getGroupOptions,
  getFilterFields,
  formatTileValue,
} from "@/lib/eoyReport";

const INSTRUMENT_TYPES = [
  "All Types", "Amendment", "Assignment", "Easement", "Estoppel Certificate", 
  "Lease", "Letter of Intent", "License Agreement", "Other", 
  "Purchase Agreement", "Sale Agreement", "SNDA", "Sublease"
];
const PENDING_WITH_OPTIONS = ["All", "Rob", "Client", "Landlord", "Tenant", "Pending Internal Review"];
const STATUS_OPTIONS = ["Closed", "Deal Died", "On Hold", "Open", "Pending Execution"];

// Report columns are built from the same list the matter table uses, so anything the
// user edits or adds there (including their own custom columns) is available here too.


export default function PrintReportModal({ open, onOpenChange, matters, archivedMatters = [], properties = [], instrumentTypes = [], pendingWithOptions = PENDING_WITH_OPTIONS, statusOptions = STATUS_OPTIONS, customColumns = [], formattingRules = [] }) {
  const instrumentOptions = instrumentTypes.length ? instrumentTypes.map((t) => t.name) : INSTRUMENT_TYPES.slice(1);
  const [reportType, setReportType] = useState("standard");
  const [filters, setFilters] = useState({
    statuses: [],
    instrumentTypes: [],
    pendingWith: "All"
  });
  const [columns, setColumns] = useState(() =>
    getDefaultSelection(buildReportColumns(customColumns))
  );
  const [selectedYear, setSelectedYear] = useState(new Date().getFullYear());
  const [eoyConfig, setEoyConfig] = useState(loadEoyConfig);
  const printRef = useRef();
  const eoyPrintRef = useRef();
  const [includeColors, setIncludeColors] = useState(false);
  const [isPrinting, setIsPrinting] = useState(false);
  const [pdfUrl, setPdfUrl] = useState("");
  const [printError, setPrintError] = useState("");

  // The report layout the user has arranged is kept between visits.
  useEffect(() => {
    saveEoyConfig(eoyConfig);
  }, [eoyConfig]);

  // Follow the column order the user arranged on the main matter table.
  // Recomputed each time the modal opens so recent rearrangements are picked up.
  const orderedColumns = useMemo(
    () => orderReportColumns(buildReportColumns(customColumns)),
    [customColumns, open]
  );

  // The user's own print order, adjustable in the column picker
  const [columnOrder, setColumnOrder] = useState([]);

  // Each time the report opens, start from whatever columns the table currently shows
  // so newly added or edited fields are included without any setup.
  useEffect(() => {
    if (open) {
      setColumns(getDefaultSelection(buildReportColumns(customColumns)));
      setColumnOrder(orderReportColumns(buildReportColumns(customColumns)).map((c) => c.key));
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open]);

  // Print order = the user's arrangement, with anything added since appended at the end.
  const reportColumns = useMemo(() => {
    const baseKeys = columnOrder.length ? columnOrder : orderedColumns.map((c) => c.key);
    const result = baseKeys
      .map((key) => orderedColumns.find((c) => c.key === key))
      .filter(Boolean);
    orderedColumns.forEach((col) => {
      if (!result.some((c) => c.key === col.key)) result.push(col);
    });
    return result;
  }, [columnOrder, orderedColumns]);

  const selectedColumns = useMemo(
    () => reportColumns.filter((col) => columns[col.key]),
    [reportColumns, columns]
  );

  const reorderColumns = (from, to) => {
    const keys = selectedColumns.map((c) => c.key);
    if (from === to || from < 0 || to < 0 || to >= keys.length) return;
    const [moved] = keys.splice(from, 1);
    keys.splice(to, 0, moved);
    setColumnOrder([
      ...keys,
      ...orderedColumns.map((c) => c.key).filter((k) => !keys.includes(k)),
    ]);
  };

  const handlePrint = async () => {
    const content = (reportType === "standard" ? printRef : eoyPrintRef).current;
    if (!content || isPrinting) return;
    // Reserve the tab during the tap, before asynchronous PDF generation.
    const viewer = window.open("about:blank", "_blank");
    if (viewer) {
      viewer.document.title = "Preparing PDF";
      viewer.document.body.textContent = "Preparing your printable PDF…";
    }
    setIsPrinting(true);
    setPrintError("");
    setPdfUrl("");
    try {
      const url = await printReport(content, { includeColors });
      setPdfUrl(url);
      if (viewer && !viewer.closed) viewer.location.replace(url);
    } catch (error) {
      viewer?.close();
      setPrintError(error.message || "Unable to create the PDF. Please try again.");
    } finally {
      setIsPrinting(false);
    }
  };

  // End of Year Report: everything the user can arrange lives in `eoyConfig`.
  const eoyReport = useMemo(
    () =>
      computeEoyReport({
        matters: [...matters, ...archivedMatters],
        columns: reportColumns,
        properties,
        year: selectedYear,
        config: eoyConfig,
      }),
    [matters, archivedMatters, properties, selectedYear, eoyConfig, reportColumns]
  );

  const tileCatalog = useMemo(() => getTileCatalog(reportColumns), [reportColumns]);
  const groupOptions = useMemo(() => getGroupOptions(reportColumns), [reportColumns]);
  const filterFields = useMemo(
    () => getFilterFields(reportColumns, [...matters, ...archivedMatters]),
    [reportColumns, matters, archivedMatters]
  );

  // Live values shown beside every metric in the "Add metric" picker.
  const metricPreview = useMemo(() => {
    const preview = computeEoyReport({
      matters: [...matters, ...archivedMatters],
      columns: reportColumns,
      properties,
      year: selectedYear,
      config: {
        ...eoyConfig,
        tiles: tileCatalog.map((c) => ({ key: c.id, id: c.id, label: c.label })),
      },
    });
    return preview.tiles.reduce((acc, tile) => {
      acc[tile.id] = tile;
      return acc;
    }, {});
  }, [matters, archivedMatters, properties, selectedYear, eoyConfig, reportColumns, tileCatalog]);

  const availableYears = useMemo(() => {
    const years = new Set();
    const currentYear = new Date().getFullYear();
    for (let y = currentYear; y >= currentYear - 5; y--) {
      years.add(y);
    }
    return Array.from(years);
  }, []);

  const filteredMatters = matters.filter(matter => {
    const matchesStatus = filters.statuses.length === 0 || filters.statuses.includes(matter.status);
    const matchesType = filters.instrumentTypes.length === 0 || filters.instrumentTypes.includes(matter.instrument_type);
    const matchesPending = filters.pendingWith === "All" || matter.pending_with === filters.pendingWith;
    return matchesStatus && matchesType && matchesPending;
  });

  const toggleStatus = (status) => {
    setFilters(prev => ({
      ...prev,
      statuses: prev.statuses.includes(status)
        ? prev.statuses.filter(s => s !== status)
        : [...prev.statuses, status]
    }));
  };

  const handleExport = async () => {
    const xlsxModule = await import("@e965/xlsx");
    const lib = xlsxModule.default ?? xlsxModule;
    if (reportType === "standard") {
      // Standard report export
      const selected = selectedColumns;

      const data = filteredMatters.map(matter => {
        const row = {};
        selected.forEach((column) => {
          row[column.label] = getReportValue(matter, column) || "—";
        });
        return row;
      });

      const ws = lib.utils.json_to_sheet(data);
      const wb = lib.utils.book_new();
      lib.utils.book_append_sheet(wb, ws, "Matters");
      lib.writeFile(wb, `Matter_Report_${format(new Date(), 'yyyy-MM-dd')}.xlsx`);
    } else {
      // EOY export mirrors the report on screen: tiles in order, then one sheet per chart.
      const sheetName = (name, fallback) =>
        (name || fallback).replace(/[\[\]:*?/\\]/g, "").slice(0, 31) || fallback;

      const wb = lib.utils.book_new();

      const summaryData = eoyReport.tiles.map((tile) => ({
        Metric: tile.label,
        Value: `${formatTileValue(tile)}${tile.sub ? ` ${tile.sub}` : ""}`,
      }));
      lib.utils.book_append_sheet(
        wb,
        lib.utils.json_to_sheet(summaryData.length ? summaryData : [{ Metric: "No metrics selected", Value: "" }]),
        "Summary"
      );

      eoyReport.charts.forEach((chart, index) => {
        const config = eoyConfig.charts.find((c) => c.id === chart.id);
        const groupLabel = groupOptions.find((o) => o.key === config?.groupBy)?.label || "Group";
        const rows = chart.data.map((entry) => ({
          [groupLabel]: entry.name,
          Count: entry.value,
          Percentage: chart.total ? `${((entry.value / chart.total) * 100).toFixed(1)}%` : "",
        }));
        lib.utils.book_append_sheet(
          wb,
          lib.utils.json_to_sheet(rows),
          sheetName(chart.title, `Chart ${index + 1}`)
        );
      });

      const noteRows = [
        { Section: eoyConfig.titles.highlights, Text: eoyConfig.notes.highlights },
        { Section: eoyConfig.titles.closing, Text: eoyConfig.notes.closing },
      ].filter((row) => row.Text?.trim());
      if (noteRows.length) {
        lib.utils.book_append_sheet(wb, lib.utils.json_to_sheet(noteRows), "Notes");
      }

      lib.writeFile(wb, `EOY_Report_${selectedYear}.xlsx`);
    }
  };

  const toggleColumn = (col) => {
    setColumns(prev => ({ ...prev, [col]: !prev[col] }));
  };

  const setAllColumns = (checked) => {
    setColumns(reportColumns.reduce((acc, col) => ({ ...acc, [col.key]: checked }), {}));
  };

  const columnGroups = useMemo(
    () => groupReportColumns(reportColumns),
    [reportColumns]
  );

  const renderReportCell = (matter, column) => {
    const value = getReportValue(matter, column);
    if (!value) return "—";
    if (column.key === "comments" || column.kind === "custom") {
      const entries = String(value).split("\n").filter((l) => l.trim());
      return entries.length > 1 ? entries.map((entry, i) => <div key={i}>{entry}</div>) : value;
    }
    return value;
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="print-report-dialog w-[calc(100vw-1rem)] max-w-4xl max-h-[90vh] overflow-y-auto overflow-x-hidden p-0 sm:max-w-4xl sm:p-0">
        <div className="min-w-0 space-y-4 p-4 pr-5 sm:p-6">
        <DialogHeader>
          <DialogTitle className="text-xl font-semibold">Print Report</DialogTitle>
        </DialogHeader>

        <Tabs value={reportType} onValueChange={setReportType} className="min-w-0 w-full">
          <TabsList className="grid h-auto w-full grid-cols-2 mb-4">
            <TabsTrigger value="standard" className="text-xs sm:text-sm">Standard Report</TabsTrigger>
            <TabsTrigger value="eoy" className="text-xs sm:text-sm">End of Year Report</TabsTrigger>
          </TabsList>

          <TabsContent value="standard" className="space-y-6">
          {/* Filters */}
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div>
              <Label className="text-sm text-slate-600 mb-2 block">
                Instrument Type <span className="text-xs font-normal text-slate-400">(select one or more)</span>
              </Label>
              <MultiSelectFilter
                options={instrumentOptions}
                values={filters.instrumentTypes}
                onChange={(instrumentTypes) => setFilters((p) => ({ ...p, instrumentTypes }))}
                allLabel="All Types"
              />
            </div>
            <div>
              <Label className="text-sm text-slate-600 mb-2 block">Pending With</Label>
              <Select value={filters.pendingWith} onValueChange={(v) => setFilters(p => ({ ...p, pendingWith: v }))}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {pendingWithOptions.map(p => <SelectItem key={p} value={p}>{p}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div>
            <Label className="text-sm text-slate-600 mb-2 block">
              Status <span className="text-xs font-normal text-slate-400">(leave all unchecked to include all)</span>
            </Label>
            <div className="grid grid-cols-1 gap-2 sm:flex sm:flex-wrap sm:gap-4">
              {statusOptions.map((status) => (
                <div key={status} className="flex items-center space-x-2">
                  <Checkbox
                    id={`status-${status}`}
                    checked={filters.statuses.includes(status)}
                    onCheckedChange={() => toggleStatus(status)}
                  />
                  <Label htmlFor={`status-${status}`} className="text-sm cursor-pointer">{status}</Label>
                </div>
              ))}
            </div>
          </div>

          {/* Column Selection */}
          <div>
            <Label className="text-sm text-slate-600 mb-2 block">Columns to Include</Label>
            <ReportColumnPicker
              groups={columnGroups}
              selected={columns}
              ordered={selectedColumns}
              onToggle={toggleColumn}
              onReorder={reorderColumns}
              onSelectAll={() => setAllColumns(true)}
              onClear={() => setAllColumns(false)}
            />
          </div>

          {/* Preview */}
                          <div className="border rounded-lg p-2 sm:p-4 bg-white max-h-80 overflow-auto print-preview">
            <div ref={printRef}>
              <h1 style={{ textAlign: 'center', color: '#000' }}>Matter Report</h1>
              <p className="date" style={{ textAlign: 'center', marginBottom: '16px', color: '#000' }}>Generated: {format(new Date(), 'MMMM d, yyyy')}</p>
              <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '11px', color: '#000' }}>
                <thead>
                  <tr>
                    {selectedColumns.map(({ key, label }) => (
                      <th key={key} style={{ border: '1px solid #d1d5db', padding: '8px', backgroundColor: '#f3f4f6', fontWeight: '600', color: '#000' }}>{label}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {filteredMatters.map(matter => (
                    <tr key={matter.id}>
                      {selectedColumns.map((column) => (
                        <td
                          key={column.key}
                          style={{
                            border: '1px solid #d1d5db',
                            padding: '8px',
                            color: '#000',
                            ...(column.key === 'comments' || column.key === 'lease_provisions' ? { fontSize: '10px' } : {}),
                            ...(column.key === 'comments' ? { maxWidth: '200px' } : {}),
                            ...(includeColors ? getReportCellStyle(formattingRules, matter, column) : {})
                          }}
                        >
                          {renderReportCell(matter, column)}
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
              <p style={{ marginTop: '10px', fontSize: '11px', color: '#666', textAlign: 'center' }}>
                Total: {filteredMatters.length} matter(s)
              </p>
            </div>
          </div>
          </TabsContent>

          <TabsContent value="eoy" className="space-y-4">
            <div className="flex flex-wrap items-end justify-between gap-3">
              <div className="w-40">
                <Label className="text-sm text-slate-600 mb-2 block">Select Year</Label>
                <Select value={selectedYear.toString()} onValueChange={(v) => setSelectedYear(parseInt(v))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {availableYears.map(y => <SelectItem key={y} value={y.toString()}>{y}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <p className="text-xs text-slate-500">
                {eoyReport.yearCount} matter(s) in {selectedYear}
              </p>
            </div>

            <EoyReportSettings
              config={eoyConfig}
              onChange={(patch) => setEoyConfig((prev) => ({ ...prev, ...patch }))}
              year={selectedYear}
              statusOptions={statusOptions}
              catalog={tileCatalog}
              fields={filterFields}
              preview={metricPreview}
              groupOptions={groupOptions}
            />

            <div className="border rounded-lg p-2 sm:p-4 bg-white max-h-[500px] overflow-auto print-preview">
              <Suspense fallback={<div className="py-10 text-center text-sm text-slate-500 dark:text-slate-400">Loading chart…</div>}>
                <EoyReportPreview
                  report={eoyReport}
                  config={eoyConfig}
                  year={selectedYear}
                  printRef={eoyPrintRef}
                />
              </Suspense>
            </div>
          </TabsContent>
        </Tabs>

        <div className="space-y-2 border-t pt-3">
          <div className="flex items-start gap-2"><Checkbox id="report-colors" checked={includeColors} onCheckedChange={(checked) => setIncludeColors(checked === true)} disabled={isPrinting} /><Label htmlFor="report-colors" className="cursor-pointer leading-snug">Include color formatting in PDF</Label></div>
          {printError && <p role="alert" className="text-sm text-destructive">{printError}</p>}
          {pdfUrl && <div className="flex flex-wrap gap-4 text-sm"><a href={pdfUrl} target="_blank" rel="noopener noreferrer" className="font-medium text-primary underline">Open printable PDF</a><a href={pdfUrl} download={reportType === "standard" ? "Matter_Report.pdf" : `EOY_Report_${selectedYear}.pdf`} className="font-medium text-primary underline">Download PDF</a></div>}
        </div>
        <DialogFooter className="sticky bottom-0 z-10 -mx-4 grid grid-cols-1 gap-2 border-t bg-background/95 px-4 py-3 backdrop-blur sm:static sm:mx-0 sm:flex sm:justify-end sm:gap-0 sm:space-x-2 sm:border-0 sm:bg-transparent sm:p-0 sm:backdrop-blur-none">
                      <Button variant="outline" onClick={() => onOpenChange(false)} className="order-3 w-full sm:order-1 sm:w-auto">Cancel</Button>
                      <Button variant="outline" onClick={handlePrint} disabled={isPrinting || (reportType === "standard" && !selectedColumns.length)} className="order-2 w-full text-base sm:w-auto sm:text-sm">
                        {isPrinting ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <Printer className="h-4 w-4 mr-2" />}
                        {isPrinting ? "Creating PDF…" : "Print PDF"}
                      </Button>
                      <Button onClick={handleExport} className="order-1 w-full bg-slate-900 text-base text-white hover:bg-slate-800 dark:bg-slate-100 dark:text-slate-900 dark:hover:bg-white sm:order-3 sm:w-auto sm:text-sm">
                        <FileSpreadsheet className="h-4 w-4 mr-2" />
                        Save as Excel
                      </Button>
                    </DialogFooter>
        </div>
      </DialogContent>
    </Dialog>
  );
}