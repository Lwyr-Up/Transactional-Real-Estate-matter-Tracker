import { Button } from "@/components/ui/button";
import { Pencil, Trash2 } from "lucide-react";
import { getOpposingPartyName } from "@/lib/opposingParty";
import OpposingPartyFields from "@/components/matters/OpposingPartyFields";

export default function OpposingPartyRow({ item, editing, value, onChange, onEdit, onSave, onCancel, onDelete, busy, unused }) {
  return (
    <div className="min-w-0 space-y-3 p-3">
      {editing ? <>
        <OpposingPartyFields value={value} onChange={onChange} />
        <div className="flex flex-wrap justify-end gap-2"><Button variant="outline" onClick={onCancel} disabled={busy}>Cancel</Button><Button onClick={onSave} disabled={busy || !value.name.trim()}>{busy ? "Saving…" : "Save"}</Button></div>
      </> : <div className="flex min-w-0 items-start gap-2">
        <div className="min-w-0 flex-1 break-words text-sm text-foreground">{getOpposingPartyName(item)}{unused && <span className="ml-2 text-xs text-muted-foreground">Unused</span>}</div>
        <div className="flex shrink-0 gap-1"><Button variant="ghost" size="icon" aria-label="Edit opposing party" onClick={onEdit}><Pencil /></Button><Button variant="ghost" size="icon" aria-label="Delete opposing party" onClick={onDelete}><Trash2 /></Button></div>
      </div>}
    </div>
  );
}