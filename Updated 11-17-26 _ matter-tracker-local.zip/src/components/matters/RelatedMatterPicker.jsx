import { useState } from "react";
import { useQuery, useInfiniteQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { getOpposingPartyName } from "@/lib/opposingParty";

const describe = (matter) => [matter.client_name, matter.property_address, getOpposingPartyName(matter.opposing_party), matter.instrument_type, matter.date_received].filter(Boolean).join(" · ");

export default function RelatedMatterPicker({ matterId, ownerEmail, matters, selected = [], onChange }) {
  const [search, setSearch] = useState("");
  const current = (matters || []).find((matter) => matter.id === matterId);
  const client = String(current?.client_name || "").trim();
  const property = String(current?.property_address || "").trim();
  // Matters of the same client in the same building are the likeliest relatives, so they lead the list.
  const hasContext = !!client && !!property;

  const searchFilter = () => {
    const escaped = search.trim().replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    return ["client_name", "property_address", "opposing_party", "instrument_type"].map((field) => ({ [field]: { $regex: escaped, $options: "i" } }));
  };

  const priorityQuery = useQuery({
    queryKey: ["relatedMatterPriority", matterId, ownerEmail, search, client, property],
    enabled: !!ownerEmail && hasContext,
    queryFn: () => base44.entities.Matter.filter({
      created_by: ownerEmail,
      client_name: client,
      property_address: property,
      id: { $ne: matterId || "" },
      archived: { $ne: true },
      ...(search.trim() ? { $or: searchFilter() } : {}),
    }, { sort: "-date_received", limit: 100 }).then((page) => page.items ?? page),
  });

  const query = useInfiniteQuery({
    queryKey: ["relatedMatterChoices", matterId, ownerEmail, search], initialPageParam: undefined,
    enabled: !!ownerEmail,
    queryFn: ({ pageParam }) => {
      const filter = { created_by: ownerEmail, id: { $ne: matterId || "" }, archived: { $ne: true } };
      if (search.trim()) filter.$or = searchFilter();
      return base44.entities.Matter.filter(filter, { sort: "-date_received", limit: 30, cursor: pageParam });
    },
    getNextPageParam: (page) => page.has_more ? page.next_cursor : undefined,
  });

  const priority = priorityQuery.data || [];
  const priorityIds = new Set(priority.map((matter) => matter.id));
  const choices = [...priority, ...(query.data?.pages.flatMap((page) => page.items) || []).filter((matter) => !priorityIds.has(matter.id))];
  const toggle = (id, checked) => onChange(checked ? [...new Set([...selected, id])] : selected.filter((value) => value !== id));
  const loading = query.isLoading || (hasContext && priorityQuery.isLoading);

  return (
    <div className="min-w-0 space-y-3 rounded-lg border p-3">
      <Label htmlFor="related-matter-search">Manually linked related matters</Label>
      <p className="text-xs text-muted-foreground">Select matters even when their client, property, or opposing party differs. Links work in both directions; automatic matches stay available.</p>
      <Input id="related-matter-search" value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Search matters to link…" />
      {selected.length > 0 && <div className="space-y-1">{selected.map((id) => <div key={id} className="flex min-w-0 items-center gap-2 text-xs"><span className="min-w-0 flex-1 break-words">{describe(matters.find((matter) => matter.id === id) || choices.find((matter) => matter.id === id) || { client_name: "Linked matter" })}</span><Button type="button" size="sm" variant="ghost" onClick={() => toggle(id, false)}>Unlink</Button></div>)}</div>}
      <div className="max-h-48 space-y-2 overflow-y-auto">
        {loading ? <p className="text-sm text-muted-foreground">Loading matters…</p> : query.isError ? <p role="alert" className="text-sm text-destructive">Unable to load matters. <button type="button" className="underline" onClick={() => query.refetch()}>Retry</button></p> : !choices.length ? <p className="text-sm text-muted-foreground">No other matters found.</p> : choices.map((matter) => <label key={matter.id} className="flex cursor-pointer items-start gap-2 rounded-md p-2 text-sm hover:bg-accent"><Checkbox checked={selected.includes(matter.id)} onCheckedChange={(checked) => toggle(matter.id, checked === true)} /><span className="min-w-0 break-words">{describe(matter)}</span>{priorityIds.has(matter.id) && <span className="ml-auto shrink-0 rounded bg-indigo-100 px-1.5 py-0.5 text-[10px] font-medium uppercase tracking-wide text-indigo-700 dark:bg-indigo-950 dark:text-indigo-300">Same client &amp; property</span>}</label>)}
      </div>
      {query.hasNextPage && <Button type="button" variant="outline" size="sm" disabled={query.isFetchingNextPage} onClick={() => query.fetchNextPage()}>{query.isFetchingNextPage ? "Loading…" : "Load more matters"}</Button>}
    </div>
  );
}