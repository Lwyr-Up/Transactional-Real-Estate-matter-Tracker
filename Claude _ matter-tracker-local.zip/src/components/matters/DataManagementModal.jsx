import { useEffect, useRef, useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Checkbox } from "@/components/ui/checkbox";
import { GripVertical } from "lucide-react";
import { DragDropContext, Droppable, Draggable } from "@hello-pangea/dnd";
import { toast } from "sonner";
import { base44 } from "@/api/base44Client";
import { DEFAULT_FILTER_CARDS, loadFilterCards, saveFilterCards } from "@/lib/filterCards";
import ListManagementModal from "./ListManagementModal";
import BackupRestoreTab from "./BackupRestoreTab";
import FormattingRulesTab from "./FormattingRulesTab";
import SwipeActionsSettings from "./SwipeActionsSettings";
import DeleteAccountDialog from "@/components/DeleteAccountDialog";
import PinSettings from "./PinSettings";

const STATUS_OPTIONS = ["Open", "Pending Execution", "On Hold", "Closed", "Deal Died"];
const INSTRUMENT_TYPES = [
  "Amendment", "Assignment", "Consent to Sublease", "Easement", "Estoppel Certificate", 
  "Lease", "Letter of Intent", "License Agreement", "Other", 
  "Purchase Agreement", "Sale Agreement", "SNDA", "Sublease"
];
const PENDING_WITH_OPTIONS = ["Rob", "Client", "Landlord", "Tenant", "Pending Internal Review"];

// Tabs wrap onto their own rows on phones instead of squeezing every label together.
const TAB_TRIGGER_CLASS =
  "h-full whitespace-normal text-center text-xs leading-snug px-2 py-2 sm:text-sm sm:px-3 sm:py-1";

export default function DataManagementModal({ 
  open, 
  onOpenChange, 
  initialTab = "backup",
  editCardId = null,
  allMatters, 
  matters, 
  archivedMatters,
  formattingRules = [],
  customColumns = [],
  onCreateFormattingRule,
  onUpdateFormattingRule,
  onDeleteFormattingRule,
  onRestore,
  onDeleteAll,
  clients = [],
  properties = [],
  opposingParties = [],
  partners = [],
  matterCategories = [],
  instrumentTypes = [],
  assetTypes = [],
  leaseProvisionOptions = [],
  pendingWithOptions = [],
  pendingWithRecords = [],
  statusOptions = [],
  statusRecords = [],
  onCreateClient,
  onUpdateClient,
  onDeleteClient,
  onCreateProperty,
  onUpdateProperty,
  onDeleteProperty,
  onCreateOpposingParty,
  onUpdateOpposingParty,
  onDeleteOpposingParty,
  onCreatePartner,
  onUpdatePartner,
  onDeletePartner,
  onCreateCategory,
  onUpdateCategory,
  onDeleteCategory,
  onCreateInstrumentType,
  onUpdateInstrumentType,
  onDeleteInstrumentType,
  onCreateAssetType,
  onUpdateAssetType,
  onDeleteAssetType,
  onCreateLeaseProvision,
  onUpdateLeaseProvision,
  onDeleteLeaseProvision,
  onCreatePendingWith,
  onUpdatePendingWith,
  onDeletePendingWith,
  onCreateStatus,
  onUpdateStatus,
  onDeleteStatus,
  onUpdateMattersField
}) {
  const dialogRef = useRef(null);
  const instrumentTypeOptions = instrumentTypes.length ? instrumentTypes.map((t) => t.name) : INSTRUMENT_TYPES;
  const pendingWithFilterOptions = pendingWithOptions.length ? pendingWithOptions : PENDING_WITH_OPTIONS;
  const statusFilterOptions = statusOptions.length ? statusOptions : STATUS_OPTIONS;
  const [backupDownloaded, setBackupDownloaded] = useState(false);
  const [filterCards, setFilterCards] = useState(loadFilterCards);
  const [editingCard, setEditingCard] = useState(null);
  const [editForm, setEditForm] = useState({
    label: "",
    statuses: [],
    instrumentTypes: [],
    pendingWith: []
  });
  const [showDuplicates, setShowDuplicates] = useState(false);
  const [tab, setTab] = useState(initialTab);

  // Opened from a dashboard card: jump to that card's setup, ready to edit.
  useEffect(() => {
    if (!open) return;
    setTab(initialTab);
    if (!editCardId) return;
    const cards = loadFilterCards();
    setFilterCards(cards);
    const card = cards.find((c) => c.id === editCardId);
    if (card) handleEditCard(card);
  }, [open, initialTab, editCardId]);

  const handleFilterCardToggle = (id) => {
    const newCards = filterCards.map(card => 
      card.id === id ? { ...card, enabled: !card.enabled } : card
    );
    setFilterCards(newCards);
    saveFilterCards(newCards);
  };

  const handleEditCard = (card) => {
    setEditingCard(card.id);
    setEditForm({
      label: card.label,
      statuses: card.filters.statuses || [],
      instrumentTypes: card.filters.instrumentTypes || [],
      pendingWith: card.filters.pendingWith || []
    });
  };

  const handleSaveCard = () => {
    const newCards = filterCards.map(card => 
      card.id === editingCard ? {
        ...card,
        label: editForm.label,
        filters: {
          statuses: editForm.statuses,
          instrumentTypes: editForm.instrumentTypes,
          pendingWith: editForm.pendingWith
        }
      } : card
    );
    setFilterCards(newCards);
    saveFilterCards(newCards);
    setEditingCard(null);
    toast.success("Filter card updated");
  };

  const handleAddCard = () => {
    if (filterCards.length >= 5) {
      toast.error("Maximum 5 filter cards allowed");
      return;
    }
    const newCard = {
      id: Date.now().toString(),
      label: "New Filter",
      enabled: true,
      filters: {}
    };
    const newCards = [...filterCards, newCard];
    setFilterCards(newCards);
    saveFilterCards(newCards);
    handleEditCard(newCard);
  };

  const handleDeleteCard = (id) => {
    const newCards = filterCards.filter(card => card.id !== id);
    setFilterCards(newCards);
    saveFilterCards(newCards);
    toast.success("Filter card deleted");
  };

  const handleResetCards = () => {
    setFilterCards(DEFAULT_FILTER_CARDS());
    saveFilterCards(DEFAULT_FILTER_CARDS());
    toast.success("Filter cards reset to default");
  };

  // Cards appear on the dashboard in this order.
  const handleCardDragEnd = (result) => {
    if (!result.destination || result.destination.index === result.source.index) return;
    const newCards = [...filterCards];
    const [moved] = newCards.splice(result.source.index, 1);
    newCards.splice(result.destination.index, 0, moved);
    setFilterCards(newCards);
    saveFilterCards(newCards);
  };

  const toggleFilterItem = (filterType, value) => {
    setEditForm(prev => {
      const current = prev[filterType] || [];
      const updated = current.includes(value)
        ? current.filter(v => v !== value)
        : [...current, value];
      return { ...prev, [filterType]: updated };
    });
  };



  const findDuplicates = () => {
    const seen = new Map();
    const duplicates = [];

    allMatters.forEach(matter => {
      const key = `${matter.client_name}-${matter.property_address}-${matter.instrument_type}-${matter.opposing_party}`;
      if (seen.has(key)) {
        if (!duplicates.find(d => d.id === seen.get(key).id)) {
          duplicates.push(seen.get(key));
        }
        duplicates.push(matter);
      } else {
        seen.set(key, matter);
      }
    });

    return duplicates;
  };

  const handleDeleteDuplicates = async () => {
    const duplicates = findDuplicates();
    
    if (duplicates.length === 0) {
      toast.info("No duplicate matters found");
      return;
    }

    if (!confirm(`Found ${duplicates.length} duplicate matters. Delete them? This cannot be undone.`)) {
      return;
    }

    try {
      for (const matter of duplicates) {
        await base44.entities.Matter.delete(matter.id);
      }
      toast.success(`Deleted ${duplicates.length} duplicate matters`);
      window.location.reload();
    } catch (error) {
      toast.error("Failed to delete duplicates: " + error.message);
    }
  };

  const handleDeleteAll = async () => {
    if (!backupDownloaded) {
      toast.error("Please download a backup before deleting all matters");
      return;
    }
    
    if (!confirm("Are you sure you want to delete ALL matters? This cannot be undone. Make sure your backup is safe.")) {
      return;
    }

    try {
      await onDeleteAll();
      setBackupDownloaded(false);
      toast.success("All matters deleted successfully");
    } catch (error) {
      toast.error("Failed to delete matters: " + error.message);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent ref={dialogRef} className="max-w-2xl h-[85dvh] overflow-y-auto sm:h-auto sm:max-h-[85vh]">
        <DialogHeader>
          <DialogTitle>Data Management</DialogTitle>
        </DialogHeader>

        <Tabs
          value={tab}
          className="w-full"
          onValueChange={(value) => {
            setTab(value);
            dialogRef.current?.scrollTo({ top: 0 });
          }}
        >
          <TabsList className="grid h-auto w-full grid-cols-2 items-stretch gap-1 p-1 sm:grid-cols-3 sticky top-0 z-10 shadow-sm">
            <TabsTrigger value="backup" className={TAB_TRIGGER_CLASS}>Backup & Restore</TabsTrigger>
            <TabsTrigger value="delete" className={TAB_TRIGGER_CLASS}>Delete All</TabsTrigger>
            <TabsTrigger value="filters" className={TAB_TRIGGER_CLASS}>Filter Cards</TabsTrigger>
            <TabsTrigger value="formatting" className={TAB_TRIGGER_CLASS}>Formatting</TabsTrigger>
            <TabsTrigger value="lists" className={TAB_TRIGGER_CLASS}>Manage Lists</TabsTrigger>
            <TabsTrigger value="swipe" className={TAB_TRIGGER_CLASS}>Swipe</TabsTrigger>
          </TabsList>

          <TabsContent value="backup" className="space-y-6 pt-4">
            <BackupRestoreTab
              allMatters={allMatters}
              onRestore={onRestore}
              backupDownloaded={backupDownloaded}
              onBackupDownloaded={() => setBackupDownloaded(true)}
            />

            <PinSettings />

            <div className="border-t pt-4 space-y-3">
              <div>
                <h3 className="text-sm font-semibold mb-2 text-red-600 dark:text-red-400">Erase All Data on This Device</h3>
                <p className="text-sm text-slate-600 dark:text-slate-400">
                  Permanently erase everything this app has saved on this device. There is no account to delete.
                  This cannot be undone, so save a full backup first.
                </p>
              </div>
              <DeleteAccountDialog />
            </div>
          </TabsContent>

          <TabsContent value="delete" className="space-y-6 pt-4">
            <div className="space-y-4">
              <div>
                <h3 className="text-sm font-semibold mb-2 text-orange-600">Delete Duplicate Matters</h3>
                <p className="text-sm text-slate-600 mb-4">
                  Find and delete duplicate matters based on Client, Property, Instrument Type, and Opposing Party.
                </p>
                
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-4">
                  <p className="text-sm text-blue-800 font-medium">
                    {findDuplicates().length} duplicate matters found
                  </p>
                  {findDuplicates().length > 0 && (
                    <Button 
                      variant="ghost" 
                      size="sm"
                      onClick={() => setShowDuplicates(!showDuplicates)}
                      className="mt-2 text-blue-600 hover:text-blue-700"
                    >
                      {showDuplicates ? "Hide Details" : "Show Details"}
                    </Button>
                  )}
                </div>

                {showDuplicates && findDuplicates().length > 0 && (
                  <div className="border rounded-lg max-h-60 overflow-y-auto mb-4">
                    <div className="divide-y">
                      {findDuplicates().map((matter, index) => (
                        <div key={matter.id} className="p-3 hover:bg-slate-50">
                          <div className="text-sm font-medium text-slate-900">{matter.client_name}</div>
                          <div className="text-xs text-slate-600 mt-0.5">{matter.property_address}</div>
                          <div className="text-xs text-slate-500 mt-0.5">
                            <span className="font-medium">Opposing:</span> {matter.opposing_party} • <span className="font-medium">Type:</span> {matter.instrument_type}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                <Button 
                  variant="outline" 
                  onClick={handleDeleteDuplicates}
                  disabled={findDuplicates().length === 0}
                  className="w-full border-orange-500 text-orange-600 hover:bg-orange-50"
                >
                  Delete Duplicates
                </Button>
              </div>

              <div className="border-t pt-4">
                <h3 className="text-sm font-semibold mb-2 text-red-600">Delete All Matters</h3>
                <p className="text-sm text-slate-600 mb-4">
                  Permanently delete all matters from the system. You must download a backup first as a safety measure.
                </p>
                
                <div className="bg-red-50 border border-red-200 rounded-lg p-4 mb-4">
                  <p className="text-sm text-red-800 font-medium mb-2">
                    ⚠️ Warning: This action cannot be undone!
                  </p>
                  <p className="text-sm text-red-700">
                    All {allMatters.length} matters (including {archivedMatters.length} archived) will be permanently deleted.
                  </p>
                </div>

                {!backupDownloaded && (
                  <div className="bg-amber-50 border border-amber-200 rounded-lg p-4 mb-4">
                    <p className="text-sm text-amber-800">
                      You must download a backup before you can delete all matters.
                    </p>
                  </div>
                )}

                <Button 
                  variant="destructive" 
                  onClick={handleDeleteAll}
                  disabled={!backupDownloaded}
                  className="w-full"
                >
                  Delete All Matters
                </Button>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="filters" className="space-y-4 pt-4">
            {editingCard ? (
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-semibold">Edit Filter Card</h3>
                  <Button variant="ghost" size="sm" onClick={() => setEditingCard(null)}>Cancel</Button>
                </div>

                <div className="space-y-4">
                  <div>
                    <Label className="text-sm mb-2 block text-slate-700 dark:text-slate-300">Card Label</Label>
                    <Input
                      value={editForm.label}
                      onChange={(e) => setEditForm(prev => ({ ...prev, label: e.target.value }))}
                      placeholder="e.g., Active Leases"
                      className="dark:bg-slate-900 dark:border-slate-700 dark:text-slate-200"
                    />
                  </div>

                  <div>
                    <Label className="text-sm mb-2 block text-slate-700 dark:text-slate-300">Status Filters</Label>
                    <div className="space-y-2">
                      {statusFilterOptions.map(status => (
                        <div key={status} className="flex items-center space-x-2">
                          <Checkbox
                            id={`status-${status}`}
                            checked={editForm.statuses.includes(status)}
                            onCheckedChange={() => toggleFilterItem('statuses', status)}
                          />
                          <Label htmlFor={`status-${status}`} className="text-sm cursor-pointer text-slate-700 dark:text-slate-300">{status}</Label>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div>
                    <Label className="text-sm mb-2 block text-slate-700 dark:text-slate-300">Instrument Type Filters</Label>
                    <div className="space-y-2 max-h-40 overflow-y-auto">
                      {instrumentTypeOptions.map(type => (
                        <div key={type} className="flex items-center space-x-2">
                          <Checkbox
                            id={`type-${type}`}
                            checked={editForm.instrumentTypes.includes(type)}
                            onCheckedChange={() => toggleFilterItem('instrumentTypes', type)}
                          />
                          <Label htmlFor={`type-${type}`} className="text-sm cursor-pointer text-slate-700 dark:text-slate-300">{type}</Label>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div>
                    <Label className="text-sm mb-2 block text-slate-700 dark:text-slate-300">Pending With Filters</Label>
                    <div className="space-y-2">
                      {pendingWithFilterOptions.map(option => (
                        <div key={option} className="flex items-center space-x-2">
                          <Checkbox
                            id={`pending-${option}`}
                            checked={editForm.pendingWith.includes(option)}
                            onCheckedChange={() => toggleFilterItem('pendingWith', option)}
                          />
                          <Label htmlFor={`pending-${option}`} className="text-sm cursor-pointer text-slate-700 dark:text-slate-300">{option}</Label>
                        </div>
                      ))}
                    </div>
                  </div>

                  <Button onClick={handleSaveCard} className="w-full">Save Changes</Button>
                </div>
              </div>
            ) : (
              <div>
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-sm font-semibold text-slate-900 dark:text-slate-100">Filter Cards ({filterCards.length}/5)</h3>
                  <div className="flex gap-2">
                    <Button variant="ghost" size="sm" onClick={handleResetCards}>Reset</Button>
                    <Button size="sm" onClick={handleAddCard} disabled={filterCards.length >= 5}>Add Card</Button>
                  </div>
                </div>

                <p className="text-xs text-slate-500 dark:text-slate-400 mb-3">
                  Drag the cards to change the order they appear on the dashboard.
                </p>

                <DragDropContext onDragEnd={handleCardDragEnd}>
                  <Droppable droppableId="filter-cards">
                    {(provided) => (
                      <div ref={provided.innerRef} {...provided.droppableProps} className="space-y-3">
                        {filterCards.map((card, index) => (
                          <Draggable draggableId={card.id} index={index} key={card.id}>
                            {(dragProvided, snapshot) => (
                              <div
                                ref={dragProvided.innerRef}
                                {...dragProvided.draggableProps}
                                className={`flex items-center justify-between p-3 bg-slate-50 dark:bg-slate-900 rounded-lg ${
                                  snapshot.isDragging ? "shadow-lg ring-2 ring-indigo-400 dark:ring-indigo-500" : ""
                                }`}
                              >
                                <div className="flex items-center gap-3 flex-1 min-w-0">
                                  <div
                                    {...dragProvided.dragHandleProps}
                                    className="p-1 -m-1 cursor-grab active:cursor-grabbing text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 touch-none"
                                    title="Drag to reorder"
                                  >
                                    <GripVertical className="h-4 w-4" />
                                  </div>
                                  <Checkbox
                                    checked={card.enabled}
                                    onCheckedChange={() => handleFilterCardToggle(card.id)}
                                  />
                                  <div className="flex-1 min-w-0">
                                    <p className="text-sm font-medium text-slate-900 dark:text-slate-100">{card.label}</p>
                                    <p className="text-xs text-slate-500 dark:text-slate-400">
                                      {Object.values(card.filters).flat().length || 0} filters
                                    </p>
                                  </div>
                                </div>
                                <div className="flex gap-1 sm:gap-2 shrink-0">
                                  <Button variant="ghost" size="sm" onClick={() => handleEditCard(card)}>Edit</Button>
                                  <Button variant="ghost" size="sm" onClick={() => handleDeleteCard(card.id)}>Delete</Button>
                                </div>
                              </div>
                            )}
                          </Draggable>
                        ))}
                        {provided.placeholder}
                      </div>
                    )}
                  </Droppable>
                </DragDropContext>
              </div>
            )}
          </TabsContent>

          <TabsContent value="formatting" className="space-y-4 pt-4">
            <FormattingRulesTab
              rules={formattingRules}
              customColumns={customColumns}
              statusOptions={statusOptions}
              onCreate={onCreateFormattingRule}
              onUpdate={onUpdateFormattingRule}
              onDelete={onDeleteFormattingRule}
            />
          </TabsContent>

          <TabsContent value="swipe" className="space-y-4 pt-4">
            <SwipeActionsSettings />
          </TabsContent>

          <TabsContent value="lists" className="space-y-4 pt-4">
            <ListManagementModal
              open={true}
              onOpenChange={() => {}}
              matters={allMatters}
              clients={clients}
              properties={properties}
              opposingParties={opposingParties}
              partners={partners}
              matterCategories={matterCategories}
              instrumentTypes={instrumentTypes}
              assetTypes={assetTypes}
              leaseProvisionOptions={leaseProvisionOptions}
              onCreateLeaseProvision={onCreateLeaseProvision}
              onUpdateLeaseProvision={onUpdateLeaseProvision}
              onDeleteLeaseProvision={onDeleteLeaseProvision}
              onCreateInstrumentType={onCreateInstrumentType}
              onUpdateInstrumentType={onUpdateInstrumentType}
              onDeleteInstrumentType={onDeleteInstrumentType}
              onCreateAssetType={onCreateAssetType}
              onUpdateAssetType={onUpdateAssetType}
              onDeleteAssetType={onDeleteAssetType}
              onCreateClient={onCreateClient}
              onUpdateClient={onUpdateClient}
              onDeleteClient={onDeleteClient}
              onCreateProperty={onCreateProperty}
              onUpdateProperty={onUpdateProperty}
              onDeleteProperty={onDeleteProperty}
              onCreateOpposingParty={onCreateOpposingParty}
              onUpdateOpposingParty={onUpdateOpposingParty}
              onDeleteOpposingParty={onDeleteOpposingParty}
              onCreatePartner={onCreatePartner}
              onUpdatePartner={onUpdatePartner}
              onDeletePartner={onDeletePartner}
              onCreateCategory={onCreateCategory}
              onUpdateCategory={onUpdateCategory}
              onDeleteCategory={onDeleteCategory}
              pendingWithRecords={pendingWithRecords}
              onCreatePendingWith={onCreatePendingWith}
              onUpdatePendingWith={onUpdatePendingWith}
              onDeletePendingWith={onDeletePendingWith}
              statusRecords={statusRecords}
              onCreateStatus={onCreateStatus}
              onUpdateStatus={onUpdateStatus}
              onDeleteStatus={onDeleteStatus}
              onUpdateMattersField={onUpdateMattersField}
              embedded={true}
            />
          </TabsContent>


          </Tabs>

          </DialogContent>
          </Dialog>
          );
          }