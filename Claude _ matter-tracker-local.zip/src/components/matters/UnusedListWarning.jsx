import { useState } from "react";
import { AlertTriangle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";

export default function UnusedListWarning({ items = [], label, getLabel, onDeleteUnused }) {
  const [confirming, setConfirming] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);

  if (!items.length) return null;

  const names = items.map(getLabel);
  const preview = names.slice(0, 8).join(", ") + (names.length > 8 ? `, plus ${names.length - 8} more` : "");
  const plural = items.length === 1 ? "" : "s";

  const handleDelete = async () => {
    setIsDeleting(true);
    await onDeleteUnused(items);
    setIsDeleting(false);
    setConfirming(false);
  };

  return (
    <>
      <div className="flex flex-wrap items-center gap-2 rounded-lg border border-amber-200 bg-amber-50 p-2.5 dark:border-amber-900/60 dark:bg-amber-950/40">
        <AlertTriangle className="h-4 w-4 shrink-0 text-amber-600 dark:text-amber-400" />
        <p className="min-w-[10rem] flex-1 text-xs text-amber-800 dark:text-amber-200">
          {items.length} {label.toLowerCase()}{plural} {items.length === 1 ? "is" : "are"} not used by any matter.
          Remove {items.length === 1 ? "it" : "them"} to clean up this list.
        </p>
        <Button
          type="button"
          size="sm"
          variant="outline"
          onClick={() => setConfirming(true)}
          className="h-8 border-amber-300 bg-white text-xs text-amber-800 hover:bg-amber-100 dark:border-amber-800 dark:bg-transparent dark:text-amber-200 dark:hover:bg-amber-900/40"
        >
          Delete unused
        </Button>
      </div>

      <AlertDialog open={confirming} onOpenChange={(open) => !open && setConfirming(false)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>
              Delete unused {label.toLowerCase()}{plural}?
            </AlertDialogTitle>
            <AlertDialogDescription>
              {preview} {items.length === 1 ? "has" : "have"} no matters associated, so nothing points to {items.length === 1 ? "it" : "them"}.
              This only cleans the dropdown list and leaves every matter untouched.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} disabled={isDeleting} className="bg-red-600 hover:bg-red-700">
              {isDeleting ? "Deleting..." : `Delete ${items.length}`}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}